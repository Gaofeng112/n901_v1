import xlrd
import os
import pdb
import shutil
import logging
import sys
# import onnx
import numpy as np
import struct
import math
import argparse
import datetime
import json
import pdb
# from rich.rule import Rule
# from rich.console import Console

# console = Console()

def compile(onnx_file, scale_file, hardware_file, memory_file, customized_file, output_path, compiler_name, npu_name, process_cnt):
    # console.print('compiler name: {}'.format(compiler_name), style='blink')
    if npu_name == 'n900':
        result_path = os.path.join(output_path, 'case')
        if (os.path.exists(result_path)):
            shutil.rmtree(result_path)
        os.makedirs(result_path)
        # ncw_result_path = os.path.join(output_path, 'case_ncw')
        # if (os.path.exists(ncw_result_path)):
        #     shutil.rmtree(ncw_result_path)
        # os.makedirs(ncw_result_path)

    elif npu_name== 'n901_FPGA':
        result_path = os.path.join(output_path, 'case')
        if (os.path.exists(result_path)):
            shutil.rmtree(result_path)
        os.makedirs(result_path)
        ncw_result_path = os.path.join(output_path, 'case_ncw')
        if (os.path.exists(ncw_result_path)):
            shutil.rmtree(ncw_result_path)
        os.makedirs(ncw_result_path)

    elif npu_name == 'n901':
        result_path = os.path.join(output_path, 'case')
        if (os.path.exists(result_path)):
            shutil.rmtree(result_path)
        os.makedirs(result_path)
        # ncw_result_path = os.path.join(output_path, 'case_ncw')
        # if(os.path.exists(ncw_result_path)):
        #     shutil.rmtree(ncw_result_path)
        # os.makedirs(ncw_result_path)
        # ncf_result_path = os.path.join(output_path, 'case_ncf')
        # if (os.path.exists(ncf_result_path)):
        #     shutil.rmtree(ncf_result_path)
        # os.makedirs(ncf_result_path)

    elif npu_name == 's900':
        result_path = os.path.join(output_path, 'case')
        if (os.path.exists(result_path)):
            shutil.rmtree(result_path)
        os.makedirs(result_path)
        ncw_result_path = os.path.join(output_path, 'case_ncw')
        if (os.path.exists(ncw_result_path)):
            shutil.rmtree(ncw_result_path)
        os.makedirs(ncw_result_path)

    elif npu_name == 's000':
        # result_path = os.path.join(output_path, 'case')
        # if (os.path.exists(result_path)):
        #     shutil.rmtree(result_path)
        # os.makedirs(result_path)
        ncw_result_path = os.path.join(output_path, 'case_ncw')
        if (os.path.exists(ncw_result_path)):
            shutil.rmtree(ncw_result_path)
        os.makedirs(ncw_result_path)
                    
    # ncw_ncf_result_path = os.path.join(output_path, 'case_ncw_ncf')
    # if (os.path.exists(ncw_ncf_result_path)):
    #     shutil.rmtree(ncw_ncf_result_path)
    # os.makedirs(ncw_ncf_result_path)
    compiler_script_file = os.path.join('..', compiler_name , 'Compiler.py')
    # compiler_script_file = os.path.join('..', compiler_name , 'Compiler.py')
    if npu_name == 'n900':
        command = 'python3 %s -o %s -hw %s -s %s -m %s -c %s -r %s -l %s -pc %s'\
            %(compiler_script_file, onnx_file, hardware_file, scale_file, memory_file,
            customized_file, result_path, 'DEBUG', process_cnt)
        os.system(command)
        # command = 'python3 %s -o %s -hw %s -s %s -m %s -r %s -l %s -pc %s -nc'\
        #     %(compiler_script_file, onnx_file, hardware_file, scale_file, memory_file,
        #     ncw_result_path, 'DEBUG', process_cnt)
        # os.system(command)

    elif npu_name == 'n901':
        # command = 'python3 %s -o %s -hw %s -s %s -m %s -r %s -l %s'\
        #     %(compiler_script_file, onnx_file, hardware_file, scale_file, memory_file,
        #     result_path, 'DEBUG')
        # os.system(command)
        # command = 'python3 %s -o %s -hw %s -s %s -m %s -r %s -l %s -pc %s  -ncf'\
        #     %(compiler_script_file, onnx_file, hardware_file, scale_file, memory_file, result_path, 'DEBUG')
        # os.system(command)
        command = 'python3 %s -o %s -hw %s -s %s -m %s -r %s -l %s -pc %s -ncf'\
            %(compiler_script_file, onnx_file, hardware_file, scale_file, memory_file,
            output_path, 'DEBUG', process_cnt)
        os.system(command)

    elif npu_name == 'n901_FPGA':
        command = 'python3 %s -o %s -hw %s -s %s -m %s -r %s -l %s '\
            %(compiler_script_file, onnx_file, hardware_file, scale_file, memory_file,
            result_path, 'DEBUG')
        os.system(command)
        command = 'python3 %s -o %s -hw %s -s %s -m %s -r %s -l %s -nc'\
            %(compiler_script_file, onnx_file, hardware_file, scale_file, memory_file,
            ncw_result_path, 'DEBUG')
        os.system(command)
    
    elif npu_name == 's900':
        # command = 'python3 %s -o %s -hw %s -s %s -m %s -r %s -l %s -pc %s'\
        #     %(compiler_script_file, onnx_file, hardware_file, scale_file, memory_file,
        #     result_path, 'DEBUG', process_cnt)
        # os.system(command)
        command = 'python3 %s -o %s -hw %s -s %s -m %s -r %s -l %s -pc %s -nc'\
            %(compiler_script_file, onnx_file, hardware_file, scale_file, memory_file,
            ncw_result_path, 'DEBUG', process_cnt)
        os.system(command)
    
    elif npu_name == 's000':
        # command = 'python3 %s -o %s -hw %s -s %s -m %s -r %s -l %s -pc %s'\
        #     %(compiler_script_file, onnx_file, hardware_file, scale_file, memory_file,
        #     result_path, 'DEBUG', process_cnt)
        # os.system(command)
        command = 'python3 %s -o %s -hw %s -s %s -m %s -r %s -l %s -pc %s -nc'\
            %(compiler_script_file, onnx_file, hardware_file, scale_file, memory_file,
            ncw_result_path, 'DEBUG', process_cnt)
        os.system(command)
    print("Generate case finished!")

def gen_golden(IEE_name, onnx_file, img_file, scale_file, hardware_json_path,config_path, output_path, npu_name):
    print("Generate golden!")
    inference_files_folder = '/mnt/c/inference_files'
    if (os.path.exists(inference_files_folder)):
        shutil.rmtree(inference_files_folder)
    os.makedirs(inference_files_folder)
    if npu_name == 'n901' or npu_name == 'n900' or npu_name == 'n901_FPGA':
        if hardware_json_path == None:
            hardware_file = os.path.join(config_path, 'hardware.json')
        else:
            hardware_file = os.path.join(hardware_json_path, 'hardware_n900_n901.json')
        config_file_path = hardware_file
    elif npu_name == 's900':
        config_file_path = '../IEE/config/hardware_s900.json'
    golden_bin_path = os.path.join(output_path, 'golden')
    case_bin_path = os.path.join(output_path, 'case')
    

    ## for verifynet
    onnx_file_path = onnx_file
    scale_info_file_path = scale_file
    img_file_path = img_file
    iee_script_file = os.path.join('..', IEE_name, 'IEE.py')
    if img_file_path != None:
        command = 'python3 %s --load_npy %s --img_folder %s --save_temp_path %s --config_json %s --gloden %s --onnx_net %s --scale_info_json %s --platform %s' \
            %(iee_script_file, True, img_file_path, inference_files_folder, config_file_path, golden_bin_path, onnx_file_path, scale_info_file_path, npu_name)
    else:
        command = 'python3 %s --load_npy %s --img_folder %s --save_temp_path %s --config_json %s --gloden %s --onnx_net %s --scale_info_json %s --platform %s' \
            %(iee_script_file, False, 'None', inference_files_folder, config_file_path, golden_bin_path, onnx_file_path, scale_info_file_path, npu_name)
        
    os.system(command)
    print("Generate golden finished!")

def copy_files(onnx_file, scale_file, output_path, img_file):
    print('Copy files!')
    command = 'cp %s %s' %(onnx_file, output_path)
    os.system(command)
    command = 'cp %s %s' %(scale_file, output_path)
    os.system(command)
    if (img_file != None):
        img_file_path = os.path.join(output_path, 'img_file')
        command = 'cp -r %s %s' %(img_file, img_file_path)
        os.system(command)
    print('Copy files finished!')

def gen_opflow_case(onnx_file, scale_file, img_file, hardware_json_path, customized_path, output_path, compiler_name, npu_name, process_cnt, run_iee, just_run_iee):
    # print('#######################################')
    # console.rule(title='input file path',style= 'green',align= 'center')
    # console.print('onnx path:{}'.format(onnx_file), style='blue')
    # console.print('json path:{}'.format(scale_file),style='blue')
    # console.rule()
    IEE_name = 'IEE'
    config_path = os.path.join('..', compiler_name, 'config')
    if scale_file == '/mnt/c/Users/14062/Documents/GitHub/onnx_net/RCAN_net/None':
        scale_file = None
    if hardware_json_path == None:
        hardware_file = os.path.join(config_path, 'hardware.json')
    else:
        hardware_file = os.path.join(hardware_json_path, 'hardware_n900_n901.json')
    if customized_path == None:
        customized_file = ''
    else:
        customized_file = customized_path
    memory_file = os.path.join(config_path, 'memory.json')

    if (os.path.exists(output_path)):
        shutil.rmtree(output_path)
    os.makedirs(output_path)

    ### run the compiler and generate the case file ###
    if just_run_iee == True:
        pass
    else:
        starttime = datetime.datetime.now()
        compile(onnx_file, scale_file, hardware_file, memory_file, customized_file, output_path, compiler_name, npu_name, process_cnt)
        print("Generate case done!")
        endtime = datetime.datetime.now()
        seconds  = (endtime - starttime).seconds
        print ('Total compiler running time {} second'.format(seconds))
        # console.rule(title='compile ending',style='green',align='center')
    ###################################################

    ### copy files of onnx json and npy ###
    # copy_files(onnx_file, scale_file, output_path, img_file)
    print("Copy files done!")
    #######################################

    ### run the iee and generate the golden file ###
    iee(IEE_name,onnx_file, img_file, scale_file, hardware_json_path, config_path, output_path , npu_name, run_iee, just_run_iee)
    ################################################

def iee(IEE_name,onnx_file, img_file, scale_file, hardware_json_path, config_path, output_path , npu_name, run_iee, just_run_iee):
    if (just_run_iee == False and run_iee == False):
        pass
    else:
        starttime = datetime.datetime.now()
        gen_golden(IEE_name, onnx_file, img_file, scale_file, hardware_json_path, config_path, output_path, npu_name)
        print("Generate golden done!")
        print(onnx_file)
        endtime = datetime.datetime.now()
        seconds  = (endtime - starttime).seconds
        print ('Total golden running time {} second'.format(seconds))

def gen_cases(worksheet, st, ed, process_cnt, run_iee, just_run_iee):
    if 'v001' in worksheet.name:
        npu_name = 'n901'
        compiler_name = 'compiler_n901'
    elif 'v002' in worksheet.name:
        npu_name = 'n900'
        compiler_name = 'compiler_n900'
    elif 'v003' in worksheet.name:
        npu_name = 'n901_FPGA'
        compiler_name = 'compiler_n901'
    elif 'v004' in worksheet.name:
        npu_name = 's900'
        compiler_name = 'compiler_s900'
    elif 'v005' in worksheet.name:
        npu_name = 's000'
        compiler_name = 'compiler_s000'
    for curr_case_num in range(st, ed + 1):
        # cmd_name = worksheet.row_values(curr_case_num)
        # pdb.set_trace()
        case = worksheet.row_values(curr_case_num)
        onnx_file = os.path.join(case[1], case[2])
        scale_file = os.path.join(case[1], case[3])
        if case[4] == '':
            img_file = None
        else:
            img_file = os.path.join(case[1], case[4])
        if case[5] == '':
            hardware_json_path = None
        else:
            hardware_json_path = os.path.join(case[1], case[5])
        if case[6] == '':
            customized_path = None
        else:
            customized_path = os.path.join(case[1], case[6])
        output_path = os.path.join('/mnt/d/github/output', npu_name + '_case_' + case[1].split('/')[-1]+ '_' + case[2].split('.')[0] + '_' + case[3].split('.')[0])
        # print('---------')
        # print(compiler_name)
        # print(worksheet.name, 'case', curr_case_num)
        # print(onnx_file)
        # print(scale_file)
        print("输出路径",output_path)
        gen_opflow_case(onnx_file, scale_file, img_file, hardware_json_path, customized_path, output_path, compiler_name, npu_name, process_cnt, run_iee, just_run_iee)

def case_generation(argv):
    # pdb.set_trace()
    workbook = xlrd.open_workbook("/mnt/d/github/opflow_case.xlsx")
    sheet_list = workbook.sheets()
    process_cnt = argv.PC
    run_iee = argv.run_iee
    just_run_iee = argv.just_run_iee
    if len(argv.Group) == 0 or len(argv.Group) > 3:
        print("Error")
    elif len(argv.Group) == 1:
        for worksheet in workbook.sheets():
            if argv.Group[0] in worksheet.name:
                case_num = worksheet.nrows - 1
                st, ed = 1, case_num
                gen_cases(worksheet, st, ed, process_cnt, run_iee, just_run_iee)
    elif len(argv.Group) == 2:
        for worksheet in workbook.sheets():
            if argv.Group[0] in worksheet.name:
                case_num = int(argv.Group[1])
                gen_cases(worksheet, case_num, case_num, process_cnt, run_iee, just_run_iee)
    elif len(argv.Group) == 3:
        for worksheet in workbook.sheets():
            if argv.Group[0] in worksheet.name:
                st = int(argv.Group[1])
                ed = int(argv.Group[2])
                gen_cases(worksheet, st, ed, process_cnt, run_iee, just_run_iee)


if __name__ == "__main__":

    parser = argparse.ArgumentParser("Opflow case generation")
    parser.add_argument(action='store', nargs='*', dest='Group', help='Specify the group to generate')
    # parser.add_argument("-cn", "--compilerName", help="this is compiler name", dest="CN", type=str, default='compiler_n901_4x4')
    parser.add_argument('-pc', '--process_cnt', help="# of process count for optimization", dest="PC", type=str, default="16")
    parser.add_argument('-r',  '--run_iee', action='store_true', help='run the iee')
    # parser.add_argument('-nc', '--not_compress', action='store_true', help='use the uncomressed weight.bin')
    parser.add_argument('-justruniee', '--just_run_iee', action='store_true', help='just run iee')
    argv = parser.parse_args()
    print(argv)
    starttime = datetime.datetime.now()
    case_generation(argv)
    endtime = datetime.datetime.now()
    seconds  = (endtime - starttime).seconds
    print ('Total running time {} second'.format(seconds))
