import json
from tkinter import W
from typing import Dict
import os
import pdb
# from Graph.graph_def import Graph
# from Node.node_def import Node, HardwareFusionNode
from dataclasses import dataclass
from collections import defaultdict

@dataclass
class HardWareInfo(object):
    def __init__(self, hardware_json_path, scaling_factor_json_path = None):

        self.hardware_info = defaultdict(int) 
        self.hardware_info = self.get_hardware_info_dict_(hardware_json_path)
        self.scaling_factor_info =  self.get_scaling_factor_info_dict_(scaling_factor_json_path)
        # self.update()
    
    def get_hardware_info_dict_(self, hardware_json_path):
        if hardware_json_path == None : return {}
        if hardware_json_path == '' : return {}
        hardware_config_file = open(hardware_json_path, 'r', encoding='utf-8')
        hardware_dict = json.load(hardware_config_file)
        return hardware_dict

    def get_scaling_factor_info_dict_(self, scaling_factor_json_path):
        if scaling_factor_json_path == None : return {}
        if scaling_factor_json_path == '' : return {}
        scaling_factor_json_file = open(scaling_factor_json_path, 'r', encoding='utf-8')
        scaling_factor_dict = json.load(scaling_factor_json_file)
        return scaling_factor_dict

    def update(self):
        ### hardcode for data_in_bitwidth, data_out_bitwidth
        self.scaling_factor_info["scale_info"]["data_in_bitwidth"] = 8
        self.scaling_factor_info["scale_info"]["data_out_bitwidth"] = 8


# hardware_config_file_path = "config/hardware.json"
# scaling_factor_file_path = "config/scale_info_cut.2.test.json"

# myHw_info = HardWareInfo(hardware_config_file_path)

# Hwbitwidth_info = myHw_info.hardware_info


if __name__ == "__main__":
    
    hardware_config_file_path = "config/hardware.json"
    scaling_factor_file_path =  "config/scale_info_cut7_4.json"

    myHw_info = HardWareInfo(hardware_config_file_path, scaling_factor_file_path) 
    pdb.set_trace() 
    print(myHw_info.hardware_info)  
    ### key : conv_bitwidth, bn_a_bitwidth, bn_b_bitwidth, working_bitwidth, datapath_bitwidth, 
    ## leaky_relu_alpha, prelu_alpha, relu6_th_bitwidth

    # print(myHw_info.scaling_factor_info["scale_info"]["conv2d_1"]["x_radix"])
    ### scale_info {layer_name}

    # a = myHw_info.scaling_factor_info["scale_info"]["conv2d_1"]["x_radix"]
    # print(type(a))
    # conv_hw_info = {}
    # for key, val in myHw_info.hardware_info.items():
        # if key == "conv_bitwidth":
            # conv_hw_info[key] = val
        # if key == "working_bitwidth" or key == "datapath_bitwidth":
            # conv_hw_info[key] = val
    # 
    # conv_scale_factor_info = {}
    # for key, val in myHw_info.scaling_factor_info["scale_info"].items():
        # if key == "conv2d_1":
            # print("key: ", key)
            # print("val: ", val)
            # conv_scale_factor_info = val
    # 
    # print("conv_hw_info: ", conv_hw_info)
    # print("conv_scale_info: ", conv_scale_factor_info)
    # Hwbitwidth_info = myHw_info.hardware_info
    # print("\n\n\n------------------------------")
    # print("bitwidth_info: ", Hwbitwidth_info)
