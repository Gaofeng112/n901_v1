## by mengxiao
# from Frontend.Node.onnx_parser import DataProcessor
import sys
import onnx
from onnx import helper
from onnx import numpy_helper
from onnx import AttributeProto, TensorProto, GraphProto
from onnx import NodeProto, ModelProto
from typing import Dict, List
import numpy as np
import pdb

from Frontend.Hardware.hardware_info import HardWareInfo

from Frontend.Graph.onnx_parser import DataProcessor, WeightExtractor, AttributeExtractor
from Frontend.Node.functions_fl import *

### the NodeOpType
from enum import Enum, unique
@unique
class NodeOpType(Enum):
    InputNode = 1
    ConvNode = 2
    MaxPoolNode = 3
    AveragePoolNode = 4
    GlobalAveragePoolNode = 5
    BatchNormalizationNode = 6
    NormalReluNode = 7
    LeakyReluNode = 8
    PReluNode = 9
    UpsampleNode = 10
    ConcatNode = 11
    GemmNode = 12
    AddNode = 13
    FlattenNode = 14
    HardwareFusionNode = 15
    ClipNode = 16
    ShiftNode = 17
    OutputNode = 18
    L2NormalizationNode = 19
    SoftmaxNode = 20
    MishNode = 21
    SiluNode = 22
    BypassNode = 23
    TruncaterNode = 24

def update_hw_info(hw_info, scale_info):
    assert isinstance(hw_info, dict)
    assert isinstance(scale_info, dict)
    for key, val in scale_info.items():
        hw_info[key] = val
    
    return hw_info

### the IR Node 
class Node(object):  ### class name 
    ##
    # parents : [Node] = []
    # children : [Node] = []
    ## construction function  ????
    def __init__(self, node_ : NodeProto = None, name = ""):
        if (name):
            self.parents = []
            self.children = []
            self.name = name
            self.shape = []
            self.input_shape = []
        elif (node_):
            self.parents = []       ## the list of current node input 
            self.children = []      ## the list of current node output
            self.name = node_.name
            self.shape = []         ## the shape of current node ouput dimension / a list
            self.input_shape = []   ## the shape of current node input dimension / a list of list
        else:
            self.parents = []
            self.children = []
            self.name = ""
            self.shape = []
            self.input_shape = []

        # self.is_onnx_output = False
        self.index = 0   ### for topological sort  
        self.type = ""

    def copy(self, ir_node_):
        self.parents = ir_node_.parents
        self.children = ir_node_.children
        self.name = ir_node_.name
        self.shape = ir_node_.shape
        self.input_shape = ir_node_.input_shape

class BypassNode(object):
    def __init__(self):
        self.op_type = NodeOpType.BypassNode
        self.hasSetParent = False
        self.parents = []
        self.children = []
        self.shape = None
        self.input_shape = []
        self.name = "Bypass_"
        self.index = 0
        self.type = "NPUType"
        self.hardware_info = {}

    def set_hardware_info(self, node):
        if node.op_type == NodeOpType.HardwareFusionNode:
            sub_node_list = node.sub_node_list
            output_bitwidth = sub_node_list[-1].hardware_info['output_bitwidth']
            y_radix = sub_node_list[-1].hardware_info['y_radix']
        else:
            output_bitwidth = node.hardware_info['output_bitwidth']
            y_radix = node.hardware_info['y_radix']
        self.hardware_info['input_bitwidth'] = output_bitwidth
        self.hardware_info['output_bitwidth'] = output_bitwidth
        self.hardware_info['x_radix'] = y_radix
        self.hardware_info['y_radix'] = y_radix

    def set_parent(self, pNode):
        self.parents.append(pNode)
        self.name += pNode.name + "_and_"
        self.input_shape.append(pNode.shape)
        self.shape = pNode.shape
        self.hasSetParent = True

    def set_child(self, cNode):
        if(not self.hasSetParent):
            assert(False), "Please Set Parent of Bypass Node First !!"
        self.children.append(cNode)
        self.name += cNode.name
class ClipNode(Node):
    def __init__(self, node_ : NodeProto = Node, hw_info : HardWareInfo = None):
        super().__init__(node_)
        self.op_type = NodeOpType.ClipNode
        self.clip_param = self._get_clip_param(node_)
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None

    def _get_clip_param(self, node_) -> Dict:
        ## return relu param such as alpha
        if node_.op_type != "Clip" :
            raise NameError("Not ONNX Clip Node")
        clip_param = {}
        for i in range(len(node_.attribute)):
            clip_param[node_.attribute[i].name] = node_.attribute[i].f
        
        return clip_param
    
    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "leaky_relu_alpha": 16,
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        relu_hw_info = {}
        relu_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "relu6_th_bitwidth":
                relu_hw_info[key] = val
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                relu_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    relu_scale_factor_info = val
        return update_hw_info(relu_hw_info, relu_scale_factor_info)            
        # return relu_hw_info, relu_scale_factor_info

class ShiftNode(Node):
    def __init__(self, node_ : NodeProto = None, name = ""):
        super().__init__(node_, name)
        self.op_type = NodeOpType.ShiftNode
        self.type = "CPUType"
        self.shift_param = []
        
    def set_shift_param(self, shift_param):
        self.shift_param = shift_param


class ConstantNode(Node):
    def __init__(self, node_ : NodeProto = None):
        super().__init__(node_)
        self.data = node_.attribute[0].t.float_data
        self.dim = node_.attribute[0].t.dims

class InputNode(Node):
    def __init__(self,  node_ : NodeProto = None, name = ""):
        super().__init__(node_, name)
        # self.op_type = "InputNode"
        self.op_type = NodeOpType.InputNode
        self.type = "CPUType"

class OutputNode(Node):
    def __init__(self,  node_ : NodeProto = None, name = ""):
        super().__init__(node_, name)
        self.op_type = NodeOpType.OutputNode

class ConvNode(Node):

    # def __init__(self, node_conv : NodeProto, weight_list, weight_dict, hw_info : HardWareInfo = None):
    def __init__(self, node_conv : NodeProto, hw_info : HardWareInfo = None):
        super().__init__(node_conv)
        # self.op_type = "ConvNode"
        self.op_type = NodeOpType.ConvNode
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        self.conv_param = self._get_conv_param(node_conv) if hw_info != None else None
        # self.conv_weight, self.conv_bias = self._get_conv_weight(node_conv, weight_list, weight_dict)
        self.conv_weight, self.conv_bias = np.array([]), np.array([])
    
    def _get_conv_param(self, node_) -> Dict:
        ### return the conv parameter such as: stride, pad, ...
        ### conv_param = {"stride" : [1,1], "pad" : [1,1,1,1], ...}
        if node_.op_type != "Conv" :
            raise NameError("Not ONNX Conv Node")
        conv_param = {}
        for i in range(len(node_.attribute)):
            if (node_.attribute[i].type == 7):    #### int64[]
                conv_param[node_.attribute[i].name] = node_.attribute[i].ints
            if (node_.attribute[i].type == 2):    #### int64
                conv_param[node_.attribute[i].name] = node_.attribute[i].i
        return conv_param

    def get_op_type(self) :
        return self.op_type
    
    def get_conv_weight_from_constant(self, node_weight, node_bias) -> np.array:
        ### return conv_weights
        # if node_weight.op_type != "Constant" or "weight" not in node_weight.name.lower():
        if node_weight.op_type != "Constant" :
            raise NameError("Not ONNX Conv Weight Node")
        w_kernel = node_weight.attribute[0].t.float_data
        dim_kernel = node_weight.attribute[0].t.dims
        w_kernel = np.reshape(w_kernel, dim_kernel)  ### NCK1K2
        w_kernel = w_kernel.transpose(2, 3, 1, 0)
        self.conv_weight =  w_kernel
        ### return conv_bias
        # if node_bias.op_type != "Constant" or "bias" not in node_bias.name.lower():
        if node_bias == None: return
         
        if node_bias.op_type != "Constant" :
            raise NameError("Not ONNX Conv bias Node")
        w_bias = node_bias.attribute[0].t.float_data
        w_bias = np.array(w_bias)
        self.conv_bias = w_bias

    def get_conv_weight_from_initializer(self, node_conv, weight_list, weight_dict):
        # och = len(self.hardware_info[1]['y_radix'])
        # w_bias = np.zeros((och))
        w_bias = np.array([])
        input_name_list = node_conv.input
        for input_name in input_name_list:
            if input_name in weight_dict.keys():
                weight_index = weight_dict[input_name]
                dim = onnx.numpy_helper.to_array(weight_list[weight_index]).shape
                if len(np.array(dim)) == 1:
                    w_bias = onnx.numpy_helper.to_array(weight_list[weight_index])
                    w_bias = w_bias.astype(np.float64)
                    dim_bias = w_bias.shape
                    [dim_bias] = dim_bias
                    w_bias = np.reshape(w_bias, (1, 1, 1, dim_bias))
                    w_bias = w_bias[0,0,0]
                    #logging.debug('w_bias.shape = ', w_bias.shape)
                elif len(np.array(dim)) > 1:
                    w_kernel = onnx.numpy_helper.to_array(weight_list[weight_index])
                    w_kernel = w_kernel.astype(np.float64)
                    dim_kernel = w_kernel.shape
                    w_kernel = np.reshape(w_kernel, dim_kernel)
                    w_kernel = w_kernel.transpose(2, 3, 1, 0)
        self.conv_weight, self.conv_bias = w_kernel, w_bias

    def _get_conv_weight(self, node_conv, weight_list, weight_dict):
        # och = len(self.hardware_info[1]['y_radix'])
        # w_bias = np.zeros((och))
        w_bias = np.array([])
        input_name_list = node_conv.input
        for input_name in input_name_list:
            if input_name in weight_dict.keys():
                weight_index = weight_dict[input_name]
                dim = onnx.numpy_helper.to_array(weight_list[weight_index]).shape
                if len(np.array(dim)) == 1:
                    w_bias = onnx.numpy_helper.to_array(weight_list[weight_index])
                    w_bias = w_bias.astype(np.float64)
                    dim_bias = w_bias.shape
                    [dim_bias] = dim_bias
                    w_bias = np.reshape(w_bias, (1, 1, 1, dim_bias))
                    w_bias = w_bias[0,0,0]
                    #logging.debug('w_bias.shape = ', w_bias.shape)
                elif len(np.array(dim)) > 1:
                    w_kernel = onnx.numpy_helper.to_array(weight_list[weight_index])
                    w_kernel = w_kernel.astype(np.float64)
                    dim_kernel = w_kernel.shape
                    w_kernel = np.reshape(w_kernel, dim_kernel)
                    w_kernel = w_kernel.transpose(2, 3, 1, 0)
        return w_kernel, w_bias


    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as    + scaling_factor info
        '''
        "conv_bitwidth": {
            "kernel": 8,
            "bias": 16
         },
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        conv_hw_info = {}
        conv_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "conv_bitwidth":
                conv_hw_info[key] = val
            if "working_bitwidth" in key or "datapath_path_bitwidth" in key:
                conv_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    conv_scale_factor_info = val
        return update_hw_info(conv_hw_info, conv_scale_factor_info)                    
        # return conv_hw_info, conv_scale_factor_info

    
class BNNode(Node):
    def __init__(self, node_bn, hw_info : HardWareInfo = None):
        super().__init__(node_bn)
        # self.op_type = "BNNode"
        self.op_type = NodeOpType.BatchNormalizationNode
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        self.bn_param = self._get_bn_param(node_bn)
        self.bn_beta, self.bn_gamma, self.bn_mean, self.bn_var = np.array([]), np.array([]), np.array([]), np.array([])
            # = self._get_bn_weight(node_bn, weight_list, weight_dict)
    
    def _get_bn_param(self, node_) -> np.array:
        ## return bn param  such as , epsilon, momentum
        if node_.op_type != "BatchNormalization" :
            raise NameError("Not ONNX BatchNormalization Node")
        bn_param = {}
        for i in range(len(node_.attribute)):
            bn_param[node_.attribute[i].name] = node_.attribute[i].f
        
        return bn_param
    
    def get_bn_weight_from_constant(self, node_gamma, node_beta, node_mean, node_var) -> np.array:
        ## return bn gamma
        if node_gamma.op_type != "Constant" or "gamma" not in node_gamma.name.lower():
            raise NameError("Not ONNX BatchNormalization gamma Node")
        bn_gamma = node_gamma.attribute[0].t.float_data
        bn_gamma = np.array(bn_gamma)
        self.bn_gamma = bn_gamma
    
        ## return bn beta
        if node_beta.op_type != "Constant" or "beta" not in node_beta.name.lower():
            raise NameError("Not ONNX BatchNormalization beta Node")
        bn_beta = node_beta.attribute[0].t.float_data
        bn_beta = np.array(bn_beta)
        self.bn_beta = bn_beta
    
        ## return bn mean
        if node_mean.op_type != "Constant" or "mean" not in node_mean.name.lower():
            raise NameError("Not ONNX BatchNormalization mean Node")
        bn_mean = node_mean.attribute[0].t.float_data
        bn_mean = np.array(bn_mean)
        self.bn_mean = bn_mean
    
        ## return bn var
        if node_var.op_type != "Constant" or "var" not in node_var.name.lower():
            raise NameError("Not ONNX BatchNormalization var Node")
        bn_var = node_var.attribute[0].t.float_data
        bn_var = np.array(bn_var)
        self.bn_var = bn_var

    def get_bn_weight_from_initializer(self, node_bn, weight_list, weight_dict):
        input_name_list = node_bn.input
        for input_name in input_name_list:
            if input_name in weight_dict.keys():
                weight_index = weight_dict[input_name]
                assert len(input_name_list) == 5, "BN node input error"
                # if "gamma" in weight_list[weight_index].name:
                if input_name_list[1] == weight_list[weight_index].name:
                    gamma = onnx.numpy_helper.to_array(weight_list[weight_index])
                    gamma = gamma.astype(np.float64)
                # if "beta" in weight_list[weight_index].name:
                if input_name_list[2] == weight_list[weight_index].name:
                    beta = onnx.numpy_helper.to_array(weight_list[weight_index])
                    beta = beta.astype(np.float64)
                # if "mean" in weight_list[weight_index].name:
                if input_name_list[3] == weight_list[weight_index].name:
                    mean = onnx.numpy_helper.to_array(weight_list[weight_index])
                    mean = mean.astype(np.float64)
                # if "var" in weight_list[weight_index].name:
                if input_name_list[4] == weight_list[weight_index].name:
                    var = onnx.numpy_helper.to_array(weight_list[weight_index])
                    var = var.astype(np.float64)
        self.bn_beta, self.bn_gamma, self.bn_mean, self.bn_var \
        = beta, gamma, mean, var

    def _get_bn_weight(self, node_bn, weight_list, weight_dict):
        input_name_list = node_bn.input
        for input_name in input_name_list:
            if input_name in weight_dict.keys():
                weight_index = weight_dict[input_name]
                assert len(input_name_list) == 5, "BN node input error"
                if input_name_list[1] == weight_list[weight_index].name:
                    gamma = onnx.numpy_helper.to_array(weight_list[weight_index])
                    gamma = gamma.astype(np.float64)
                if input_name_list[2] == weight_list[weight_index].name:
                    beta = onnx.numpy_helper.to_array(weight_list[weight_index])
                    beta = beta.astype(np.float64)
                if input_name_list[3] == weight_list[weight_index].name:
                    mean = onnx.numpy_helper.to_array(weight_list[weight_index])
                    mean = mean.astype(np.float64)
                if input_name_list[4] == weight_list[weight_index].name:
                    var = onnx.numpy_helper.to_array(weight_list[weight_index])
                    var = var.astype(np.float64)
        return beta, gamma, mean, var

    def get_op_type(self):
        return self.op_type

    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "bn_bitwidth": 16,
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        bn_hw_info = {}
        bn_scale_factor_info = {}
        
        for key, val in hw_info.hardware_info.items():
            if key == "bn_a_bitwidth" or key == "bn_b_bitwidth":
                bn_hw_info[key] = val
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                bn_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    bn_scale_factor_info = val

        return update_hw_info(bn_hw_info, bn_scale_factor_info)                    
        # return bn_hw_info, bn_scale_factor_info

class NormalReLUNode(Node):
    def __init__(self, node_ : NodeProto, hw_info : HardWareInfo = None):
        super().__init__(node_)
        # self.op_type = "ReluNode"
        self.op_type = NodeOpType.NormalReluNode
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        # self.ReLu_param = self._get_Relu_param(node_)
    
    # def _get_Relu_param(self, node_) -> Dict:
    #     ## return relu param such as alpha
    #     if node_.op_type != "LeakyRelu" and node_.op_type != "Relu" and node_.op_type != "PRelu":
    #         raise NameError("Not ONNX Relu Node")
    #     Relu_param = {}
    #     for i in range(len(node_.attribute)):
    #         Relu_param[node_.attribute[i].name] = node_.attribute[i].f
        
    #     return Relu_param

    def get_op_type(self):
        return self.op_type

    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "leaky_relu_alpha": 16,
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        relu_hw_info = {}
        relu_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                relu_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    relu_scale_factor_info = val
                    
        return update_hw_info(relu_hw_info, relu_scale_factor_info)                    
        # return relu_hw_info, relu_scale_factor_info

####MishNode
'''
                    elif self.node_list[i].op_type == "Mish":
                        weight_dict = self.get_node_weights(self.node_list[i])
                        temp_res_list = self.processor.get_input_tensor(self.node_list[i], weight_dict, self.input_dict, temp_folder_path, img_name)
                        assert len(temp_res_list) == 1, 'input number of this node is wrong!'
                        temp_res = functions_fl.mish(temp_res_list[0])
                        res_path = '{}/layer_{}_img_{}.npy'.format(temp_folder_path, self.node_list[i].output[0], img_name)
                        np.save(res_path, temp_res)
                        temp_array = temp_res

                    elif self.node_list[i].op_type == "Silu":
                        weight_dict = self.get_node_weights(self.node_list[i])
                        temp_res_list = self.processor.get_input_tensor(self.node_list[i], weight_dict, self.input_dict, temp_folder_path, img_name)
                        assert len(temp_res_list) == 1, 'input number of this node is wrong!'
                        temp_res = temp_res_list[0]
                        temp_res = functions_fl.silu(temp_res)
                        res_path = '{}/layer_{}_img_{}.npy'.format(temp_folder_path, self.node_list[i].output[0], img_name)
                        np.save(res_path, temp_res)
                        temp_array = temp_res

'''

class MishNode(Node):
    def __init__(self, node_ : NodeProto, hw_info : HardWareInfo = None):
        super().__init__(node_)
        # self.op_type = "LeakyReluNode"
        self.op_type = NodeOpType.MishNode
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        self.mish_param = self._get_mish_param(node_)
    
    def _get_mish_param(self, node_) -> Dict:
        ## return relu param such as alpha
        if node_.op_type != "Mish" :
            raise NameError("Not ONNX Mish Node")
        mish_param = {}
        for i in range(len(node_.attribute)):
            mish_param[node_.attribute[i].name] = node_.attribute[i].f
        
        return mish_param

    def get_op_type(self):
        return self.op_type

    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "leaky_relu_alpha": 16,
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        mish_hw_info = {}
        mish_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "leaky_relu_alpha":   ###????
                mish_hw_info[key] = val
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                mish_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    mish_scale_factor_info = val
                    
        return update_hw_info(mish_hw_info, mish_scale_factor_info)                    
        # return mish_hw_info, mish_scale_factor_info

class SiluNode(Node):
    def __init__(self, node_ : NodeProto, hw_info : HardWareInfo = None):
        super().__init__(node_)
        # self.op_type = "LeakyReluNode"
        self.op_type = NodeOpType.SiluNode
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        self.silu_param = self._get_silu_param(node_)
    
    def _get_silu_param(self, node_) -> Dict:
        ## return relu param such as alpha
        if node_.op_type != "Silu" :
            raise NameError("Not ONNX Silu Node")
        silu_param = {}
        for i in range(len(node_.attribute)):
            silu_param[node_.attribute[i].name] = node_.attribute[i].f
        
        return silu_param

    def get_op_type(self):
        return self.op_type

    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "leaky_relu_alpha": 16,
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        silu_hw_info = {}
        silu_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "leaky_relu_alpha":   ###????
                silu_hw_info[key] = val
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                silu_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    silu_scale_factor_info = val
                    
        return update_hw_info(silu_hw_info, silu_scale_factor_info)                    
        # return silu_hw_info, silu_scale_factor_info


class LeakyReLUNode(Node):
    def __init__(self, node_ : NodeProto, hw_info : HardWareInfo = None):
        super().__init__(node_)
        # self.op_type = "LeakyReluNode"
        self.op_type = NodeOpType.LeakyReluNode
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        self.leakyReLu_param = self._get_Relu_param(node_)
    
    def _get_Relu_param(self, node_) -> Dict:
        ## return relu param such as alpha
        if node_.op_type != "LeakyRelu" :
            raise NameError("Not ONNX LeakyRelu Node")
        leakyRelu_param = {}
        for i in range(len(node_.attribute)):
            leakyRelu_param[node_.attribute[i].name] = node_.attribute[i].f
        
        return leakyRelu_param

    def get_op_type(self):
        return self.op_type

    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "leaky_relu_alpha": 16,
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        leakyrelu_hw_info = {}
        leakyrelu_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "leaky_relu_alpha":
                leakyrelu_hw_info[key] = val
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                leakyrelu_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    leakyrelu_scale_factor_info = val
                    
        return update_hw_info(leakyrelu_hw_info, leakyrelu_scale_factor_info)                    
        # return leakyrelu_hw_info, leakyrelu_scale_factor_info


class PReLUNode(Node):
    def __init__(self, node_ : NodeProto, node_constant_ : NodeProto, constant, hw_info : HardWareInfo = None):
        super().__init__(node_)
        # self.op_type = "LeakyReluNode"
        self.op_type = NodeOpType.PReluNode
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        # self.PReLu_param = self._get_Relu_param(node_)
        if (constant):
            self.PReLu_weight = self._get_Relu_weight(node_constant_)

    def _get_Relu_param(self, node_) -> Dict:
        ## return relu param such as alpha
        if node_.op_type != "PRelu" :
            raise NameError("Not ONNX PRelu Node")
        PRelu_param = {}
        for i in range(len(node_.attribute)):
            PRelu_param[node_.attribute[i].name] = node_.attribute[i].f
        
        return PRelu_param

    def _get_Relu_weight(self, node_) -> np.array:
        ### return conv_weights
        if node_.op_type != "Constant" :
            raise NameError("Not ONNX Conv Weight Node")
        PReLu_weight = node_.attribute[0].t.float_data
        dims = node_.attribute[0].t.dims
        if dims[1] != 1 or dims[2] != 1:
           raise NameError("Not support the PRelu Node, dim must be same with channel num") 
        
        PReLu_weight = np.reshape(PReLu_weight, -1)
        return PReLu_weight
    
    def get_weight_from_initializer(self, node_, initializer, initializer_dict):
        index = initializer_dict[node_.input[1]]
        prelu_weight = onnx.numpy_helper.to_array(initializer[index])
        prelu_weight = prelu_weight.astype(np.float64)
        self.PReLu_weight = np.reshape(prelu_weight, -1)

    def get_op_type(self):
        return self.op_type

    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "leaky_relu_alpha": 16,
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        prelu_hw_info = {}
        prelu_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "prelu_alpha":
                prelu_hw_info[key] = val
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                prelu_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    prelu_scale_factor_info = val
                    
        return update_hw_info(prelu_hw_info, prelu_scale_factor_info)                    
        # return prelu_hw_info, prelu_scale_factor_info


class MaxPoolNode(Node):
    def __init__(self, node_ : NodeProto, hw_info : HardWareInfo = None):
        super().__init__(node_)
        self.op_type = NodeOpType.MaxPoolNode  ###"PoolNode"
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        self.maxpool_param = self._get_pool_param(node_)
    
    def _get_pool_param(self, node_) -> Dict:
        ## return pool param such as size , stride
        if node_.op_type != "MaxPool":
            raise NameError("Not ONNX MaxPool Node")
        maxpool_param = {}
        for i in range(len(node_.attribute)):
            maxpool_param[node_.attribute[i].name] = node_.attribute[i].ints
        
        return maxpool_param
    
    def get_op_type(self):
        return self.op_type

    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        maxpool_hw_info = {}
        maxpool_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                maxpool_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    maxpool_scale_factor_info = val
                    
        return update_hw_info(maxpool_hw_info, maxpool_scale_factor_info)                    
        # return maxpool_hw_info, maxpool_scale_factor_info


class AveragePoolNode(Node):
    def __init__(self, node_ : NodeProto, hw_info : HardWareInfo = None):
        super().__init__(node_)
        self.op_type = NodeOpType.AveragePoolNode  ###"PoolNode"
        # self.mode = ""       ### "MAX", AVG
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        self.avgpool_param = self._get_pool_param(node_)
    
    def _get_pool_param(self, node_) -> Dict:
        ## return pool param such as size , stride
        if node_.op_type != "AveragePool":
            raise NameError("Not ONNX AveragePool Node")
        avgpool_param = {}
        for i in range(len(node_.attribute)):
            avgpool_param[node_.attribute[i].name] = node_.attribute[i].ints
        
        return avgpool_param
    
    def get_op_type(self):
        return self.op_type

    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        avgpool_hw_info = {}
        avgpool_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                avgpool_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    avgpool_scale_factor_info = val
                    
        return update_hw_info(avgpool_hw_info, avgpool_scale_factor_info)                    
        # return avgpool_hw_info, avgpool_scale_factor_info


class UpsampleNode(Node):
    # def __init__(self, node_ : NodeProto, weight_list, weight_dict, hw_info : HardWareInfo = None):
    def __init__(self, node_ : NodeProto, hw_info : HardWareInfo = None):
        super().__init__(node_)
        self.op_type = NodeOpType.UpsampleNode
        self.mode = node_.attribute[0].s
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        # self.Upsample_param = self._get_upsample_param(node_, weight_list, weight_dict)
    
    def get_upsample_param_from_attr(self, node_) -> Dict:
        ## return pool param such as size , stride
        if node_.op_type != "Upsample" :
            raise NameError("Not ONNX Upsample Node")
        Upsample_param = {}
        Upsample_param[node_.attribute[0].name] = node_.attribute[0].s          ### mode
        Upsample_param[node_.attribute[1].name] = node_.attribute[1].floats     ### scales

        return Upsample_param
    
    def get_upsample_param_from_initializer(self, node_, weight_list, weight_dict) -> Dict:
        ## return pool param such as size , stride
        if node_.op_type != "Upsample" :
            raise NameError("Not ONNX Upsample Node")
        Upsample_param = {}
        Upsample_param[node_.attribute[0].name] = node_.attribute[0].s          ### mode

        Upsample_param['scales'] = self._get_upsample_weight(node_, weight_list, weight_dict)     ### scales
        
        return Upsample_param
    
    def _get_upsample_param(self, node_, weight_list, weight_dict) -> Dict:
        ## return pool param such as size , stride
        if node_.op_type != "Upsample" :
            raise NameError("Not ONNX Upsample Node")
        Upsample_param = {}
        Upsample_param[node_.attribute[0].name] = node_.attribute[0].s          ### mode

        Upsample_param['scales'] = self._get_upsample_weight(node_, weight_list, weight_dict)     ### scales
        
        return Upsample_param
    
    def get_op_type(self) :
        return self.op_type

    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        upsample_hw_info = {}
        upsample_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                upsample_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    upsample_scale_factor_info = val
        x_radix, y_radix = upsample_scale_factor_info['x_radix'], upsample_scale_factor_info['y_radix']
        assert(x_radix == y_radix)
        return update_hw_info(upsample_hw_info, upsample_scale_factor_info)                    
        # return upsample_hw_info, upsample_scale_factor_info

    def _get_upsample_weight(self, node_, weight_list, weight_dict):
        input_name_list = node_.input
        for input_name in input_name_list:
            if input_name in weight_dict.keys():
                weight_index = weight_dict[input_name]
                scales = onnx.numpy_helper.to_array(weight_list[weight_index])                            
        return scales

class AddNode(Node):
    def __init__(self, node_ : NodeProto, hw_info : HardWareInfo = None):
        super().__init__(node_)
        self.op_type = NodeOpType.AddNode
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        
    def get_op_type(self):
        return self.op_type

    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        add_hw_info = {}
        add_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                add_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    add_scale_factor_info = val
                    
        return update_hw_info(add_hw_info, add_scale_factor_info)                    
        # return add_hw_info, add_scale_factor_info

class ConcatNode(Node):
    def __init__(self, node_ : NodeProto, hw_info : HardWareInfo = None):
        super().__init__(node_)
        self.op_type = NodeOpType.ConcatNode
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        self.concat_param = self._get_concat_param(node_)
        
    def get_op_type(self):
        return self.op_type

    def _get_concat_param(self, node_) -> Dict:
        ## return pool param such as size , stride
        if node_.op_type != "Concat" :
            raise NameError("Not ONNX Concat Node")
        Concat_param = {}
        Concat_param[node_.attribute[0].name] = node_.attribute[0].i          ### axis
        
        return Concat_param

    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        concat_hw_info = {}
        concat_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                concat_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    concat_scale_factor_info = val
                    
        return update_hw_info(concat_hw_info, concat_scale_factor_info)                    
        # return concat_hw_info, concat_scale_factor_info


class CPUNode(Node):
    def __init__(self):
        self.type = "CPUType"
        pass
    
class L2NormalizationNode(Node):
    def __init__(self, node_: NodeProto, hw_info : HardWareInfo = None):
        super().__init__(node_=node_)
        self.type = "CPUType"
        self.op_type = NodeOpType.L2NormalizationNode
        self.func_fl = l2_norm
        self.hardware_info = self._get_hardware_info(hw_info) if hw_info != None else None
        self.L2N_param = self._get_L2N_param(node_)

    def _get_hardware_info(self, hw_info):
        ## return hw_info such as 
        '''
        "leaky_relu_alpha": 16,
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        L2N_hw_info = {}
        l2N_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                L2N_hw_info[key] = val
        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    l2N_scale_factor_info = val
        return L2N_hw_info, l2N_scale_factor_info

    def _get_L2N_param(self, node_) -> Dict:
        print(node_.input)
        ## return L2N param such as alpha
        if node_.op_type != "L2Normalization" :
            raise NameError("Not ONNX L2Normalization Node")
        l2N_param = {}
        for i in range(len(node_.attribute)):
            l2N_param[node_.attribute[i].name] = node_.attribute[i].f

        return l2N_param
    
    def get_L2N_weight_from_initializer(self, node_, weight_list, weight_dict):
        input_name_list = node_.input
        for input_name in input_name_list:
            if input_name in weight_dict.keys():
                weight_index = weight_dict[input_name]
                assert len(input_name_list) == 2, "L2N node input error"
                if input_name_list[1] == weight_list[weight_index].name:
                    L2N_scale = onnx.numpy_helper.to_array(weight_list[weight_index])
                    L2N_scale = L2N_scale.astype(np.float64)
        self.L2N_scale = L2N_scale
        
class FlattenNode(Node):
    def __init__(self, node_ : NodeProto):
        super().__init__(node_)
        # self.op_type = "FlattenNode"
        self.op_type = NodeOpType.FlattenNode
        # self.type = "CPUType"
        self.func_fl = flatten

class SliceNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.SliceNode
        weight_dict = WeightExtractor().get_node_weights(node_)
        # temp_res_list = DataProcessor().get_input_tensor(node_, weight_dict, self.input_dict, temp_folder_path, img_name)
        self.starts, self.end, self.axes, self.steps = None###?????
        self.func_fl = slice

class SigmoidNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.SigmoidNode
        self.func_fl = sigmoid

class SoftplusNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.SoftplusNode
        self.beta, self.threshold = 1, 20
        self.func_fl = softplus

class TanhNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.TanhNode
        self.func_fl = tanh

class MulNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.MulNode
        self.func_fl = mul

class DivNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.DivNode
        self.func_fl = div

class SubNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.SubNode
        self.func_fl = sub

class ShapeNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.ShapeNode
        self.func_fl = shape

class GatherNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.GatherNode
        self.indices, self.axis = 0, 0 ####
        self.func_fl = gather 

class UnsqueezeNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.UnsqueezeNode
        self.axes = 0 ###
        self.func_fl = unsqueeze


class CastNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.CastNode
        self.to = 0 ###
        self.func_fl = cast

class ReshapeNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.ReshapeNode
        self.shap, self.allowzero = 0, 0  ##
        self.func_fl = reshape

class ConstantOfShapeNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.ConstantOfShapeNode
        self.value = 0
        self.func_fl = constantofshape

class ExpNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.ExpNode
        self.func_fl = exp

class EqualNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.EqualNode
        ####self.inputs = []
        self.func_fl = equal

class WhereNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.WhereNode
        self.condition = 0  ####
        self.func_fl = where

class ExpandNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.ExpandNode
        self.shape = 0 ###
        self.func_fl = expand

class TransposeNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.TransposeNode
        self.perm = 0 ##
        self.func_fl = transpose

class ResizeNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.ResizeNode
        ## self.roi,scales,sizes,coordinate_transformation_mode,cubic_coeff_a,exclude_outside,extrapolation_value,mode,nearest_mode
        self.func_fl = resize

class SoftmaxNode(Node):
    def __init__(self, node_: NodeProto, name = ""):
        super().__init__(node_=node_, name=name)
        self.op_type = NodeOpType.SoftmaxNode

#### ????
class TruncaterNode(Node):
    def __init__(self, node_: NodeProto,  hw_info : HardWareInfo = None):
        super().__init__(node_=node_)
        self.op_type = NodeOpType.TruncaterNode
        self.hardware_info = self._get_hardware_info(hw_info)
        
    def _get_hardware_info(self, hw_info : HardWareInfo) -> Dict:
        ## return hw_info such as 
        '''
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''
        truncater_hw_info = {}
        truncater_scale_factor_info = {}
        for key, val in hw_info.hardware_info.items():
            if key == "working_bitwidth" or key == "datapath_bitwidth":
                truncater_hw_info[key] = val

        if hw_info.scaling_factor_info.get("scale_info") != None:
            for key, val in hw_info.scaling_factor_info["scale_info"].items():
                if key == self.name:
                    truncater_scale_factor_info = val
        # x_radix, y_radix = truncater_scale_factor_info['x_radix'], truncater_scale_factor_info['y_radix']
        return update_hw_info(truncater_hw_info, truncater_scale_factor_info)
class HardwareFusionNode(Node):
    def __init__(self, hwnode_name, sub_node_list):
        super().__init__(name = hwnode_name)
        # self.op_type = "HardwarefusionNode"
        self.op_type = NodeOpType.HardwareFusionNode
        self.type = "NPUType"

        self.hardware_info = self._get_hardware_info(sub_node_list)
        self.sub_node_list = sub_node_list
        self.is_conv_in = True if sub_node_list[0].op_type == NodeOpType.ConvNode else False
        self.is_bn_in, self.is_relu_in, self.is_pool_in = self.is_op_types(sub_node_list)
        self.hwfusion_node_param = self.get_hwfusion_node_param(sub_node_list)
        self.hwfusion_node_weights = self.get_hwfusion_node_weights(sub_node_list)
        self.adjusted(sub_node_list)
        # self.is_adjusted = self.adjusted(sub_node_list)
        
    ### override _get_inputs() / _get_outputs  ???? how to implement

    def is_op_types(self, sub_node_list):
        is_bn_in, is_relu_in, is_pool_in = False, False, False
        for node in sub_node_list:
            
            if node.op_type == "BNNode":
                is_bn_in = True
            elif node.op_type == "LeakyReluNode":
                is_relu_in = True
            elif node.op_type == "MaxPoolNode":
                is_pool_in = True

        return is_bn_in, is_relu_in, is_pool_in

    def get_subnodelist(self) -> List:
        
        return self.sub_node_list
        ## return Node List which can harawarefusion
    
    def get_hwfusion_node_param(self, sub_node_list):
        hwfusion_node_param = {}
        for node in sub_node_list:
            if node.op_type == NodeOpType.ConvNode:
                hwfusion_node_param["ConvParam"] = node.conv_param
            elif node.op_type == NodeOpType.UpsampleNode:
                hwfusion_node_param["UpsampleParam"] = node.upsample_param
            elif node.op_type == NodeOpType.BatchNormalizationNode:
                hwfusion_node_param["BNParam"] = node.bn_param
            elif node.op_type == NodeOpType.MaxPoolNode:
                hwfusion_node_param["MaxPoolParam"] = node.maxpool_param
            elif node.op_type == NodeOpType.AveragePoolNode:
                hwfusion_node_param["AvgPoolParam"] = node.avgpool_param
            elif node.op_type == NodeOpType.LeakyReluNode:
                hwfusion_node_param["LeakReluParam"] = node.leakyReLu_param
            # elif node.op_type == NodeOpType.PReluNode:
            #     hwfusion_node_param["PReLuParam"] = node.PReLu_param
            else:
                continue
        
        return hwfusion_node_param

    def get_hwfusion_node_weights(self, sub_node_list):
        hwfusion_node_weights = {}
        for node in sub_node_list:
            if node.op_type == NodeOpType.ConvNode:
                hwfusion_node_weights["ConvWeight"] = node.conv_weight
                hwfusion_node_weights["ConvBias"] = node.conv_bias
                
            elif node.op_type == NodeOpType.BatchNormalizationNode:
                hwfusion_node_weights["BNGamma"] = node.bn_gamma
                hwfusion_node_weights["BNBeta"] = node.bn_beta
                hwfusion_node_weights["BNMean"] = node.bn_mean
                hwfusion_node_weights["BNVar"] = node.bn_var
            else:
                continue

        return hwfusion_node_weights

    def adjusted(self, sub_node_list):
        self.parents = sub_node_list[0].parents
        self.children = sub_node_list[-1].children
        self.shape = sub_node_list[-1].shape
        self.input_shape = sub_node_list[0].input_shape
        # return True

    def _get_hardware_info(self, sub_node_list) -> Dict:
        ## return hw_info such as 
        '''
        "working_bitwidth": 32,
        "datapath_bitwidth": 16,
        '''

        hfnode_hw_info = {}
        hfnode_scale_factor_info = {}
        
        for node in sub_node_list:
            if node.op_type == NodeOpType.ConvNode:
                hfnode_hw_info["Conv_info"] = node.hardware_info
            elif node.op_type == NodeOpType.BatchNormalizationNode:
                hfnode_hw_info["BN_info"] = node.hardware_info
            elif node.op_type == NodeOpType.MaxPoolNode:
                hfnode_hw_info["MaxPool_info"] = node.hardware_info
            elif node.op_type == NodeOpType.AveragePoolNode:
                hfnode_hw_info["AvgPool_info"] = node.hardware_info
            elif node.op_type == NodeOpType.NormalReluNode:
                hfnode_hw_info["Relu_info"] = node.hardware_info
            elif node.op_type == NodeOpType.LeakyReluNode:
                hfnode_hw_info["LeakyRelu_info"] = node.hardware_info
            elif node.op_type == NodeOpType.PReluNode:
                hfnode_hw_info["PRelu_info"] = node.hardware_info
            elif node.op_type == NodeOpType.UpsampleNode:
                hfnode_hw_info["Upsample_info"] = node.hardware_info
            elif node.op_type == NodeOpType.AddNode:
                hfnode_hw_info["Add_info"] = node.hardware_info
            elif node.op_type == NodeOpType.TruncaterNode:
                hfnode_hw_info["Truncater_info"] = node.hardware_info
            else:
                continue
        '''
        for node in sub_node_list:
            if node.op_type == NodeOpType.ConvNode:
                hfnode_scale_factor_info["Conv_info"] = node.hardware_info[1]
            elif node.op_type == NodeOpType.BatchNormalizationNode:
                hfnode_scale_factor_info["BN_info"] = node.hardware_info[1]
            elif node.op_type == NodeOpType.MaxPoolNode:
                hfnode_scale_factor_info["MaxPool_info"] = node.hardware_info[1]
            elif node.op_type == NodeOpType.AveragePoolNode:
                hfnode_scale_factor_info["AvgPool_info"] = node.hardware_info[1]
            elif node.op_type == NodeOpType.NormalReluNode:
                hfnode_scale_factor_info["Relu_info"] = node.hardware_info[1]
            elif node.op_type == NodeOpType.LeakyReluNode:
                hfnode_scale_factor_info["LeakyRelu_info"] = node.hardware_info[1]
            elif node.op_type == NodeOpType.PReluNode:
                hfnode_scale_factor_info["PRelu_info"] = node.hardware_info[1]
            elif node.op_type == NodeOpType.UpsampleNode:
                hfnode_scale_factor_info["Upsample_info"] = node.hardware_info[1]
            elif node.op_type == NodeOpType.AddNode:
                hfnode_scale_factor_info["Add_info"] = node.hardware_info[1]
            else:
                continue
        '''
        return hfnode_hw_info
        # return hfnode_hw_info, hfnode_scale_factor_info
