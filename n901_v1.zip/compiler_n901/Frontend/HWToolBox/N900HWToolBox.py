import pdb
from curses import noecho
from Frontend.Graph.graph_def import Graph
from Frontend.Node.node_def import Node,BypassNode, HardwareFusionNode, NodeOpType, OutputNode
import pdb


class N900HWToolBox(object):
    def __init__(self):
        pass

    def HardwareModification(self, graph_):
        ## max pooling and aver non 2 * 2 / 3 * 3
        for node in graph_.nodes:
            if (node.op_type == NodeOpType.MaxPoolNode
                or node.op_type == NodeOpType.AveragePoolNode
                or node.op_type == NodeOpType.GlobalAveragePoolNode):
                if (node.Pool_param["kernel_shape"][0] != 2 or node.Pool_param["kernel_shape"][0]) != 3:
                    ### needs to be decomposed into a serial of 2x2 or 3x3 pooling
                    pass
        pass
        
    def HardwareFusion(self, graph_):
        assert isinstance(graph_, Graph)
        
        topo_sort = self.topo_sort(graph_)
        for node in topo_sort:
            if node in graph_.inputs:
                topo_sort.remove(node)
        graph_.nodes = topo_sort
        self.hardwarefusion_nodes(graph_)

        name_to_newnode_parents = self.get_newnode_parents(graph_)  ### self.__new_list
        name_to_newnode_children = self.get_newnode_children(graph_)  ### self.__new_list
        self.modify_node_parents_children(graph_, name_to_newnode_parents, name_to_newnode_children)
        self.__insert_bypass_nodes(graph_)
        self.reset_node_idx(graph_)
        self.get_hwnode_bitwidth(graph_)

    def __insert_bypass_nodes(self, graph):
        node_list = graph.nodes
        new_node_list = []
        i = 0
        # for node in node_list:
        while(i < len(node_list)):
            node = node_list[i]
            if(len(node.children) != 2):
                new_node_list.append(node)
                i += 1
            else:
                Len, check = self.checkStofRes(node)
                if(not check):
                    new_node_list.append(node)
                    i += 1
                else:
                    assert(Len % 2 == 1), "No Need for an Extra Bypass Node !!"
                    new_node_list.append(node)
                    i += 1
                    for j in range(Len):
                        cnode = node_list[i]
                        new_node_list.append(cnode)
                        i += 1
                    bypassnode = BypassNode()
                    bypassnode.set_hardware_info(node_list[i-1])
                    bypassnode.set_parent(node_list[i - 1])
                    bypassnode.set_child(node_list[i])
                    node_list[i - 1].children.remove(node_list[i])
                    node_list[i - 1].children.append(bypassnode)
                    if(node_list[i - 1] == node_list[i].parents[0]):
                        node_list[i].parents.remove(node_list[i - 1])
                        node_list[i].parents.insert(0, bypassnode)
                    else:
                        node_list[i].parents.remove(node_list[i - 1])
                        node_list[i].parents.append(bypassnode)
                    new_node_list.append(bypassnode)
        graph.nodes = new_node_list

    def checkStofRes(self, node):
        if node.type == "CPUType":
            return 0, False
        [c1, c2] = node.children
        if(len(c1.parents) == 2):
            c1, c2 = c2, c1
        ## assume c1 is the start node of res, c2 is the end node of res
        if(not (len(c1.parents) == 1 and len(c2.parents) == 2)):
            return 0, False
        Len = 0
        while(c1 != c2):
            if(len(c1.children) != 1):
                return 0, False
            c1 = c1.children[0]
            Len += 1
        if(Len % 2 == 0):
            return Len, False
        return Len, True
    
    def get_hwnode_bitwidth(self, graph):
        for node in graph.nodes:
            if(node.op_type == NodeOpType.HardwareFusionNode):
                print(node.sub_node_list[-1].name)
                node.hardware_info["input_bitwidth"] = node.sub_node_list[0].hardware_info["input_bitwidth"]
                node.hardware_info["output_bitwidth"] = node.sub_node_list[-1].hardware_info["output_bitwidth"]

    def reset_node_idx(self, graph):
        st_idx = 0
        for node in graph.nodes:
            st_idx = max(st_idx, node.index)
        st_idx += 1
        for node in graph.nodes:
            if node.op_type == NodeOpType.HardwareFusionNode or node.op_type == NodeOpType.BypassNode:
                node.index = st_idx
                st_idx += 1

    def get_newnode_parents(self, graph_):
        name_to_newnode_parents = {}

        for new_node in graph_.nodes:
            name_to_newnode_parents[new_node] = []
            node_parents = new_node.parents
            for node in node_parents:
                if node in graph_.nodes:
                    name_to_newnode_parents[new_node].append(node)
                elif new_node == graph_.nodes[0]:
                    name_to_newnode_parents[new_node].append(node)
                else:
                    for new_node_parent in graph_.nodes:
                        if new_node_parent.op_type == NodeOpType.HardwareFusionNode:
                            #if node in new_node_parent.sub_node_list:
                            if node == new_node_parent.sub_node_list[-1]:
                                name_to_newnode_parents[new_node].append(new_node_parent)
                            
        #print('name_to_newnode_parents:', name_to_newnode_parents)
        return name_to_newnode_parents

    def get_newnode_children(self, graph_):
        name_to_newnode_children = {}
        for new_node in graph_.nodes:
            name_to_newnode_children[new_node] = []
            node_children = new_node.children
            for node in node_children:
                if node in graph_.nodes:
                    name_to_newnode_children[new_node].append(node)
                elif new_node == graph_.nodes[-1]:
                    name_to_newnode_children[new_node].append(node)
                else:
                    for new_node_child in graph_.nodes:
                        if new_node_child.op_type == NodeOpType.HardwareFusionNode:
                            #if node in new_node_parent.sub_node_list:
                            if node == new_node_child.sub_node_list[0]:
                                name_to_newnode_children[new_node].append(new_node_child)
        #print('name_to_newnode_children:', name_to_newnode_children)
        return name_to_newnode_children

    def modify_node_parents_children(self, graph_, name_to_newnode_parents, name_to_newnode_children):
        input_node_children = {}
        parents = name_to_newnode_parents[graph_.nodes[0]]
        for inputnode in graph_.inputs:
            input_node_children[inputnode] = []
            for node, parents in name_to_newnode_parents.items():
                if inputnode in parents:
                    input_node_children[inputnode].append(node)

            inputnode.children = input_node_children[inputnode]
        
        for node in graph_.nodes:
            node.parents = name_to_newnode_parents[node]
            node.children = name_to_newnode_children[node]

    def topo_sort(self, Graph):
        """this is an implementation of dfs algorithm
        
        it generates a topological sort list from a Directed Acyclic Graph(DAC)
        constructed directly by nodes which are connected to each other through
        reference method

        Args:
            toposort: list type, contains results of topological sorts(contents are
            references of nodes), they also present the "removed" nodes
            visited: list type, contains nodes which have been visited, every node
            will be visited only once
        
        return:
            a list contains nodes after topological sort
        """
        toposort = []
        visited = []
        for i in Graph.inputs:
            self.visit(i, visited, toposort)
        return toposort

    def visit(self, node, visited, toposort):
        visited.append(node)
        for i in node.children:
            if i not in visited:
                self.visit(i, visited, toposort)
        toposort.insert(0, node)
        
    def is_DIDMA_Add(self, node):
        x0_radix = node.hardware_info["x0_radix"]
        x1_radix = node.hardware_info["x1_radix"]
        if abs(x0_radix[0] - x1_radix[0]) <= 2:
            return False
        return True
    
    def permutations(self, alist):
        if len(alist) == 1:
            return [alist]
        n = len(alist)
        ans = []
        for i in range(n):
            for each in self.permutations(alist[0:i]+alist[i+1:n]):
                ans.append([alist[i]]+each)
        return ans

    def _get_defaults(self):
        list_group = [[NodeOpType.BatchNormalizationNode, NodeOpType.NormalReluNode, 
                       NodeOpType.MaxPoolNode], 
                      [NodeOpType.BatchNormalizationNode, NodeOpType.NormalReluNode, 
                       NodeOpType.AveragePoolNode], 
                      [NodeOpType.BatchNormalizationNode, NodeOpType.NormalReluNode, 
                       NodeOpType.GlobalAveragePoolNode], 
                      [NodeOpType.BatchNormalizationNode, NodeOpType.LeakyReluNode, 
                       NodeOpType.MaxPoolNode], 
                      [NodeOpType.BatchNormalizationNode, NodeOpType.LeakyReluNode, 
                       NodeOpType.AveragePoolNode],
                      [NodeOpType.BatchNormalizationNode, NodeOpType.LeakyReluNode, 
                       NodeOpType.GlobalAveragePoolNode], 
                      [NodeOpType.BatchNormalizationNode, NodeOpType.PReluNode, 
                       NodeOpType.MaxPoolNode], 
                      [NodeOpType.BatchNormalizationNode, NodeOpType.PReluNode, 
                       NodeOpType.AveragePoolNode],
                      [NodeOpType.BatchNormalizationNode, NodeOpType.PReluNode, 
                       NodeOpType.GlobalAveragePoolNode], 
                      [NodeOpType.BatchNormalizationNode, NodeOpType.ClipNode, 
                       NodeOpType.MaxPoolNode], 
                      [NodeOpType.BatchNormalizationNode, NodeOpType.ClipNode, 
                       NodeOpType.AveragePoolNode],
                      [NodeOpType.BatchNormalizationNode, NodeOpType.ClipNode, 
                       NodeOpType.GlobalAveragePoolNode], 
                     ]
        len4_list = []
        for alist in list_group:
            new_list = self.permutations(alist)
            for mode in new_list:
                new_mode = [NodeOpType.ConvNode] + mode
                len4_list.append(new_mode)
                new_mode = [NodeOpType.UpsampleNode] + mode
                len4_list.append(new_mode)
                new_mode = [NodeOpType.AddNode] + mode
                len4_list.append(new_mode)

        _defaults = len4_list[:]
        for HFNode in len4_list:
            _defaults.extend([HFNode[:3], HFNode[:2], HFNode[1:], HFNode[2:]])
        modes = []
        for i in _defaults:
            if i not in modes:
                modes.append(i)
        _defaults = modes
        return _defaults
    
        
        
    def hardwarefusion_nodes(self, graph_):
        idxMap = {NodeOpType.ConvNode: 0, NodeOpType.AddNode: 1, NodeOpType.UpsampleNode: 2, NodeOpType.NormalReluNode: 3, 
                NodeOpType.LeakyReluNode: 3, NodeOpType.PReluNode: 3, NodeOpType.ClipNode: 3, NodeOpType.BatchNormalizationNode: 4, 
                NodeOpType.AveragePoolNode: 5, NodeOpType.GlobalAveragePoolNode: 5, NodeOpType.MaxPoolNode: 5, NodeOpType.SiluNode: 6, 
                NodeOpType.MishNode: 6, NodeOpType.TruncaterNode: 7}
        diffNodeSet = set()
        for key, val in idxMap.items():
            diffNodeSet.add(val)
        diffNodeCnt = len(diffNodeSet)
        onlyHead = [NodeOpType.ConvNode, NodeOpType.AddNode, NodeOpType.UpsampleNode]
        LutNode = [NodeOpType.SiluNode, NodeOpType.MishNode]
        NonlinearNode = [NodeOpType.NormalReluNode, NodeOpType.LeakyReluNode, NodeOpType.PReluNode, NodeOpType.ClipNode, NodeOpType.BatchNormalizationNode, 
                NodeOpType.AveragePoolNode, NodeOpType.GlobalAveragePoolNode, NodeOpType.MaxPoolNode, NodeOpType.TruncaterNode]
        hw_node_list = []
        i = 0
        j = 0
        node_list = graph_.nodes
        hwcount = 0
        while(i < len(node_list)):
            if(node_list[i].op_type not in idxMap.keys() or 
                (node_list[i].op_type == NodeOpType.AddNode and N900HWToolBox().is_DIDMA_Add(node_list[i]))):
                hw_node_list.append(node_list[i])
                i += 1
            else:
                Nonlinear = False
                node_cnt = [0 for x in range(0, diffNodeCnt)]
                j = i 
                sub_node_list = [node_list[j]]
                node_cnt[idxMap[node_list[j].op_type]] += 1
                if(node_list[j].op_type in NonlinearNode):
                    Nonlinear = True
                j += 1
                ## 1. index is not out of bound
                ## 2. currnode is parent of next node and next node id child of currnode without branch
                ## 3. # of currnode is 0 before
                ## 4. currnode is not the node only could occur in th head
                ## 5. if Nonlinear is True, the pending node could not be a lutnode
                while(j < len(node_list) and \
                    node_list[j].op_type in idxMap.keys() and \
                    node_list[j].parents == [sub_node_list[-1]] and sub_node_list[-1].children == [node_list[j]] and \
                    node_list[j].op_type not in onlyHead and \
                    node_cnt[idxMap[node_list[j].op_type]] != 1):
                    if(Nonlinear and node_list[j].op_type in LutNode):
                        break
                    if(node_list[j].op_type in NonlinearNode):
                        Nonlinear = True
                    if (self._check_lut_nl(node_list[j], LutNode, NonlinearNode)):
                        break
                    if(self._check_add_bn_t(node_list[j])):
                        break
                    else:
                        sub_node_list.append(node_list[j]) 
                    node_cnt[idxMap[node_list[j].op_type]] += 1
                    j += 1
                if(len(sub_node_list) > 1):
                    hwnode, hwcount = self._get_hwnode(sub_node_list, hwcount)
                    hw_node_list.append(hwnode)
                else:
                    hw_node_list.append(sub_node_list[0])
                i = j
        graph_.nodes = hw_node_list
    def _check_add_bn_t(self, node):
        if node.op_type == NodeOpType.BatchNormalizationNode:
            child = node.children[0]
            parent = node.parents[0]
            if parent.op_type == NodeOpType.AddNode and child.op_type == NodeOpType.TruncaterNode:
                return True
            else:
                return False
    ##Make sure that the NonlinearNode behind the LUT is not in the HardwareFusionNode as the LUT fuse in front of it
    def _check_lut_nl(self, node, lutnode, nlnode): 
        if node.op_type in nlnode:
            if node.parents[0].op_type in lutnode:
                return True
            else:
                return False
    def _get_hwnode(self, sub_node_list, hwnode_count):
        hwnode_count = hwnode_count + 1
        name = "hardwarefusion_" + str(hwnode_count)
        myHwFusionNode = HardwareFusionNode(name, sub_node_list)
        return myHwFusionNode, hwnode_count

    def reverse_concat_input(self, topo_sort):
        for node in topo_sort:
            if node.op_type == NodeOpType.ConcatNode:
                ## reverse concat parent
                node.parents.reverse()
                ## reverse concat input radix
                new_x1_radix = node.hardware_info['x0_radix']
                new_x0_radix = node.hardware_info['x1_radix']
                node.hardware_info['x0_radix'] = new_x0_radix
                node.hardware_info['x1_radix'] = new_x1_radix

        pass
    
    def display_iobitwidth(self, graph):
        for node in graph.nodes:
            print("node name: %s\n" % (node.name))
            if(node.op_type == NodeOpType.OutputNode):
                continue
            if(node.op_type == NodeOpType.HardwareFusionNode):
                print("input_bitwidth: %d, output_bitwidth: %d\n" % \
                    (node.sub_node_list[0].hardware_info["input_bitwidth"], node.sub_node_list[-1].hardware_info["output_bitwidth"]))
            else:
                print("input_bitwidth: %d, output_bitwidth: %d\n" % \
                    (node.hardware_info["input_bitwidth"], node.hardware_info["output_bitwidth"]))