import onnx
from onnx import AttributeProto, TensorProto, GraphProto
from onnx import NodeProto, ModelProto
from typing import Dict, List
import numpy as np
import pdb
import logging
import copy
import math
from Frontend.Node.node_def import L2NormalizationNode, NodeOpType, Node, SiluNode
from Frontend.Node.node_def import (ConvNode, BNNode, NormalReLUNode, LeakyReLUNode, UpsampleNode,
                    MaxPoolNode, AddNode, InputNode, OutputNode, ConcatNode, HardwareFusionNode, TruncaterNode,
                    FlattenNode, ShiftNode, PReLUNode, AveragePoolNode, ClipNode, SoftmaxNode, MishNode, SiluNode)
from Frontend.Graph.change_prelu import Change_PReLu
from Frontend.Graph.change_avgpool import Change_AveragePool
from Frontend.Hardware.hardware_info import HardWareInfo
from Frontend.Graph.onnx_parser import Inferencer

class Graph(Inferencer):
    _npu_support_type = [NodeOpType.ConvNode, NodeOpType.BatchNormalizationNode, NodeOpType.NormalReluNode,
                        NodeOpType.LeakyReluNode, NodeOpType.MaxPoolNode, NodeOpType.GlobalAveragePoolNode,
                        NodeOpType.AveragePoolNode, NodeOpType.AddNode, NodeOpType.UpsampleNode, NodeOpType.PReluNode,
                        NodeOpType.ClipNode, NodeOpType.MishNode, NodeOpType.SiluNode, NodeOpType.TruncaterNode]

    def __init__(self, model_path, myHw_info = None):
        super().__init__(model_path)
        self.graph_ = self.model.graph
        self.inputs_name = [self.graph_.node[0].input[0] if len(self.graph_.input) != 1 else self.graph_.input[0].name]   ### only one input
        self.outputs_name = [self.graph_.output[i].name for i in range(len(self.graph_.output))]
        
        self.inputs = self._get_inputs()
        self.outputs = self._get_outputs()
        self.name = self.graph_.name
        self.existed_conv_constant, self.existed_bn_constant = self.existed_constant()
        
        ### to do ---- 
        self.__conv_constant_mapping = self.get_conv_constant_mapping() if self.existed_conv_constant else {}
        self.__bn_constant_mapping =  self.get_bn_constant_mapping() if self.existed_conv_constant else {}
        self.nodes = self._get_nodes(myHw_info) # -> [conv_o1, BN_o1]
        self.__name_to_node_mapping = self.get_mapping() ###{"conv_o1": conv_o1, "BN_o1": BN_o1}

        self.__outputname_to_node_mapping = self.get_outputname_to_node_mapping()
        self.__name_to_node_parents = self.get_node_parents_mapping()
        self.__name_to_node_children = self.get_node_children_mapping()
        
        self.__nodename_to_shape = self.get_node_shape()
        self.connect_node()
        self.deal_big_pool()
        self.process_last_node()
        self.support_mtcnn()
        
        self.support_7x7avgpool()
        # self.support_avgpool()

        self.set_node_idx()
        self.fix_pads()
    # def deal_concat_node(self):
    #     need_deal_concats = []
    #     for node in self.nodes:
    #         if node.op_type == NodeOpType.ConcatNode:
    # def _judge_concat(self, node):
    #     shape = node.shape
    #     input_shapes = node.input_shape
    #     ibw = node.hardware_info['input_bitwidth']
    #     if ibw == 16:
    #         for i_shape in input_shapes:
    #             if i_shape[1] < 32:
    #                 return node
    #     elif ibw == 8:
    #         for i_shape in input_shapes:
    #             if i_shape[1] < 64:
    #                 return node
              
    def support_7x7avgpool(self):
        nodes_list = self.nodes[:]
        # pdb.set_trace()
        for i in range(len(nodes_list)):
            node = nodes_list[i]
            # pdb.set_trace()
            if (node.op_type == NodeOpType.AveragePoolNode) and (node.avgpool_param['kernel_shape'][0] > 3) :
                self.change_averagepool(node)
                # pdb.set_trace()
            else:
                # 不符合条件则跳过当前节点
                continue

    def change_averagepool(self, node):
        parent_node = node.parents[0]
        child_node = node.children[0]
        child_is_output = False
        parent_is_intput = False

        if (parent_node.op_type == NodeOpType.InputNode) and (child_node.op_type != NodeOpType.OutputNode):
            parent_is_intput = True
            parent_node = self.inputs[0]
            self.nodes.remove(node)
            self.nodes.remove(child_node)
            del(parent_node.children[0])
            del(child_node.parents[0])
            change_averagepool = Change_AveragePool()
            change_averagepool.modified_avgpool(parent_node, child_node, node, parent_is_intput ,child_is_output)
            modified_list = change_averagepool.modified_list
            self.nodes = self.nodes + modified_list
            self.inputs = change_averagepool.input_node

        elif (child_node.op_type == NodeOpType.OutputNode) and (parent_node.op_type != NodeOpType.InputNode):
            child_is_output = True
            child_node = self.outputs[0]
            self.nodes.remove(parent_node)
            self.nodes.remove(node)
            del(parent_node.children[0])
            del(child_node.parents[0])
            change_averagepool = Change_AveragePool()
            change_averagepool.modified_avgpool(parent_node, child_node, node, parent_is_intput ,child_is_output)
            modified_list = change_averagepool.modified_list
            self.nodes = self.nodes + modified_list
            self.outputs = change_averagepool.output_node

        elif (parent_node.op_type == NodeOpType.InputNode) and (child_node.op_type == NodeOpType.OutputNode):
            parent_is_intput = True
            child_is_output = True
            parent_node = self.inputs[0]
            child_node = self.outputs[0]
            self.nodes.remove(node)
            del(parent_node.children[0])
            del(child_node.parents[0])
            change_averagepool = Change_AveragePool()
            change_averagepool.modified_avgpool(parent_node, child_node, node, parent_is_intput ,child_is_output)
            modified_list = change_averagepool.modified_list
            self.nodes = self.nodes + modified_list
            self.inputs = change_averagepool.input_node
            self.outputs = change_averagepool.output_node

        else:
            self.nodes.remove(parent_node)
            self.nodes.remove(node)
            self.nodes.remove(child_node)
            del(parent_node.children[0])
            del(child_node.parents[0])
            change_averagepool = Change_AveragePool()
            change_averagepool.modified_avgpool(parent_node, child_node, node, parent_is_intput ,child_is_output)
            modified_list = change_averagepool.modified_list
            self.nodes = self.nodes + modified_list

    def support_mtcnn(self):
        nodes_list = []
        nodes_list = self.nodes[:]
        for i in range(len(nodes_list)):
            need_change_prelu = False
            node = nodes_list[i] 
            if node.op_type == NodeOpType.PReluNode:###判断是否修改PReLU节点
                for slope in node.PReLu_weight:
                    if slope < 0:
                        need_change_prelu = True
                    else:
                        continue
                if (need_change_prelu):
                    if (node != nodes_list[-1]):
                        self.change_middle_prelu(node, i)
                    else:
                        self.change_end_prelu(node, i)
            else:
                continue

    def change_middle_prelu(self, node, i):###把该节点，父节点和子节点提出来，修改后再放进去
        modified_nodes_list = []
        parent_node = node.parents[0]###获取PReLU的父节点
        child_node = node.children[0]
        self.nodes.remove(parent_node)
        self.nodes.remove(child_node)
        self.nodes.remove(node)
        change_prelu = Change_PReLu()
        del(parent_node.children[0])#移除与当前节点的关联
        del(child_node.parents[0])
        change_prelu.modify_prelu_structure(parent_node, child_node, node, i , end_prelu = False)
        modified_nodes_list = change_prelu.modified_nodes_list
        self.nodes = self.nodes + modified_nodes_list

    def change_end_prelu(self, node, i):
        end_prelu = True
        modified_nodes_list = []
        parent_node = node.parents[0]
        child_node = self.outputs[0]
        change_prelu = Change_PReLu()
        self.nodes.remove(parent_node)
        self.nodes.remove(node)
        del(parent_node.children[0])
        del(child_node.parents[0])
        change_prelu.modify_prelu_structure(parent_node, child_node, node, i, end_prelu)
        modified_nodes_list = change_prelu.modified_nodes_list
        self.nodes = self.nodes + modified_nodes_list
        self.outputs = change_prelu.output_node
        
    def deal_big_pool(self):
        new_node_list = []
        for node in self.nodes:
            if(node.op_type == NodeOpType.MaxPoolNode and node.maxpool_param["kernel_shape"][0] > 3):
                cnt = (node.maxpool_param["kernel_shape"][0] - 3) // 2 + 1
                parents, children, first_node, last_node = node.parents, node.children, None, None
                [iw, ih], ow, oh = node.input_shape[0][2:4], 0, 0
                stride = node.maxpool_param["strides"][0]
                for j in range(cnt):
                    new_node = copy.deepcopy(node)
                    if (j==0):
                        new_node.hardware_info['output_bitwidth'] = 16
                    elif (j==cnt-1):
                        new_node.hardware_info['input_bitwidth'] = 16
                        new_node.hardware_info['output_bitwidth'] = node.hardware_info['output_bitwidth']
                    else:
                        new_node.hardware_info['input_bitwidth'] = 16
                        new_node.hardware_info['output_bitwidth'] = 16
                    new_node.name = node.name + "(" + str(j) + ")"
                    new_node.maxpool_param["kernel_shape"] = [3, 3]
                    new_node.parents, new_node.children = [], []
                    if(last_node == None):
                        first_node = new_node
                        last_node = new_node
                    else:
                        last_node.children = [new_node]
                        new_node.parents = [last_node]
                    new_node.maxpool_param["pads"] = [1, 1, 1, 1]
                    pad_t, pad_l, pad_b, pad_r = new_node.maxpool_param["pads"]
                    ow = math.floor((iw + pad_l + pad_r - 3) / stride) + 1
                    oh = math.floor((ih + pad_t + pad_b - 3) / stride) + 1
                    new_node.input_shape[0][2:4] = [iw, ih]
                    new_node.shape[2:4] = [ow, oh]
                    last_node = new_node
                    iw, ih = ow, oh
                    new_node_list.append(new_node)
                for pnode in parents:
                    first_node.parents.append(pnode)
                    for i in range(len(pnode.children)):
                        if(pnode.children[i] == node):
                            pnode.children[i] = first_node
                            break
                for cnode in children:
                    last_node.children.append(cnode)
                    for i in range(len(cnode.parents)):
                        if(cnode.parents[i] == node):
                            cnode.parents[i] = last_node
                            break
            else:
                new_node_list.append(node)
        self.nodes = new_node_list
                
    def fix_pads(self):
        for node in self.nodes:
            pad_t, pad_b, pad_l, pad_r = 0, 0, 0, 0
            stride, kh, kw = 0, 0, 0
            # pdb.set_trace()
            [ih, iw] = node.input_shape[0][2:4]
            [oh, ow] = node.shape[2:4]
            if(node.op_type == NodeOpType.ConvNode):
                pad_t, pad_l, pad_b, pad_r = node.conv_param["pads"]
                stride = node.conv_param["strides"][0]
                [kh, kw] = node.conv_param["kernel_shape"]
            elif(node.op_type == NodeOpType.MaxPoolNode):
                pad_t, pad_l, pad_b, pad_r = node.maxpool_param["pads"]
                stride = node.maxpool_param["strides"][0]
                [kh, kw] = node.maxpool_param["kernel_shape"]
            elif(node.op_type == NodeOpType.AveragePoolNode):
                pad_t, pad_l, pad_b, pad_r = node.avgpool_param["pads"]
                stride = node.avgpool_param["strides"][0]
                [kh, kw] = node.avgpool_param["kernel_shape"]
            else:
                continue
            if(stride == 1):
                continue
            if(pad_t or pad_b or pad_l or pad_r):
                pb = ((oh - 1) * stride) + kh - pad_t - ih
                pr = ((ow - 1) * stride) + kw - pad_l - iw
                assert(pb <= pad_b and pb >= 0 and pr <= pad_r and pr >= 0), "Wrong Modify Pad at node %s!" % (node.name)
                if(pb != pad_b or pr != pad_r):
                    modify_pad = [pad_t, pad_l, pb, pr]
                    logging.debug("node name: {} modified pad: {}".format(node.name, modify_pad))
                    if(node.op_type == NodeOpType.ConvNode):
                        node.conv_param["pads"] = modify_pad
                    elif(node.op_type == NodeOpType.MaxPoolNode):
                        node.maxpool_param["pads"] = modify_pad
                    elif(node.op_type == NodeOpType.AveragePoolNode):
                        node.avgpool_param["pads"] = modify_pad
                    else:
                        assert(False), "Wrong NodeOpType!!"

    

    def existed_constant(self):
        existed_conv_constant, existed_bn_constant = True, True
        if len(self.constant_node_list) == 0: return False, False
        if "Conv" in [node.op_type for node in self.node_list]: existed_conv_constant = True         
        if "BatchNormalization" in [node.op_type for node in self.node_list]: existed_bn_constant = True         
        return existed_conv_constant, existed_bn_constant

    def _get_inputs(self) -> List:
        node_list = []
        input_nodes = [input for input in self.graph_.input if input.name == self.inputs_name[0]]
        assert len(input_nodes) == 1, "Not find the input_nodes!"
        myInputnode = InputNode(name = input_nodes[0].name) 
        myInputnode.shape = [dim.dim_value for dim in input_nodes[0].type.tensor_type.shape.dim]
        node_list.append(myInputnode)
        return node_list
    
    def _get_outputs(self) -> List:
        node_list = []
        for i in range(len(self.graph_.output)):
            myOutputnode = OutputNode(name = self.graph_.output[i].name)
            myOutputnode.shape = [dim.dim_value for dim in self.graph_.output[i].type.tensor_type.shape.dim]
            node_list.append(myOutputnode)

        return node_list

    def set_node_type(self, node_):
        assert isinstance(node_, Node)
        if (node_.op_type in self._npu_support_type):
            if (node_.op_type == NodeOpType.UpsampleNode):
                if (node_.mode == b'nearest'):
                    return "NPUType"
                else:
                    return "CPUType"

            return "NPUType"

        else:
            return "CPUType"

    def get_outputname_to_node_mapping(self):
        outputname_to_node_mapping = {}
        for i in range(len(self.graph_.node)):
            if self.graph_.node[i].op_type == "Constant":
                continue
            else:
                outputname_to_node_mapping[self.graph_.node[i].output[0]] = self.graph_.node[i].name
        return outputname_to_node_mapping

    def get_conv_constant_mapping(self):
        conv_constant_mapping = {}
        for i in range(len(self.graph_.node)):
            if self.graph_.node[i].op_type == "Conv" :
                assert self.graph_.node[i - 1].op_type == "Constant"
                if i - 2 >= 0 and self.graph_.node[i - 2].op_type == "Constant" :
                    conv_constant_mapping[self.graph_.node[i].name] = [self.graph_.node[i - 2], self.graph_.node[i - 1]]
                # elif i - 2 >= 0 and graph_.node[i - 2].op_type != "Constant":
                else:
                    conv_constant_mapping[self.graph_.node[i].name] = [self.graph_.node[i - 1], None]
                
        return conv_constant_mapping
    
    def get_bn_constant_mapping(self):
        bn_constant_mapping = {}
        for i in range(len(self.graph_.node)):
            if self.graph_.node[i].op_type == "BatchNormalization" :
                assert self.graph_.node[i - 4].op_type == "Constant" and self.graph_.node[i - 3].op_type == "Constant" and \
                    self.graph_.node[i - 2].op_type == "Constant" and self.graph_.node[i - 1].op_type == "Constant"

                bn_constant_mapping[self.graph_.node[i].name] = [self.graph_.node[i - 4], self.graph_.node[i - 3], self.graph_.node[i - 2], self.graph_.node[i - 1]]
        
        return bn_constant_mapping

    def get_mapping(self):
        name_to_node_mapping = {}
        for i in range(len(self.nodes)):
            name_to_node_mapping[self.nodes[i].name] = self.nodes[i]
        
        return name_to_node_mapping

    def get_node_parents_mapping(self):
        name_to_node_parents = {}
        for i in range(len(self.graph_.node)):
            if self.graph_.node[i].op_type == "Constant":
                continue
            elif self.graph_.node[i].op_type == "Conv" or self.graph_.node[i].op_type == "BatchNormalization" or self.graph_.node[i].op_type == "PRelu" or self.graph_.node[i].op_type == 'Upsample' or self.graph_.node[i].op_type == "L2Normalization" :
            #  or self.graph_.node[i].op_type == "Softmax" or self.graph_.node[i].op_type == "Flatten":
                ### not consider the Constant node parents
                name_to_node_parents[self.graph_.node[i].name] = []
                name = self.graph_.node[i].input[0]
                if name in self.inputs_name:
                    name_to_node_parents[self.graph_.node[i].name].append(name)   ######
                else:
                    name_to_node_parents[self.graph_.node[i].name].append(self.__outputname_to_node_mapping[name]) #outputname_to_node_mapping[graph_.node[i].input[0]]]
                
            else:
                name_to_node_parents[self.graph_.node[i].name] = []
                for name in self.graph_.node[i].input:
                    if name in self.inputs_name:
                        name_to_node_parents[self.graph_.node[i].name].append(name)
                    else:
                        name_to_node_parents[self.graph_.node[i].name].append(self.__outputname_to_node_mapping[name])

        return name_to_node_parents
    
    def get_node_parentsnode_mapping(self):
        name_to_parentsnode = {}
        for i in range(len(self.graph_.node)):
            if self.graph_.node[i].op_type == "Constant":
                continue
            else:
                name_to_parentsnode[self.graph_.node[i].name] = []  ### list for node referenct
                parents_node_name = []
                
                if self.graph_.node[i].op_type == "Conv" or self.graph_.node[i].op_type == "BatchNormalization":
                    parents_node_name = [self.graph_.node[i].input[0]]   ###conv / BN input only 1
                else:
                    parents_node_name = self.graph_.node[i].input
                
                for name in parents_node_name:
                    if name == "input_1_o0":
                        name_to_parentsnode[self.graph_.node[i].name].append("inputNode")
                    else:
                        for name in self.__name_to_node_parents:
                            name_to_parentsnode[self.graph_.node[i].name].append(self.__name_to_node_mapping[name])
                
        return name_to_parentsnode

    def get_node_children_mapping(self):
        name_to_node_children = {}
        for i in range(len(self.graph_.node)):
            if self.graph_.node[i].op_type == "Constant":
                continue
            else:
                name_to_node_children[self.graph_.node[i].name] = [] 
                ouputname = self.graph_.node[i].output[0]
                for j in range(len(self.graph_.node)):
                    if self.graph_.node[j].op_type == "Constant":
                        continue
                    else:
                        for inputname in self.graph_.node[j].input:
                            if inputname == ouputname:
                                name_to_node_children[self.graph_.node[i].name].append(self.graph_.node[j].name)
                for k in range(len(self.outputs)):
                    if ouputname == self.outputs[k].name:
                        name_to_node_children[self.graph_.node[i].name].append(self.outputs[k].name)

        return name_to_node_children

    def get_node_shape(self):
        nodename_to_shape = {}  ### {node.name: [dim]}
        name_shape = {} ### {node.output[0].name : [dim]}
        for val_info in self.graph_.input:
            input_dim = [dim.dim_value for dim in val_info.type.tensor_type.shape.dim]
            name_shape[val_info.name] = input_dim

        for val_info in self.graph_.output:
            output_dim = [dim.dim_value for dim in val_info.type.tensor_type.shape.dim]
            name_shape[val_info.name] = output_dim

        for val_info in self.graph_.value_info:
            node_dim = [dim.dim_value for dim in val_info.type.tensor_type.shape.dim]
            name_shape[val_info.name] = node_dim
    
        node_output_name = self.get_outputname_to_node_mapping()
        for outputname, node_name in node_output_name.items():
            if outputname in name_shape.keys():
                nodename_to_shape[node_name] = name_shape[outputname]
            else:
                # print("not find ", outputname)
                raise ValueError("node shape not find")

        return nodename_to_shape


    def connect_node(self):

        for i in range(len(self.inputs)):
            for node in self.nodes:
                for inputname in self.__name_to_node_parents[node.name]:
                    if self.inputs[i].name == inputname:
                        self.inputs[i].children.append(node)
        
        for i in range(len(self.outputs)):
            for node in self.nodes:
                for outputname in self.__name_to_node_children[node.name]:
                    if self.outputs[i].name == outputname:
                        self.outputs[i].parents.append(node)

        for i in range(len(self.nodes)):
            for name in self.__name_to_node_parents[self.nodes[i].name]:
                if name in self.inputs_name:
                    for j in range(len(self.inputs_name)):
                        if name == self.inputs_name[j]:
                            self.nodes[i].parents.append(self.inputs[j])
                else:
                    self.nodes[i].parents.append(self.__name_to_node_mapping[name])

            for name in self.__name_to_node_children[self.nodes[i].name]:
                if name in self.outputs_name:
                    for j in range(len(self.outputs_name)):
                        if name == self.outputs_name[j]:
                            self.nodes[i].children.append(self.outputs[j])
                else:
                    self.nodes[i].children.append(self.__name_to_node_mapping[name])
            
            ### shape dim
            self.nodes[i].shape = self.__nodename_to_shape[self.nodes[i].name]
            
            ### inputshape dim
            for name in self.__name_to_node_parents[self.nodes[i].name]:
                if name in self.inputs_name:
                    self.nodes[i].input_shape = [self.inputs[0].shape]
                else:
                    self.nodes[i].input_shape.append(self.__nodename_to_shape[name])

        # return True

    def merge_flatten_node(self):
        for node in self.nodes:
            if node.op_type == NodeOpType.FlattenNode:
                assert len(node.parents) == 1
                node.parents[0].children = node.children
                node.parents[0].shape = node.shape
                self.nodes.remove(node)    

    def _get_nodes(self, myHw_info = None):
        node_list = []
        for i in range(len(self.graph_.node)):   # self.node_list
            if self.graph_.node[i].op_type == "Conv":
                my_node = ConvNode(self.graph_.node[i], myHw_info)
                
                if (self.existed_conv_constant) :
                    my_node.get_conv_weight_from_constant(node_weight = self.__conv_constant_mapping[self.graph_.node[i].name][0], 
                        node_bias=self.__conv_constant_mapping[self.graph_.node[i].name][1])
                    
                else:
                    my_node.get_conv_weight_from_initializer(self.graph_.node[i], self.initializer, self.initializer_dict)

                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)
                
            elif self.graph_.node[i].op_type == "LeakyRelu":
                my_node = LeakyReLUNode(self.graph_.node[i], myHw_info)
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)

            elif self.graph_.node[i].op_type == "Relu":
                my_node = NormalReLUNode(self.graph_.node[i], myHw_info)
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)

            elif self.graph_.node[i].op_type == "Add":
                my_node = AddNode(self.graph_.node[i], myHw_info)
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)
                
            elif self.graph_.node[i].op_type == "Truncater":
                my_node = TruncaterNode(self.graph_.node[i], myHw_info)
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)

            elif self.graph_.node[i].op_type == "Upsample":
                my_node = UpsampleNode(self.graph_.node[i], myHw_info)
                # pdb.set_trace()
                ## change by mengxiao @20220325 to YOLOv4/5 model

                if(len(self.graph_.node[i].attribute) == 2 and self.graph_.node[i].attribute[1].name == "scales"):
                    my_node.get_upsample_param_from_attr(self.graph_.node[i])
                elif(self.initializer):  ## if initializer mode, the 'scales' of upsample node exist in initializer
                    my_node.get_upsample_param_from_initializer(self.graph_.node[i], self.initializer, self.initializer_dict)
                else:
                    print("Error, can't find Upsample param!")
                
                # if (self.initializer):  ## if initializer mode, the 'scales' of upsample node exist in initializer
                #     my_node.get_upsample_param_from_initializer(self.graph_.node[i], self.initializer, self.initializer_dict)
                # else:
                #     my_node.get_upsample_param_from_attr(self.graph_.node[i])

                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)
                
            elif self.graph_.node[i].op_type == "MaxPool":
                my_node = MaxPoolNode(self.graph_.node[i], myHw_info)
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)

            elif self.graph_.node[i].op_type == "BatchNormalization":
                my_node = BNNode(self.graph_.node[i], myHw_info)
                if (self.existed_bn_constant) :
                    my_node.get_bn_weight_from_constant(node_gamma=self.__bn_constant_mapping[self.graph_.node[i].name][0], node_beta=self.__bn_constant_mapping[self.graph_.node[i].name][1], 
                        node_mean=self.__bn_constant_mapping[self.graph_.node[i].name][2], node_var=self.__bn_constant_mapping[self.graph_.node[i].name][3]) 

                else:
                    my_node.get_bn_weight_from_initializer(self.graph_.node[i], self.initializer, self.initializer_dict)
                
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)

            elif self.graph_.node[i].op_type == "Concat":
                my_node = ConcatNode(self.graph_.node[i], myHw_info)
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)

            elif self.graph_.node[i].op_type == "Flatten":
                my_node = FlattenNode(self.graph_.node[i])
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)

            elif self.graph_.node[i].op_type == "PRelu":
                if self.graph_.node[i].input[1] in self.initializer_dict:
                    init_, constant = True, False
                else:
                    init_, constant = False, True
                my_node = PReLUNode(self.graph_.node[i], self.graph_.node[i-1], constant, myHw_info)
                if (init_):
                    my_node.get_weight_from_initializer(self.graph_.node[i], self.initializer, self.initializer_dict)
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)

            elif self.graph_.node[i].op_type == "Mish":
                my_node = MishNode(self.graph_.node[i], myHw_info)
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)

            elif self.graph_.node[i].op_type == "Silu":
                my_node = SiluNode(self.graph_.node[i], myHw_info)
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)
            
            elif self.graph_.node[i].op_type == "AveragePool":
                my_node = AveragePoolNode(self.graph_.node[i], myHw_info)
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)

            elif self.graph_.node[i].op_type == "Clip":
                my_node = ClipNode(self.graph_.node[i], myHw_info)
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)
            
            elif self.graph_.node[i].op_type == "L2Normalization":
                my_node = L2NormalizationNode(self.graph_.node[i], myHw_info)
                my_node.type = self.set_node_type(my_node)
                my_node.get_L2N_weight_from_initializer(self.graph_.node[i], self.initializer, self.initializer_dict)
                print("L2Norm type: ", my_node.type)
                node_list.append(my_node)
            
            elif self.graph_.node[i].op_type == "Softmax":
                my_node = SoftmaxNode(self.graph_.node[i])
                my_node.type = self.set_node_type(my_node)
                node_list.append(my_node)
                
            elif self.graph_.node[i].op_type == "Sigmoid":
                pass

            elif self.graph_.node[i].op_type == "Softplus":
                pass
            
            elif self.graph_.node[i].op_type == "Tanh":
                pass
            
            elif self.graph_.node[i].op_type == "Mul":
                pass
            
            elif self.graph_.node[i].op_type == "Div":
                pass
            
            elif self.graph_.node[i].op_type == "Sub":
                pass
            
            elif self.graph_.node[i].op_type == "upsample_yolov4":
                pass
            
            elif self.graph_.node[i].op_type == "Flatten":
                pass
            
            elif self.graph_.node[i].op_type == "Shape":
                pass
            
            elif self.graph_.node[i].op_type == "Gather":
                pass
            
            elif self.graph_.node[i].op_type == "Unsqueeze":
                pass
            
            elif self.graph_.node[i].op_type == "Cast":
                pass
            
            elif self.graph_.node[i].op_type == "Reshape":
                pass
            
            elif self.graph_.node[i].op_type == "ConstantOfShape":
                pass
            
            elif self.graph_.node[i].op_type == "Exp":
                pass
            
            elif self.graph_.node[i].op_type == "Equal":
                pass
            
            elif self.graph_.node[i].op_type == "Where":
                pass
            
            elif self.graph_.node[i].op_type == "Expand":
                pass
            
            elif self.graph_.node[i].op_type == "Transpose":
                pass
            
            elif self.graph_.node[i].op_type == "Slice":
                pass
            
            elif self.graph_.node[i].op_type == "Resize":
                pass
            
            elif self.graph_.node[i].op_type == "Constant":   ### the new praser 
                pass
            
            else:
                assert False, "Unsupport op type: {}".format(self.graph_.node[i].op_type)

        return node_list

    def set_node_idx(self):
        len_inputs = len(self.inputs) 
        len_nodes = len(self.nodes)
        len_ouputs = len(self.outputs)
        for i in range(len_inputs):
            self.inputs[i].index = i
        
        for i in range(len_inputs, len_nodes + len_inputs):
            self.nodes[i - len_inputs].index = i
        
        for i in range(len_inputs + len_nodes, len_nodes + len_inputs + len_ouputs):
            self.outputs[i - len_inputs - len_nodes].index = i
        
    def process_last_node(self):
        for i, output_node  in enumerate(self.outputs):
            last_node = output_node.parents[0]

            if last_node.op_type == NodeOpType.ConcatNode:
                x0_radix = last_node.hardware_info["x0_radix"]
                x1_radix = last_node.hardware_info["x1_radix"]
                y_radix = last_node.hardware_info["y_radix"]
                len_x0, len_x1, len_y = len(x0_radix), len(x1_radix), len(y_radix)
                assert(len_x0 + len_x1) == len_y
                concat_shift = [(x0_radix + x1_radix)[i] - y_radix[i] for i in range(len_y)]

                my_node = ShiftNode(name = "Shift_Concat_last_" + str(i))
                my_node.set_shift_param(concat_shift)

                my_node.parents.append(last_node)
                my_node.children = last_node.children
                my_node.shape = last_node.shape
                my_node.input_shape = last_node.shape

                last_node.children = [my_node]
                output_node.parents = [my_node]
                self.nodes.append(my_node)

    
if __name__ == "__main__":

    model = onnx.load(onnx_file_path)

    ## 1
    my_Graph = Graph(model.graph)
    
    ## 2
    my_Graph = Graph()
    my_Graph.load(model.graph)    
