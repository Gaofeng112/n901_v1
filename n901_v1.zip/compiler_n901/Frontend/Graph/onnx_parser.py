import onnx
import os
import numpy as np
import logging
from onnx import numpy_helper
import pdb
class Inferencer:  
    def __init__(self, model_path):
        self.model_path = model_path
        self.model = onnx.load_model(model_path)
        self.node_list, self.constant_node_list, self.former_layer_dict, self.next_layer_dict = self.topo_sort()
        self.constant_node_output = [node.output[0] for node in self.constant_node_list]
        self.initializer, self.initializer_dict = self.get_initializer()
        self.weight_name_list = list(self.initializer_dict.keys()) + self.constant_node_output
        self.input_dict, self.output_dict, self.model_graph_input, self.model_graph_output = self._get_input_output_dict()
        
    
    def find_former_layer(self,layer_input):
        for layer in self.model.graph.node:
            if layer.op_type == 'Constant':
                continue
            layer_outputs = layer.output
            if layer_input in layer_outputs:
                return layer.name
        return ""
    
    
    def find_next_layer(self,layer_output):
        res = []
        for layer in self.model.graph.node: 
            layer_inputs = layer.input
            if layer_output in layer_inputs:
                res.append(layer.name)
        return res 
    
    
    def topo_sort(self):
        #sort node_list based on the model's info
        all_layer_dict = {} # layer_name -> node_id
        former_layer_dict = {}  # layer_name -> former layer's name , regardless of constant node
        next_layer_dict = {}  # layer_name -> next layer's name , regardless of constant node
        set_constant_node = set() # constant node name set
        for i in range(len(self.model.graph.node)):
            layer = self.model.graph.node[i]
            all_layer_dict[layer.name] = i
            if layer.op_type == "Constant":
                set_constant_node.add(layer.name)
                continue

            layer_inputs = layer.input
            for layer_input in layer_inputs:
                former_layer_name = self.find_former_layer(layer_input)
                if former_layer_name != "":
                    if layer.name not in former_layer_dict:
                        former_layer_dict[layer.name] = []
                    former_layer_dict[layer.name].append(former_layer_name)
            layer_outputs = layer.output
            for layer_output in layer_outputs:
                next_layer_list = self.find_next_layer(layer_output)
                if next_layer_list:
                    if layer.name not in next_layer_dict:
                        next_layer_dict[layer.name] = []
                    next_layer_dict[layer.name].extend(next_layer_list)

        # find first layer
        first_layer_name_set = set(all_layer_dict.keys()) - set(former_layer_dict.keys()) - set_constant_node
        # assert len(first_layer_name_set) == 1, f"find {len(first_layer_name_set)} inputs"
        first_layer_name = list(first_layer_name_set)

        #sort layer
        layer_order_list = []
        layer_order_list.extend(list(set_constant_node)) ## put constant node in head
        cur_layer_queue = first_layer_name
        while cur_layer_queue:
            next_layer_queue = []
            while len(cur_layer_queue) > 0:
                cur_layer = cur_layer_queue.pop(0)
                if cur_layer in layer_order_list:
                    continue
                whether_traverse_all_input = True
                if cur_layer in former_layer_dict:
                    for input_layer in former_layer_dict[cur_layer]:
                        if input_layer not in layer_order_list:
                            whether_traverse_all_input = False
                            break
                if whether_traverse_all_input:
                    layer_order_list.append(cur_layer)
                    if cur_layer in next_layer_dict:
                        next_layer_queue.extend(next_layer_dict[cur_layer])
            cur_layer_queue = next_layer_queue
        assert len(layer_order_list)==len(self.model.graph.node), "list do not cover all nodes"
        #layer_name to node
        node_order_list = []
        for layer_name in layer_order_list:
            for j in range(len(self.model.graph.node)):
                if self.model.graph.node[j].name == layer_name:
                    node_order_list.append(self.model.graph.node[j])
                    break
        assert len(node_order_list)==len(self.model.graph.node), "list do not cover all nodes"
        return node_order_list, node_order_list[:len(set_constant_node)], former_layer_dict, next_layer_dict
    

    def get_initializer(self):
        initializer = self.model.graph.initializer
        initializer_dict = {}
        for i in range(len(initializer)):
            name = initializer[i].name
            initializer_dict[name] = i
        return initializer, initializer_dict
    

    def _get_input_output_dict(self):
        input_dict, output_dict = {}, {} # key:node.input/ node.output, value: node.name , regardless of constant node
        model_graph_input, model_graph_output = [], [] # model.graph.input / model.graph.output
        for i in range(len(self.node_list)):
            if self.node_list[i].op_type == 'Constant':
                continue
            node_name = self.node_list[i].name
            inputs = self.node_list[i].input
            outputs = self.node_list[i].output
            assert len(outputs) == 1, 'there are multi-outputs in the node' 
            output_dict[outputs[0]] = node_name
            for ele in inputs:
                if not ele in self.weight_name_list:
                    if not ele in input_dict.keys():
                        input_dict[ele] = []
                    input_dict[ele].append(node_name)
        for k in self.model.graph.input:
            # initializer name may be stored in model.graph.input, delete it!
            if k.name not in self.weight_name_list:
                model_graph_input.append(k.name)
        for k in self.model.graph.output:
            model_graph_output.append(k.name)
        
        assert len(model_graph_input) == 1, "fail to find input node or find multi-inputs"
        output_dict[model_graph_input[0]] = 'input'
        return input_dict, output_dict, model_graph_input, model_graph_output


class AttributeExtractor():
    ''' this class aims to process AttributeProto, extract attributes in the node by name
        node.attribute.name return name of the attribution
        node.attribute.f return float number, node.attribute.floats return float list
        node.attribute.i return int number, node.attribute.ints return int list
        node.attribute.s return string object
        node.attribute.t return tensor, use onnx.numpy_helper.to_array() to obtain numpy array, no matter float_data or raw_data
    '''

    def __init__(self):
        pass

    
    def get_info_conv(self,node):
        dilation, group, pad, stride = '', 1, '', ''
        for j in range(len(node.attribute)):
            para_name =  node.attribute[j].name
            if para_name == "dilations":
                dilation = node.attribute[j].ints
            elif para_name == "group":
                group = node.attribute[j].i
            elif para_name =="pads":
                pad = node.attribute[j].ints
            elif para_name =="strides":
                stride = node.attribute[j].ints
        return dilation, group, pad, stride
    
    
    def get_info_bn(self,node):
        [epsilon] = [attr.f for attr in node.attribute if attr.name == 'epsilon']
        [momentum] = [attr.f for attr in node.attribute if attr.name == 'momentum']
        return epsilon, momentum

    
    def get_info_maxpool(self,node):
        for i in range(len(node.attribute)):
            if node.attribute[i].name == 'kernel_shape':
                kernel_shape = node.attribute[i].ints
            elif node.attribute[i].name == 'pads':
                pad = node.attribute[i].ints
            elif node.attribute[i].name == 'strides':
                stride = node.attribute[i].ints

        return kernel_shape, pad, stride

    
    def get_info_leakyrelu(self,node):
        alpha = 0.01 # default value
        if node.attribute:
            [alpha] = [attr.f for attr in node.attribute if attr.name == 'alpha']
        return alpha
    
    
    def get_info_upsample(self,node):
        mode = 'nearest'
        scales = [] # scales should be put in node's input instead of node's attribute since opset 9
        for i in range(len(node.attribute)):
            if node.attribute[i].name == 'scales':
                scales = node.attribute[i].floats
            elif node.attribute[i].name == 'mode':
                mode = node.attribute[i].s
        return mode, scales
    

    def get_info_cancat(self,node):
        [axis] = [attr.i for attr in node.attribute if attr.name == 'axis']
        return axis

    
    def get_info_clip(self,node):
        ##TODO:max and min has became the input of the node instead of attributes since opset 11
        [x_max] = [attr.f for attr in node.attribute if attr.name == 'max']
        [x_min] = [attr.f for attr in node.attribute if attr.name == 'min']
        return x_max, x_min


    def get_info_averagepool(self,node):
        for i in range(len(node.attribute)):
            if node.attribute[i].name == 'kernel_shape':
                kernel_shape = node.attribute[i].ints
            elif node.attribute[i].name == 'pads':
                pad = node.attribute[i].ints
            elif node.attribute[i].name == 'strides':
                stride = node.attribute[i].ints

        return kernel_shape, pad, stride


    def get_info_constant(self,node):
        [attr] = [a for a in node.attribute if a.name == "value"]
        w = onnx.numpy_helper.to_array(attr.t)
        return w
    
    def get_info_gather(self,node):
        [attr] = [a for a in node.attribute if a.name == "axis"]
        axis = attr.i
        return axis
    
    def get_info_unsqueeze(self,node):
        [attr] = [a for a in node.attribute if a.name == "axes"]
        axes = attr.ints
        return axes
    
    def get_info_transpose(self,node):
        [attr] = [a for a in node.attribute if a.name == "perm"]
        perm = attr.ints
        return perm
    
    def get_info_cast(self,node):
        [attr] = [a for a in node.attribute if a.name == "to"]
        to = attr.i
        return to
    
    def get_info_reshape(self,node):
        allowzero = 0
        if node.attribute:
            [attr] = [a for a in node.attribute if a.name == "allowzero"]
            allowzero = attr.i
        return allowzero
    
    def get_info_constantofshape(self,node):
        value = np.array([0])
        if node.attribute:
            [attr] = [a for a in node.attribute if a.name == "value"]
            value = onnx.numpy_helper.to_array(attr.t)
        return value
    
    def get_info_resize(self,node):
        coordinate_transformation_mode = 'half_pixel'
        cubic_coeff_a = 0.75
        exclude_outside = 0
        extrapolation_value = 0.0
        mode = 'nearst'
        nearest_mode = 'round_prefer_floor'

        for i in range(len(node.attribute)):
            if node.attribute[i].name == 'coordinate_transformation_mode':
                coordinate_transformation_mode = node.attribute[i].s
            elif node.attribute[i].name == 'cubic_coeff_a':
                cubic_coeff_a = node.attribute[i].f
            elif node.attribute[i].name == 'exclude_outside':
                exclude_outside = node.attribute[i].i
            elif node.attribute[i].name == 'extrapolation_value':
                extrapolation_value = node.attribute[i].f
            elif node.attribute[i].name == 'mode':
                mode = node.attribute[i].s
            elif node.attribute[i].name == 'nearest_mode':
                nearest_mode = node.attribute[i].s
                
        return coordinate_transformation_mode, cubic_coeff_a, exclude_outside, extrapolation_value, mode, nearest_mode
        


class WeightExtractor():

    ''' This class assume that the order of inputs for each type of node are fixed, or errors will occur!
        The class aims to obtain the weights of each node. weights are divided into two categories, 
        one is stored in model.graph.initializer,another is stored in constant nodes
    '''
    def __init__(self,initializer,initializer_dict,constant_node_list):
        self.initializer = initializer
        self.initializer_dict = initializer_dict
        self.constant_node_list = constant_node_list
        self.constant_node_output = [node.output[0] for node in self.constant_node_list]
    

    def get_node_weights(self,node):
        '''weight_dict: input name --> input array
        '''
        input_name_list = node.input
        weight_dict = {}
        for input_name in input_name_list:
            if input_name in self.initializer_dict.keys():
                index = self.initializer_dict[input_name]
                weight_dict[input_name] = onnx.numpy_helper.to_array(self.initializer[index])
            elif input_name in self.constant_node_output:
                index = self.constant_node_output.index(input_name)
                weight_dict[input_name] = AttributeExtractor().get_info_constant(self.constant_node_list[index])
            else:
                pass
        
        return weight_dict

    def update_w_kernel_for_dilation_conv(self, w_kernel, dilation):
        [dilation1, dilation2] = dilation
        if [dilation1, dilation2] != [1, 1]:
            w_kernel = w_kernel.transpose(2, 3, 1, 0)
            (f, f, C_prev, C) = w_kernel.shape
            kernel_size_effective = f + (f - 1) * (dilation1 - 1)
            w_kernel_dilated = np.zeros((kernel_size_effective, kernel_size_effective, C_prev, C))
            for j in range(f):
                for k in range(f):
                    for kernel_channel in range(C_prev):
                        for kernel_num in range(C):
                            w_kernel_dilated[dilation1 * j, dilation2 * k, kernel_channel, kernel_num] = w_kernel[j, k, kernel_channel, kernel_num]
            w_kernel = w_kernel_dilated.transpose(3,2,0,1)
        
        return w_kernel


class DataProcessor():
    def __init__(self):
        pass
    
    
    def rm_tempfile(self,node_name,input_name,input_dict,temp_file_path):
        if node_name in input_dict[input_name]:
            input_dict[input_name].remove(node_name)
        if len(input_dict[input_name]) == 0:
            os.remove(temp_file_path)
    
    def save_compute_results(self, temp_res, int_folder_path, float_folder_path, node_name, img_name, temp_res_radix):
        res_path = '{}/layer_{}_img_{}_radix_{}.npy'.format(int_folder_path, node_name, img_name, temp_res_radix)
        np.save(res_path, temp_res)
        float_temp_res = temp_res * 2 ** (-temp_res_radix)
        float_res_path = '{}/layer_{}_img_{}.npy'.format(float_folder_path, node_name, img_name)
        np.save(float_res_path, float_temp_res)


    def get_input_tensor(self,node,weight_dict,input_dict,temp_folder_path,img_name):
        '''node: onnx layer
           weight_dict: output of WeightExtractor().get_node_weights
        '''
        temp_res_list = []
        for input_name in node.input:
            if input_name in weight_dict:
                temp_res_list.append(weight_dict.pop(input_name))
            else: ## feature map of last layer
                temp_file_path = '{}/layer_{}_img_{}.npy'.format(temp_folder_path, input_name, img_name)
                logging.debug("temp_file_path: {}".format(temp_file_path))
                assert os.path.exists(temp_file_path), "fail to find the temp file: {}".format(temp_file_path)
                temp_res = np.load(temp_file_path)
                temp_res_list.append(temp_res)
                self.rm_tempfile(node.name,input_name,input_dict,temp_file_path)
        
        return temp_res_list
    
    def get_input_weights(self,node,weight_dict):
        '''node: onnx layer
           weight_dict: output of WeightExtractor().get_node_weights
        '''
        temp_res_list = []
        for input_name in node.input:
            if input_name in weight_dict:
                temp_res_list.append(weight_dict.pop(input_name))
        
        return temp_res_list
        
    def get_input_tensor_fp(self,node,weight_dict,input_dict,output_dict,int_folder_path,float_folder_path,img_name,output_per_layer):
        '''node: onnx layer
           weight_dict: output of WeightExtractor().get_node_weights
        '''
        temp_res_list = []
        temp_res_radix_list = []
        for input_name in node.input:
            if input_name in weight_dict:
                temp_res_list.append(weight_dict.pop(input_name))
            else: ## feature map of last layer
                for file in os.listdir(int_folder_path):
                    file_name = os.path.splitext(file)[0]
                    index = file_name.index('radix_')
                    if file_name[: index - 1] == 'layer_{}_img_{}'.format(output_dict[input_name], img_name):
                        temp_int_file_path = '{}/{}.npy'.format(int_folder_path, file_name)
                        temp_res_radix = int(file_name[index + 6: ])
                        temp_res_radix_list.append(temp_res_radix)
                        break
                temp_res = np.load(temp_int_file_path)
                temp_res_list.append(temp_res)   
                temp_float_file_path = '{}/layer_{}_img_{}.npy'.format(float_folder_path, output_dict[input_name], img_name)
                if not output_per_layer:
                    self.rm_tempfile(node.name,input_name,input_dict,temp_int_file_path)
                    self.rm_tempfile(node.name,input_name,input_dict,temp_float_file_path)
          
        return temp_res_list, temp_res_radix_list