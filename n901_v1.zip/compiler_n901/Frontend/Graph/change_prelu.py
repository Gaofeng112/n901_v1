from Frontend.Node.node_def import NodeOpType, NormalReLUNode , AddNode, ConvNode , PReLUNode
import numpy as np
import pdb

class Change_PReLu(object):
    def __init__(self):
        self.modified_nodes_list = []
        self.output_node = []
 
    def modify_prelu_structure(self, parent_node, child_node, prelu_node, i, end_prelu):
        conv_id = 1
        relu_id = 1
        relu_1_node = self.relu_node( prelu_node, i, relu_id)
        conv_1_node = self.conv_node(prelu_node, i, conv_id)
        relu_id = 2
        relu_2_node = self.relu_node(conv_1_node, i, relu_id)
        conv_id = 2
        conv_2_node = self.conv_node(relu_2_node, i, conv_id)
        prelu_1_node = self.prelu_node(prelu_node, i)
        conv_3_node = self.conv_3_node(prelu_node, i)
        add_node = self.add_node(relu_1_node, conv_3_node, prelu_node)
        self.fill_child_node(relu_1_node, parent_node, conv_1_node)
        self.fill_parent_node(parent_node, relu_1_node)
        self.fill_child_node(add_node, relu_1_node)
        self.fill_parent_node(parent_node, conv_1_node)
        self.fill_child_node(relu_2_node, conv_1_node)
        self.fill_parent_node(conv_1_node, relu_2_node)
        self.fill_child_node(conv_2_node, relu_2_node)
        self.fill_parent_node(relu_2_node, conv_2_node)
        self.fill_child_node(prelu_1_node, conv_2_node)
        self.fill_parent_node(conv_2_node, prelu_1_node)
        self.fill_child_node(conv_3_node, prelu_1_node)
        self.fill_parent_node(prelu_1_node, conv_3_node)
        self.fill_child_node(add_node, conv_3_node)
        self.fill_parent_node(relu_1_node, add_node, conv_3_node)
        self.fill_child_node(child_node, add_node)
        self.fill_parent_node(add_node, child_node)
        self.modified_nodes_list.append(parent_node)
        self.modified_nodes_list.append(relu_1_node)
        self.modified_nodes_list.append(conv_1_node)
        self.modified_nodes_list.append(relu_2_node)
        self.modified_nodes_list.append(conv_2_node)
        self.modified_nodes_list.append(prelu_1_node)
        self.modified_nodes_list.append(conv_3_node)
        self.modified_nodes_list.append(add_node)
        if end_prelu != True:
            self.modified_nodes_list.append(child_node)
        else:
            self.output_node.append(child_node)
        return self.modified_nodes_list, self.output_node

    def relu_node(self, node, i, relu_id):
        relunode = NormalReLUNode(None)
        relunode.name = 're_lu_'  + str(i) + '_' + str(relu_id)
        relunode.shape = node.shape
        relunode.input_shape = node.input_shape
        relunode.type = 'NPUType'
        relunode.hardware_info = self.get_relu_hwinfo(node)
        return relunode

    def conv_node(self, node, i, conv_id):
        convnode = ConvNode(None)
        convnode.name = 'Conv_' + str(i) + '_' + str(conv_id)
        convnode.shape = node.shape
        convnode.input_shape = node.input_shape
        convnode.type = 'NPUType'
        convnode.hardware_info = self.get_conv_hwinfo(node)
        convnode.conv_param = self.get_conv_param(node)
        convnode.conv_weight = self.get_conv_weight(node)
        convnode.conv_bias = self.get_conv_bias(node)
        return convnode

    def prelu_node(self, node, i):
        prelunode = PReLUNode(None, False, None)
        prelunode.name = 'p_re_lu__' + str(i)
        prelunode.shape = node.shape
        prelunode.input_shape = node.input_shape
        prelunode.type = 'NPUType'
        prelunode.hardware_info = node.hardware_info
        prelunode.PReLu_weight = np.abs(node.PReLu_weight)
        return prelunode

    def conv_3_node(self, node, i):
        convnode = ConvNode(None)
        convnode.name = 'Conv__' + str(i) + '3'
        convnode.shape = node.shape
        convnode.input_shape = node.input_shape
        convnode.type = 'NPUType'
        convnode.hardware_info = self.get_conv_hwinfo(node)
        convnode.conv_param = self.get_conv_param(node)
        convnode.conv_weight = self.get_conv3_weight(node)
        convnode.conv_bias = self.get_conv_bias(node)
        return convnode

    def add_node(self, node_1, node_2, prelu_node):
        addnode = AddNode(None)
        addnode.name = prelu_node.name
        addnode.shape = prelu_node.shape
        addnode.input_shape.append(node_1.shape)
        addnode.input_shape.append(node_2.shape)
        addnode.type = 'NPUType'
        addnode.hardware_info = self.get_add_hwinfo(node_1, node_2, prelu_node)
        return addnode

    def get_conv_hwinfo(self, node):###get函数相当于做参数初始化
        hardware_info = []
        channel = node.input_shape[0][1]
        dict_0 = {'conv_bitwidth': {'kernel': 10, 'bias': 16}, 'working_bitwidth': 32}
        dict_0['output_bitwidth'] = node.hardware_info['output_bitwidth']
        dict_0['x_radix'] = node.hardware_info['x_radix']
        dict_0['input_bitwidth'] = node.hardware_info['input_bitwidth']
        dict_0['kernel_weight_radix'] = [1 for i in range(channel)]#共channel个1作为基数
        dict_0['bias_radix'] = [1 for i in range(channel)]
        dict_0['y_radix'] = dict_0['x_radix']
        dict_0['psum_radix'] = [i + j for i, j in zip(dict_0['x_radix'], dict_0['kernel_weight_radix'])]#表示两者相加
        return dict_0

    def get_conv_param(self, node):
        channel = node.input_shape[0][1]
        conv_param =  {'dilations': [1, 1], 'group': channel, 'kernel_shape': [3, 3], 'pads': [0, 0, 2, 2], 'strides': [1, 1]} 
        return conv_param

    def get_conv_weight(self, node):
        channel = node.input_shape[0][1]
        conv_weight = np.zeros((3, 3, 1, channel))###（kr,kc,och,ich)
        for i in range(channel):
            conv_weight[0][0][0][i] = -1###左上角-1，其余为0
        return conv_weight

    def get_conv_bias(self, node):
        channel = node.input_shape[0][1]
        conv_bias = np.zeros(channel)
        return conv_bias
    
    def get_conv3_weight(self, node):
        channel = node.input_shape[0][1]
        conv_weight = np.zeros((3, 3, 1, channel))
        conv_weight[0][0][0] = np.sign(node.PReLu_weight)###取符号值
        return conv_weight
 
    def get_relu_hwinfo(self, node):
        dict_0 = {}
        hardware_info = node.hardware_info
        dict_0['working_bitwidth'] = hardware_info['working_bitwidth']
        dict_0['datapath_bitwidth'] = 16
        dict_0['output_bitwidth'] = hardware_info['output_bitwidth']
        dict_0['x_radix'] = hardware_info['x_radix']
        dict_0['input_bitwidth'] = hardware_info['input_bitwidth']
        dict_0['y_radix'] = hardware_info['y_radix']
        return dict_0
    
    def get_add_hwinfo(self, node_1, node_2, prelu_node):
        dict_0 = {'working_bitwidth': 32, 'datapath_bitwidth': 16}
        dict_0['output_bitwidth'] = prelu_node.hardware_info['output_bitwidth']
        dict_0['x0_radix'] = node_1.hardware_info['y_radix']
        dict_0['x1_radix'] = node_2.hardware_info['y_radix']
        dict_0['input_bitwidth'] = node_1.hardware_info['input_bitwidth']
        dict_0['y_radix'] = prelu_node.hardware_info['y_radix']
        return dict_0

    def fill_parent_node(self, parent_node_1, node, parent_node_2 = None ):
        node.parents.append(parent_node_1)
        if parent_node_2 != None:
            node.parents.append(parent_node_2)

    def fill_child_node(self, child_node_1, node, child_node_2 = None):
        node.children.append(child_node_1)  
        if child_node_2 != None:
            node.children.append(child_node_2)
    