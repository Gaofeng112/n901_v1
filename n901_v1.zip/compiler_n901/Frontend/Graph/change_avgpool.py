from Frontend.Node.node_def import NodeOpType, ConvNode, AveragePoolNode, AddNode
import numpy as np
import math

class Change_AveragePool(object):
    """
    该类用于将模型中的平均池化节点转换为卷积节点。
    """

    def __init__(self):
        self.modified_list = []  # 保存已修改的节点列表
        self.output_node = []   # 保存最终的输出节点列表
        self.input_node = []    #保存最终的父节点

    def modified_avgpool(self, parent_node, child_node, node, parent_is_input, child_is_output):
        """
        实现将平均池化节点替换为具有相同效果的卷积节点。
        
        """
        conv_node = self.gen_conv_node(node)  # 生成模拟平均池化的卷积节点
        
        # 根据child_is_output更新节点之间的连接关系
        if child_is_output and (not parent_is_input):
            self.modified_list.append(parent_node)  # 添加父节点到修改列表
            self.modified_list.append(conv_node)  # 添加新生成的卷积节点到修改列表

            self.set_children_parents(parent_node, conv_node)
            self.set_children_parents(conv_node, child_node)
            self.output_node.append(child_node)  # 标记子节点为输出节点
            return self.modified_list, self.output_node
        
        elif parent_is_input and (not child_is_output):
            self.modified_list.append(conv_node)  
            self.modified_list.append(child_node)  

            self.set_children_parents(parent_node, conv_node)
            self.set_children_parents(conv_node, child_node)
            self.input_node.append(parent_node)  # 标记子节点为输出节
            return self.input_node, self.modified_list
        
        elif parent_is_input and child_is_output:
            self.set_children_parents(parent_node, conv_node)
            self.set_children_parents(conv_node, child_node)
            self.modified_list.append(conv_node)
            self.input_node.append(parent_node)
            self.output_node.append(child_node)
            return self.modified_list, self.input_node, self.output_node
        
        else:
            self.set_children_parents(parent_node, conv_node)
            self.set_children_parents(conv_node, child_node)
            self.modified_list.append(parent_node)  #输入节点也加到里面
            self.modified_list.append(conv_node)
            self.modified_list.append(child_node)  # 非输出节点也加入修改列表
            return self.modified_list   

    def set_children_parents(self, node_1, node_2):
        """
        设置两个节点间的父子关系
        """
        node_1.children.append(node_2)  # node_1成为node_2的父节点
        node_2.parents.append(node_1)   # node_2的父节点列表中添加node_1

    def gen_conv_node(self, node):
        conv = ConvNode(None)
        conv.name = node.name
        conv.shape = node.shape
        conv.input_shape = node.input_shape
        conv.type = 'NPUType'
        conv.hardware_info = self.get_conv_hwinfo(node)
        conv.conv_param = self.get_conv_param(node)
        conv.conv_weight = self.get_conv_weight(node)
        conv.conv_bias = self.get_conv_bias(node)
        return conv

    def get_conv_hwinfo(self, node):
        ich = node.input_shape[0][1]
        och = node.shape[1]
        dict_0 =  {'conv_bitwidth':{'kernel':10, 'bias':16}, 'working_bitwidth':32}
        dict_0['output_bitwidth'] = node.hardware_info['output_bitwidth']
        dict_0['x_radix'] = [node.hardware_info['x_radix'][0] for i in range(ich)]
        dict_0['input_bitwidth'] = node.hardware_info['input_bitwidth']
        dict_0['kernel_weight_radix'] = [14 for i in range(och)]
        dict_0['bias_radix'] = [0 for i in range(och)]
        dict_0['y_radix'] = [node.hardware_info['y_radix'][0] for i in range(och)]
        dict_0['psum_radix'] = [self._gen_psum_radix(dict_0['x_radix'][0], dict_0['y_radix'][0], dict_0['kernel_weight_radix'][0]) for i in range(och)]
        return dict_0

    def _gen_psum_radix(self, x_radix, y_radix, kernel_weight_radix):
        """
        计算卷积操作中部分和的radix。
        """
        psum_radix = x_radix + kernel_weight_radix
        c_shift = 4 * int(math.floor((x_radix + kernel_weight_radix - psum_radix)/4))  # 计算补偿位移
        f_shift = x_radix + kernel_weight_radix - c_shift - y_radix  # 计算剩余位移
        # 调整psum_radix确保位移在15位限制内
        while f_shift > 15:
            psum_radix -= 4
            f_shift -= 4
        return psum_radix
    
    def get_conv_param(self, node):
        # Update the kernel shape to match the average pool size
        avgpool_kernel_shape = node.avgpool_param['kernel_shape']
        conv_param = {
            'dilations': [1, 1],
            'group': 1,
            'kernel_shape': avgpool_kernel_shape,
            'pads': [0, 0, 0, 0],
            'strides': [1, 1],
            'avgpool_flag': True
        }
        return conv_param
    def get_conv_weight(self, node):
        k_row, k_col = node.avgpool_param['kernel_shape']
        ich, och = node.input_shape[0][1], node.shape[1]
        conv_weight = np.zeros((k_row, k_col, ich, och))
        for i in range(k_row):
            for j in range(k_col):
                for k in range(ich):
                    for z in range(och):
                        if k==z:
                            conv_weight[i][j][k][z] = 1/(k_row * k_col)
                        else:
                            continue
        return conv_weight

    def get_conv_bias(self, node):
        """
        生成卷积层的偏置值。由于平均池化不涉及偏置，故所有偏置初始化为零。
        
        """
        channel = node.input_shape[0][1]  # 通道数
        conv_bias = np.zeros(channel)  # 所有通道偏置设为0
        return conv_bias

