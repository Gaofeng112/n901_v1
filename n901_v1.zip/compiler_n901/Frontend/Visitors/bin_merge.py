import os
import shutil
import sys
import json
import struct

class BinMerge(object):
    def __init__(self):
        pass

    def merge_bin_files(self, case_path, output_path):
        # FILE_LIST = ['config.bin', 'opflow.bin', 'cmd.bin', 'dram_weight.bin']
        self.endianConvert(case_path, case_path, "cmd.bin", 4)
        self.endianConvert(case_path, case_path, "dram_weight.bin", 4)
        self.mergeCase(case_path, case_path, output_path)

    def endianConvert(self, dir_ready_case, dir_case, file, step):
        converted_filename = file[:-4] + "_" + str(step) + ".bin"
        with open(os.path.join(dir_ready_case, converted_filename), "wb") as fw:
            with open(os.path.join(dir_case, file), "rb") as fr:
                while True:
                    data = fr.read(step)
                    if len(data) == step:
                        fw.write(data[::-1])
                    else:
                        if len(data) == 0:
                            break
                        else:
                            print("[ERROR] Remain of file {} is lack of with {}! EXIT!".format(len(data), step))
                            sys.exit(-1)
    
    def mergeCase(self, dir_ready_case, dir_case, output_path):
        file_list = ["config.bin", "opflow.bin", "cmd_4.bin", "dram_weight_4.bin"]
        offset_list = [28]  # 16 + 12

        path_net_bin = os.path.join(dir_ready_case, "net.bin")
        with open(path_net_bin, "wb") as nf:
            # Write 16 bytes offsets placeholder
            for i in range(16):
                nf.write(bytes([0]))

            for idx, file_name in enumerate(file_list):
                size_file_block = 0

                # Write 12 zero-byte
                for i in range(12):
                    nf.write(bytes([0]))
                size_file_block += 12

                # Write 4 bytes file size
                size_ori_file = os.path.getsize(os.path.join(dir_case, file_name))
                print("    File: {}, size: {}".format(file_name, size_ori_file))
                nf.write(size_ori_file.to_bytes(4, byteorder="big", signed=True))
                size_file_block += 4

                # Write file
                with open(os.path.join(dir_case, file_name), "rb") as f:
                    nf.write(f.read())
                size_file_block += size_ori_file

                # Pad zero at the end
                if size_ori_file % 16 == 0:
                    print("      Pad 0 zero(s) at the end.")
                else:
                    num_pad = 16 - (size_ori_file % 16)
                    print("      Pad {} zero(s) at the end.".format(num_pad))
                    for i in range(num_pad):
                        nf.write(bytes([0]))
                    size_file_block += num_pad
                print("      After padding, size: {}".format(size_file_block))

                # Calculate offset
                if idx == 3:
                    pass  # No need calculation for the last one
                else:
                    offset = offset_list[-1] - 12 + size_file_block + 12
                    offset_list.append(offset)
            print("    Offsets: {}".format(offset_list))

            # Write offsets at the head
            nf.seek(0, 0)  # Set file pointer to the head
            for offset in offset_list:
                nf.write(offset.to_bytes(4, byteorder="big", signed=True))

        size_net_file = os.path.getsize(path_net_bin)
        shutil.copyfile(dir_case +'/net.bin', output_path+'/net.bin')
        print("    File: net.bin, size: {}".format(size_net_file))
        