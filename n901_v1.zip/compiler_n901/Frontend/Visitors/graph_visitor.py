
from typing import Dict, List
from Frontend.Node.node_def import NodeOpType
from Backend.ComputationNode.computation_node_def import NodeType, CpuOpcode
import struct
import os
import pdb
import json

class GraphVisitor(object):
    def __init__(self):
        pass

    def topo_sort(self, Graph) -> List:
        """this is an implementation of dfs algorithm
        
        it generates a topological sort list from a Directed Acyclic Graph(DAC)
        constructed directly by nodes which are connected to each other through
        reference method

        Args:
            toposort: list type, contains results of topological sorts(contents are
            references of nodes), they also present the "removed" nodes
            visited: list type, contains nodes which have been visited, every node
            will be visited only once
        
        return:
            a list contains nodes after topological sort
        """
        toposort = []
        visited = []
        for node in Graph.inputs:
            self._visit(node, visited, toposort)
        # self._display_sorted_node(toposort)
        # self._display_concat_node(toposort)
        # pdb.set_trace()
        # self.display_node_iobitwidth(toposort)
        return toposort

    def _visit(self, node, visited, toposort):
        visited.append(node)
        for i in node.children:
            if i not in visited:
                self._visit(i, visited, toposort)
        toposort.insert(0, node)

    def _display_sorted_node(self, node_list):
        print('-----toposorted nodes-----')
        for i in range(len(node_list)):
            node = node_list[i]
            print('-----')
            print('Execute index:', i)
            print('node index:', node.index)
            print('node type:', node.type)
            print('op_type:', node.op_type)
            print('node name:', node.name)
            print('parent:', node.parents)
            print('children:', node.children)
            if node.op_type == NodeOpType.HardwareFusionNode:
                print('sub-nodes')
                for sub_node in node.sub_node_list:
                    print('\t-----')
                    print('\tnode index:', sub_node.index)
                    print('\tnode type:', sub_node.type)
                    print('\top_type:', sub_node.op_type)
                    print('\tnode name:', sub_node.name)

    def _display_shift_node(self, node_list):
        print('-----shift nodes-----')
        for i in range(len(node_list)):
            node = node_list[i]
            if node.op_type == NodeOpType.ShiftNode:
                print('-----')
                print('node index:', node.index)
                print('node type:', node.type)
                print('op_type:', node.op_type)
                print('node name:', node.name)
                print('parent:')
                print('\t', node.parents)
                print('children:')
                print('\t', node.children)
                print('shift_param')
                print(node.shift_param)

    def _display_concat_node(self, node_list):
        print('-----concat nodes-----')
        for i in range(len(node_list)):
            node = node_list[i]
            if node.op_type == NodeOpType.ConcatNode:
                print('-----')
                print('node index:', node.index)
                print('node type:', node.type)
                print('op_type:', node.op_type)
                print('node name:', node.name)
                print('parent:')
                print('\t', node.parents)
                print('children:')
                print('\t', node.children)
                x0_radix = node.hardware_info['x0_radix']
                x1_radix = node.hardware_info['x1_radix']
                y_radix = node.hardware_info['y_radix']
                print('x0_radix: {}' .format(x0_radix[0]))
                print('x1_radix: {}' .format(x1_radix[0]))
                print('y_radix: {}' .format(y_radix[0]))
    
    def display_node_iobitwidth(self, node_list):
        for node in node_list:
            if(node.op_type in [NodeOpType.InputNode, NodeOpType.OutputNode]):
                continue
            print("node name: %s, inputbitwidth: %d, outputbitwidth: %d" % (node.name, node.hardware_info["input_bitwidth"], node.hardware_info["output_bitwidth"]))
    
    def write_datanode_map_bin(self, compu_node_list, result_path):
        map_dict = {}
        golden_index = 0
        for i in range(len(compu_node_list)):
            node = compu_node_list[i]
            if node.node_type == NodeType.CpuType:
                if node.cpu_optype == CpuOpcode.DODMA:
                    datanode_index = node.datanode_out.index
                    if datanode_index not in list(map_dict.values()):
                        map_dict[golden_index] = datanode_index
                        golden_index += 1
        map_bin_file = os.path.join(result_path, 'map.bin')
        with open(map_bin_file, 'wb') as f_bin:
            for i in range(len(list(map_dict.keys()))):
                f_bin.write(struct.pack(">I", int(i)))
                f_bin.write(struct.pack(">I", int(map_dict[i])))
    def write_hf_map_json(self, cmd_node_list, result_path):
        cmd_dict = {}
        for i in range(len(cmd_node_list)):
            cmd_id= i
            cmd_node = cmd_node_list[i]
            hf_dict = {}
            for j in range(len(cmd_node.contents.node_list)):
                hardware_id = j
                key = ['name','col','row','channel','row_st','row_ed']
                hardwarefusion = cmd_node.contents.node_list[j]
                if hardwarefusion.op_type._name_ == 'AddNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'UpsampleNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'ConvNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'ConcatNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'LeakyReluNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'MaxPoolNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'L2NormalizationNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'BatchNormalizationNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'NormalReluNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'AveragePoolNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'PReluNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'ClipNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'MishNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'SiluNode':
                    name = hardwarefusion.name
                elif hardwarefusion.op_type._name_ == 'BypassNode':
                    name = hardwarefusion.name
                else:
                    name = hardwarefusion.sub_node_list[-1].name
                col = hardwarefusion.shape[3]
                row = hardwarefusion.shape[2]
                channel = hardwarefusion.shape[1]
                
                for k in range(len(cmd_node.contents.output_chunk)):
                    output_chunk = cmd_node.contents.output_chunk[k]
                    if j == k:
                        n = cmd_node.chunk_id
                        row_st = output_chunk[n]['row_st']
                        row_ed = output_chunk[n]['row_ed']
                    else:
                        continue
                values = [name, col, row, channel, row_st, row_ed]
                a_dict = {key[x]:values[x] for x in range(len(values))}
                hf_dict.setdefault(hardware_id, a_dict) 
            cmd_dict.setdefault(cmd_id, hf_dict)
        hf_map_json = json.dumps(cmd_dict, sort_keys=False, 
            indent=4, separators=(',', ': '))
        hf_map_json_file = os.path.join(result_path, "hf_map.json")
        with open(hf_map_json_file, 'w') as f_map:
            f_map.write(hf_map_json)
        