from Frontend.Node.node_def import NodeOpType
import pdb
import json
import os
from Backend.CmdNode.MemoryManagement.compress_gen import CompressGenAgent
class DataNodeDictVisitor(object):
    def __init__(self):
        pass

    def write_datanode_map_json(self, datanode_dict, result_path):
        map_dict = {}
        for node in datanode_dict.keys():
            ## input node not included
            if node.op_type == NodeOpType.InputNode:
                continue
            ## get name of layer
            if node.op_type == NodeOpType.HardwareFusionNode:
                ## get the name of the last subnode in hardware fusion node
                layer_name = node.sub_node_list[-1].name
            else:
                layer_name = node.name
            if layer_name[-1] == ')':
                while len(layer_name) and layer_name[-1] != '(':
                    layer_name = layer_name[:-1]
                layer_name = layer_name[:-1]            
            ## get datanode index
            index = datanode_dict[node].index
            ## add this map to dict
            map_dict[index] = layer_name
        map_json = json.dumps(map_dict, sort_keys=True, 
            indent=4, separators=(',', ': '))
        map_json_file = os.path.join(result_path, "map.json")
        with open(map_json_file, 'w') as f_map:
            f_map.write(map_json)

    def write_datanode_map_txt(self, datanode_dict, result_path):
        map_dict = {}
        for node in datanode_dict.keys():
            if node.op_type == NodeOpType.InputNode:
                continue
            if node.op_type == NodeOpType.HardwareFusionNode:    
                layer_name = node.sub_node_list[-1].name
            else:
                layer_name = node.name
            if layer_name[-1] == ')':
                while len(layer_name) and layer_name[-1] != '(':
                    layer_name = layer_name[:-1]
                layer_name = layer_name[:-1]            
            index = datanode_dict[node].index
            map_dict[index] = layer_name 
        map_tb_json = os.path.join(result_path, "map_tb.json")
        with open(map_tb_json,'w') as file:
            for key in map_dict:
                file.write('\n')
                file.writelines('   ' + str(key) + '   ' + str(map_dict[key]))

    def get_matched_node(self, datanode_dict, datanode):
        for node in datanode_dict.keys():
            if datanode_dict[node].index == datanode.index:
                return node

    def write_compressed_datanode_json(self, cmd_node_list, output_datanode_dict, result_path):
        compress = CompressGenAgent(cmd_node_list, output_datanode_dict)
        compress.fill_datanode_list()
        compress.fill_burst_list()
        datanode_list = compress.datanode_list
        layer_dict = {}
        for datanode in datanode_list:
            burst_dict = {}
            for j in range(len(datanode.burst_list)):
                burst = datanode.burst_list[j]
                burst_id = j
                burst_row = []
                start_row = burst.start_row
                row_num = burst.end_row - burst.start_row + 1
                burst_row.append(start_row)
                burst_row.append(row_num)
                burst_dict.setdefault(j, burst_row)
            for cmd_node in cmd_node_list:
                for i in range(len(cmd_node.datanode_out)):     
                    datanode_out = cmd_node.datanode_out[i]
                    if datanode_out == datanode:
                        hwf = cmd_node.contents.node_list[-1]
                        if hwf.op_type._name_ == 'AddNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'UpsampleNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'ConvNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'ConcatNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'LeakyReluNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'MaxPoolNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'L2NormalizationNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'BatchNormalizationNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'NormalReluNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'AveragePoolNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'PReluNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'ClipNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'MishNode':
                            layer_name = hwf.name
                        elif hwf.op_type._name_ == 'SiluNode':
                            layer_name = hwf.name
                        else:
                            layer_name = hwf.sub_node_list[-1].name
                        layer_dict.setdefault(layer_name, burst_dict)
        c_datanode_json = json.dumps(layer_dict, sort_keys=False, 
            indent=4, separators=(',', ': '))
        c_datanode_json_file = os.path.join(result_path, "compressed_datanode.json")
        with open(c_datanode_json_file, 'w') as file:
            file.write(c_datanode_json)