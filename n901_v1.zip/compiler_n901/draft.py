str_list = [i for i in range(5)]
str_list_2 = [str_list[i] for i in range(5)]
print(str_list_2)


