from locale import RADIXCHAR
from urllib.parse import _ResultMixinStr
from Backend.CmdNode.MemoryManagement.WeightGeneration.common_functions import Weight
from Frontend.Node.node_def import NodeOpType
from ..weight_gen import WeightGenAgent
import numpy as np
import os
import math
import struct
e = math.e

def tanh(x):
    return (e**x - e**(-x)) / (e**x + e**(-x))

def softplus(x):
    return math.log(1 + pow(e, x))

def mish(x):
    return x * tanh(softplus(x))

def sigmoid(x):
    return 1 / (1 + e**(-x))

def silu(x):
    return x * sigmoid(x)

class LutDataGenAgent(object):
    def __init__(self):
        self.bank_tot_num = 16
        self.bank_num = {16: 16, 14: 4, 12: 1}
        self.sram_depth = 4096
        self.lutmode_set = set()

    def fill_lut_data(self, cmd_node_list, result_path, pdma_byte_num, cpu_node_byte_num):
        dram_weight_file_path = os.path.join(result_path, "dram_weight.bin")
        weight_file_path = os.path.join(result_path, "weight.bin")
        WeightGenAgent()._dram_weight_gen(weight_file_path, dram_weight_file_path, pdma_byte_num, cpu_node_byte_num)
        lut_bin_file_path = os.path.join(result_path, "lut.bin")
        lut_origin_bin_file_path = os.path.join(result_path, "lut_origin.bin")
        f_lut_origin = open(lut_origin_bin_file_path, "wb+")
        f_lut = open(lut_bin_file_path, "wb+")
        for cmd_node in cmd_node_list:
            if(cmd_node.type == "CPUType"):
                continue
            self.gen_lut_data_cmd_node(cmd_node, f_lut, f_lut_origin)
        f_lut.close()
        f_lut_origin.close()
        lut_reversed_bin_file_path = os.path.join(result_path, "lut_revered_tmp.bin")
        self.byte_reverse(lut_bin_file_path, lut_reversed_bin_file_path)
        f_lut = open(lut_bin_file_path, "rb")
        f_lut_tmp = open(lut_reversed_bin_file_path, "rb") 
        f_weight = open(weight_file_path, "ab+")
        f_dram_weight = open(dram_weight_file_path, "ab+")
        lut_bin_file_size = os.path.getsize(lut_bin_file_path)
        f_weight.write(f_lut_tmp.read(lut_bin_file_size))
        f_dram_weight.write(f_lut.read(lut_bin_file_size))                
        f_weight.close()
        f_dram_weight.close()
        f_lut.close()
        f_lut_tmp.close()
        os.remove(lut_reversed_bin_file_path)
        os.remove(lut_bin_file_path)
        os.remove(lut_origin_bin_file_path)
    
    def gen_lut_data_cmd_node(self, cmd_node, f_lut, f_lut_origin):
        for lnode in cmd_node.lutnode:
            lutmode = str(lnode.func_type) + "_" + str(lnode.x_radix) + "_" + str(lnode.y_radix) + "_" + str(lnode.input_bitwidth)
            if(lutmode in self.lutmode_set):
                continue
            self.lutmode_set.add(lutmode)
            self.gen_lut_data_lut_node(lnode, f_lut, f_lut_origin)
    
    def gen_lut_data_lut_node(self, lutnode, f_lut, f_lut_origin):
        x_radix = lutnode.x_radix
        y_radix = lutnode.y_radix
        overflow_upper = 2 ** 15 - 1
        overflow_lower = -2 ** 15
        input_bitwidth = lutnode.input_bitwidth
        if(lutnode.func_type == 0):
            func_type = "Mish"
        elif(lutnode.func_type == 1):
            func_type = "Silu"
        else:
            assert(False), "Unsurpported Func Type!!"
        lookup_table = {}
        x_max = 2 ** (input_bitwidth - 1)
        for fp_x in range(-x_max, x_max):
            float_x = fp_x / 2 ** x_radix
            if(func_type == "Mish"):
                float_y = mish(float_x)
            else:
                float_y = silu(float_x)
            fp_y = np.round(float_y * 2 ** y_radix)
            if(fp_y > overflow_upper):
                fp_y = overflow_upper
            if(fp_y < overflow_lower):
                fp_y = overflow_lower
            lookup_table[fp_x] = fp_y
        self.address_lut_data(lookup_table, input_bitwidth, f_lut, f_lut_origin)
    
    def address_lut_data(self, lut_dict, input_bitwidth, f_lut, f_lut_origin):
        lut = np.zeros((self.bank_tot_num, self.sram_depth))
        for key, value in lut_dict.items():
            x, y = key >> 12, key & (2 ** 12 - 1)
            for rep in range(0, self.bank_tot_num // self.bank_num[input_bitwidth]):
                lut[rep * self.bank_num[input_bitwidth] + x, y] = value

        lut_reorg = np.zeros((self.bank_tot_num, self.sram_depth))
        old_x, old_y = 0, 0
        reorg_x, reorg_y = 0, 0
        for _ in range(0, lut.size // 2):
            ele1 = lut[old_x, old_y]
            old_x += 1
            ele2 = lut[old_x, old_y]
            old_x += 1
            if old_x % 8 == 0:
                old_x -= 8
                old_y += 1
                if old_y == 4096:
                    old_x = 8
                    old_y = 0
            lut_reorg[reorg_x, reorg_y] = ele2
            reorg_y += 1
            lut_reorg[reorg_x, reorg_y] = ele1
            reorg_y += 1
            if reorg_y == 4096:
                reorg_y, reorg_x = 0, reorg_x + 1

        for i in range(self.bank_tot_num):
            for j in range(self.sram_depth):
                val_w = struct.pack(">h", int(lut_reorg[i, j]))
                val_w_origin = struct.pack(">h", int(lut[i, j]))
                f_lut.write(val_w)
                f_lut_origin.write(val_w_origin)
    
    def byte_reverse(self, file_in, file_out):
        file_size = os.path.getsize(file_in)
        f_in, f_out = open(file_in, "rb"), open(file_out, "wb+")
        reverse_unit = 16
        for _ in range(int(file_size/reverse_unit)):
            buffer_byte = []
            for _ in range(reverse_unit):
                buffer_byte.append(f_in.read(1))
            for i in range(reverse_unit - 1, -1, -1):
                f_out.write(buffer_byte[i])
        f_in.close()
        f_out.close()