import math
import numpy as np
import pdb
import sys

from Frontend.HWToolBox.N900HWToolBox import N900HWToolBox
from Frontend.Node.node_def import NodeOpType
from Backend.CmdNode.MemoryManagement.WeightGeneration.gen_w_shift_bias_nl_bytes import GenWeightShiftBiasNlBytes
from Backend.CmdNode.MemoryManagement.WeightGeneration.gen_weight_chunk_bytes import GenWeightChunkBytes

class WriteWeightBin(object):
    def __init__(self, Hwbitwidth_info):
        self.Hwbitwidth_info = Hwbitwidth_info

    def write_weight_bin(self, weight, sub_node_list, f_weight):
        # print('-----')
        # for sub_node in sub_node_list:
        #     print('node index:', sub_node.index)
        #     print('node type:', sub_node.type)
        #     print('op_type:', sub_node.op_type)
        #     print('node name:', sub_node.name)
        och = sub_node_list[-1].shape[1]
        first_node = sub_node_list[0]
        #weight.bin generation
        if (first_node.op_type == NodeOpType.ConvNode):
            if ('group' in first_node.conv_param.keys()
                and first_node.conv_param['group'] != 1):
                ## depthwise conv
                self._write_conv_dw_weight(sub_node_list, weight, f_weight)
            else:
                if weight.kernel_weight.shape[0: 2] == (3, 3):
                    if weight.kernel_weight.shape[2] <= 4:
                        self._write_conv_3x3rgba_weight(first_node, weight, f_weight)
                    else:
                        ##CONV_3x3RGBA
                        self._write_conv_3x3_weight(first_node, weight, f_weight)
                elif weight.kernel_weight.shape[0: 2] == (1, 1):
                    ## CONV_1x1
                    ich = weight.kernel_weight.shape[2]
                    if ich > 2048:
                        self._write_large_ich_conv1x1_weight(first_node, weight, f_weight)
                    else:
                        self._write_conv_1x1_weight(first_node, weight, f_weight)
                else:
                    print("Error weight kernel size !")
                    sys.exit()
        elif (first_node.op_type == NodeOpType.AddNode and N900HWToolBox().is_DIDMA_Add(first_node) == False):
            ## ELE_ADD mode
            self._write_ele_add_weight(sub_node_list, weight, och, f_weight)
        else:
            ## BYPASS mode
            self._write_bypass_weight(sub_node_list, weight, och, f_weight)

    def _write_bypass_weight(self, sub_node_list, weight, och, f_weight):
        input_bw = sub_node_list[0].hardware_info['input_bitwidth']
        output_bw = sub_node_list[-1].hardware_info['output_bitwidth']
        pool_en = False
        for node in sub_node_list:
            if node.op_type in [NodeOpType.MaxPoolNode, NodeOpType.AveragePoolNode]:
                pool_en = True
        if not pool_en:
            if  input_bw == 16:
                f_32_num = math.ceil(och/32)
                for curr_f_32 in range(f_32_num):
                    f_st = 32 * curr_f_32
                    f_ed = f_st + 32
                    for i in range(2):
                        f_st1=f_st + 16*i 
                        f_ed1=f_ed - 16*(1-i)
                        w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st1, f_ed1)
                        f_weight.write(w_shift_bias_nl)
            else:
                f_64_num = math.ceil(och/64)
                for curr_f_64 in range(f_64_num):
                    f_st = 64 * curr_f_64
                    f_ed = f_st + 64
                    for i in range(4):
                        f_st1=f_st + 16*i 
                        f_ed1=f_ed - 16*(3-i)
                        w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st1, f_ed1)
                        f_weight.write(w_shift_bias_nl)
        else:
            f_16_num = math.ceil(och/16)
            for curr_f_16 in range(f_16_num):
                f_st = 16 * curr_f_16
                f_ed = f_st + 16
                w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st, f_ed)
                f_weight.write(w_shift_bias_nl)

    def _write_ele_add_weight(self, sub_node_list, weight, och, f_weight):
        input_bw = sub_node_list[0].hardware_info['input_bitwidth']
        output_bw = sub_node_list[-1].hardware_info['output_bitwidth']
        pool_en = False
        for node in sub_node_list:
            if node.op_type in [NodeOpType.MaxPoolNode, NodeOpType.AveragePoolNode]:
                pool_en = True
        if  not pool_en:
            if  input_bw == 16:
                f_32_num = math.ceil(och/32)
                for curr_f_32 in range(f_32_num):
                    f_st = 32 * curr_f_32
                    f_ed = f_st + 32
                    for i in range(2):
                        f_st1=f_st + 16*i 
                        f_ed1=f_ed - 16*(1-i)
                        w_add_shift = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_add_shift(weight, f_st1, f_ed1)
                        f_weight.write(w_add_shift)
                    for i in range(2):
                        f_st1=f_st + 16*i
                        f_ed1=f_ed - 16*(1-i)
                        w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st1, f_ed1)
                        f_weight.write(w_shift_bias_nl)
            else:
                f_64_num = math.ceil(och/64)
                for curr_f_64 in range(f_64_num):
                    f_st = 64 * curr_f_64
                    f_ed = f_st + 64
                    for i in range(4):
                        f_st1=f_st + 16*i 
                        f_ed1=f_ed - 16*(3-i)
                        w_add_shift = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_add_shift(weight, f_st1, f_ed1)
                        f_weight.write(w_add_shift)
                    for i in range(4):
                        f_st1=f_st + 16*i 
                        f_ed1=f_ed - 16*(3-i)
                        w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st1, f_ed1)
                        f_weight.write(w_shift_bias_nl)
        else:
            f_16_num = math.ceil(och/16)
            for curr_f_16 in range(f_16_num):
                f_st = 16 * curr_f_16
                f_ed = f_st + 16
                w_add_shift = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_add_shift(weight, f_st, f_ed)
                f_weight.write(w_add_shift)
                w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st, f_ed)
                f_weight.write(w_shift_bias_nl)

    def _write_conv_dw_weight(self, sub_node_list, weight, f_weight):
        input_bw = sub_node_list[0].hardware_info['input_bitwidth']
        output_bw = sub_node_list[-1].hardware_info['output_bitwidth']
        pool_en = False
        for node in sub_node_list:
            if node.op_type in [NodeOpType.MaxPoolNode, NodeOpType.AveragePoolNode]:
                pool_en = True
        ## weight.shape = (3, 3, och)
        och = weight.kernel_weight.shape[2]
        if  not pool_en:
            if input_bw == 16:
                f_32_num = math.ceil(och/32)
                for curr_f_32 in range(f_32_num):
                    f_st = 32 * curr_f_32
                    f_ed = f_st + 32
                    if curr_f_32 == f_32_num - 1:
                        f_ed = och
                    w_32f = GenWeightChunkBytes().gen_3x3dw_w_kernel_byte(weight.kernel_weight[:, :, f_st: f_ed], 32)
                    f_weight.write(w_32f)
                    for i in range(2):
                        f_st1=f_st + 16*i 
                        f_ed1=f_ed - 16*(1-i)
                        w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st1, f_ed1)
                        f_weight.write(w_shift_bias_nl)
            else:
                f_64_num = math.ceil(och/64)
                for curr_f_64 in range(f_64_num):
                    f_st = 64 * curr_f_64
                    f_ed = f_st + 64
                    if curr_f_64 == f_64_num - 1:
                        f_ed = och
                    w_64f = GenWeightChunkBytes().gen_3x3dw_w_kernel_byte(weight.kernel_weight[:, :, f_st: f_ed], 64)
                    f_weight.write(w_64f)
                    for i in range(4):
                        f_st1=f_st + 16*i 
                        f_ed1=f_ed - 16*(3-i)
                        w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st1, f_ed1)
                        f_weight.write(w_shift_bias_nl)
        else :
            f_16_num = math.ceil(och/16)
            for curr_f_16 in range(f_16_num):
                f_st = 16 * curr_f_16
                f_ed = f_st + 16
                if curr_f_16 == f_16_num - 1:
                    f_ed = och
                w_32ch_16f = GenWeightChunkBytes().gen_3x3dw_w_kernel_byte(weight.kernel_weight[:, :, f_st: f_ed], 16)
                f_weight.write(w_32ch_16f)
                w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st, f_ed)
                f_weight.write(w_shift_bias_nl)

    def _write_conv_3x3_weight(self, first_node, weight, f_weight):
        input_bw = first_node.hardware_info['input_bitwidth']
        (kernel_row, kernel_col, ich, och) = np.shape(weight.kernel_weight)
        #weight.shape = (3, 3, reg.ich, och)
        f_16_num = math.ceil(och/16)
        for curr_f_16 in range(f_16_num):
            f_st = 16 * curr_f_16
            f_ed = f_st + 16
            if curr_f_16 == f_16_num - 1:
                f_ed = och
            if input_bw == 16:
                ch_32_num = math.ceil(ich/32)
                for curr_ch_32 in range(0, ch_32_num):
                    ch_st = 32 * curr_ch_32
                    ch_ed = ch_st + 32
                    if curr_ch_32 == ch_32_num - 1:
                        ch_ed = ich
                    w_32ch_16f = GenWeightChunkBytes().gen_3x3_w_kernel_byte(weight.kernel_weight[:, :, ch_st: ch_ed, f_st: f_ed], 32)
                    f_weight.write(w_32ch_16f)
                    if(curr_ch_32 == 0):
                        w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st, f_ed)
                        f_weight.write(w_shift_bias_nl)
            else:
                ch_64_num = math.ceil(ich/64)
                for curr_ch_64 in range(0, ch_64_num):
                    ch_st = 64 * curr_ch_64
                    ch_ed = ch_st + 64
                    if curr_ch_64 == ch_64_num - 1:
                        ch_ed = ich
                    w_64ch_16f = GenWeightChunkBytes().gen_3x3_w_kernel_byte(weight.kernel_weight[:, :, ch_st: ch_ed, f_st: f_ed], 64)
                    f_weight.write(w_64ch_16f)
                    if(curr_ch_64 == 0):
                        w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st, f_ed)
                        f_weight.write(w_shift_bias_nl)

    def _write_conv_3x3rgba_weight(self, first_node, weight, f_weight):
        (kernel_row, kernel_col, ich, och) = np.shape(weight.kernel_weight)
        #weight.shape = (3, 3, reg.ich, och)
        f_16_num = math.ceil(och/16)
        for curr_f_16 in range(f_16_num):
            f_st = 16 * curr_f_16
            f_ed = f_st + 16
            if curr_f_16 == f_16_num - 1:
                f_ed = och
            w_16f = GenWeightChunkBytes().gen_3x3rgba_w_kernel_byte(weight.kernel_weight[:, :, :, f_st: f_ed])
            f_weight.write(w_16f)
            w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st, f_ed)
            f_weight.write(w_shift_bias_nl)

    def _write_large_ich_conv1x1_weight(self, first_node, weight, f_weight):
        input_bw = first_node.hardware_info['input_bitwidth']
        (kernel_row, kernel_col, ich, och) = np.shape(weight.kernel_weight)
        f_16_num = math.ceil(och/16)
        c_2048_num = math.ceil(ich/2048)
        # pdb.set_trace()
        for curr_f_16 in range(f_16_num):
            f_st = 16 * curr_f_16
            f_ed = f_st + 16
            if curr_f_16 == f_16_num - 1:
                f_ed = och
            if input_bw == 16:
                for curr_ch_2048 in range(c_2048_num):
                    ch_32_num = math.ceil(2048/32)
                    for curr_ch_32 in range(0, ch_32_num):
                        ch_st = 32 * curr_ch_32 + curr_ch_2048 * 2048
                        ch_ed = ch_st + 32
                        if curr_ch_32 == ch_32_num - 1 and curr_ch_2048 == 0:
                            ch_ed = 2048
                        elif curr_ch_32 == ch_32_num - 1 and curr_ch_2048 == c_2048_num - 1:
                            ch_ed == ich
                        w_32ch_16f = GenWeightChunkBytes().gen_1x1_w_kernel_byte(weight.kernel_weight[0,0, ch_st: ch_ed, f_st: f_ed], 32)
                        f_weight.write(w_32ch_16f)
                        if curr_ch_32 == 0 and curr_ch_2048 != c_2048_num - 1:
                            w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st, f_ed)
                            f_weight.write(w_shift_bias_nl)
                        elif curr_ch_32 == 0 and curr_ch_2048 == c_2048_num - 1:
                            w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st, f_ed)
                            f_weight.write(w_shift_bias_nl)
            else:
                for curr_ch_2048 in range(c_2048_num):
                    ch_64_num = math.ceil(2048/64)
                    for curr_ch_64 in range(0, ch_64_num):
                        ch_st = 64 * curr_ch_64 + curr_ch_2048 * 2048
                        ch_ed = ch_st + 64
                        if curr_ch_64 == ch_64_num - 1 and curr_ch_2048 == 0:
                            ch_ed = 2048
                        elif curr_ch_64 == ch_64_num - 1 and curr_ch_2048 == c_2048_num - 1:
                            ch_ed = ich
                        w_64ch_16f = GenWeightChunkBytes().gen_1x1_w_kernel_byte(weight.kernel_weight[0,0, ch_st: ch_ed, f_st: f_ed], 64)
                        f_weight.write(w_64ch_16f)
                        if curr_ch_64 == 0 and curr_ch_2048 != c_2048_num - 1:
                            w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st, f_ed)
                            f_weight.write(w_shift_bias_nl)
                        elif curr_ch_64 == 0 and curr_ch_2048 == c_2048_num - 1:
                            w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st, f_ed)
                            f_weight.write(w_shift_bias_nl)
                    
    def _write_conv_1x1_weight(self, first_node, weight, f_weight):
        input_bw = first_node.hardware_info['input_bitwidth']
        (kernel_row, kernel_col, ich, och) = np.shape(weight.kernel_weight)
        #weight.shape = (reg.ich, och)
        f_16_num = math.ceil(och/16)
        for curr_f_16 in range(f_16_num):
            f_st = 16 * curr_f_16
            f_ed = f_st + 16
            if curr_f_16 == f_16_num - 1:
                f_ed = och
            if input_bw == 16:
                ch_32_num = math.ceil(ich/32)
                for curr_ch_32 in range(0, ch_32_num):
                    ch_st = 32 * curr_ch_32
                    ch_ed = ch_st + 32
                    if curr_ch_32 == ch_32_num - 1:
                        ch_ed = ich
                    w_32ch_16f = GenWeightChunkBytes().gen_1x1_w_kernel_byte(weight.kernel_weight[0, 0, ch_st: ch_ed, f_st: f_ed], 32)
                    f_weight.write(w_32ch_16f)
                    if(curr_ch_32 == 0):
                        w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st, f_ed)
                        f_weight.write(w_shift_bias_nl)
            else:
                ch_64_num = math.ceil(ich/64)
                for curr_ch_64 in range(0, ch_64_num):
                    ch_st = 64 * curr_ch_64
                    ch_ed = ch_st + 64
                    if curr_ch_64 == ch_64_num - 1:
                        ch_ed = ich
                    w_64ch_16f = GenWeightChunkBytes().gen_1x1_w_kernel_byte(weight.kernel_weight[0, 0, ch_st: ch_ed, f_st: f_ed], 64)
                    f_weight.write(w_64ch_16f)
                    if(curr_ch_64== 0):
                        w_shift_bias_nl = GenWeightShiftBiasNlBytes(self.Hwbitwidth_info).gen_w_shift_bias_nl_bytes(weight, f_st, f_ed)
                        f_weight.write(w_shift_bias_nl)

