import numpy as np
import math
from Frontend.Node.node_def import NodeOpType
from Backend.CmdNode.MemoryManagement.WeightGeneration.common_functions import CommonFunctions
from Frontend.HWToolBox.N900HWToolBox import N900HWToolBox

import pdb

class GenWeightToolbox(object):
    def __init__(self):
        pass

    def gen_truncate_shift(self, curr_node, weight, init_och):
        trun_s_node = [NodeOpType.MaxPoolNode, NodeOpType.AveragePoolNode, NodeOpType.PReluNode, NodeOpType.ClipNode, NodeOpType.NormalReluNode,
                    NodeOpType.LeakyReluNode, NodeOpType.UpsampleNode, NodeOpType.TruncaterNode]
        if curr_node.op_type in trun_s_node:
            x_radix, y_radix = curr_node.hardware_info['x_radix'], curr_node.hardware_info['y_radix']
            truncate_shift = [(x_radix[0] - y_radix[0]) for i in range(init_och)]
        else:
            truncate_shift = [0 for i in range(init_och)]
        weight.truncate_shift = truncate_shift
        
    def gen_bypass_weight(self, curr_node, weight, init_och):
        x_radix = curr_node.hardware_info['x_radix']
        y_radix = curr_node.hardware_info['y_radix']
        och = curr_node.shape[1]
        # get c_shift
        if x_radix[0] - y_radix[0] < 0:
            c_shift = -4 * np.ones((init_och))
        else:
            c_shift = np.zeros((init_och))
        if c_shift[0] < -4 or c_shift[0] > 20:
            print('Error! c_shift out of range !')
            print('x_radix =', x_radix, 'y_radix =', y_radix, 'c_shift =', c_shift[0])
        # get f_shift
        f_shift = np.zeros((init_och))
        f_shift[0: och] = x_radix - c_shift[0: och] - y_radix
        if f_shift[0] < 0 or f_shift[0] > 15:
            print('Error! f_shift out of range !')
            print('x_radix =', x_radix, 'y_radix =', y_radix, 'c_shift =', c_shift[0], 'f_shift', f_shift[0])
        # convert true value to pattern of weight.bin
        c_shift = CommonFunctions().c_shift_value2bin(c_shift)
        weight.c_shift = c_shift
        weight.f_shift = f_shift

    def gen_add_weight(self, curr_node, weight, init_och):
        is_didma_add = N900HWToolBox().is_DIDMA_Add(curr_node)
        if is_didma_add == True:
            return
        x0_radix = curr_node.hardware_info['x0_radix']
        x1_radix = curr_node.hardware_info['x1_radix']
        y_radix = curr_node.hardware_info['y_radix']
        och = curr_node.shape[1]
        # get add shift
        add_shift = np.zeros(init_och)
        for c in range(och):
            add_shift[c] = x1_radix[c] - x0_radix[c]
            if abs(add_shift[c]) > 2:
                print('Error! add shift out of range!!')
                return
        # get c_shift
        if x0_radix[0] - y_radix[0] < 0:
            c_shift = -4 * np.ones((init_och))
        else:
            c_shift = np.zeros((init_och))
        if c_shift[0] < -4 or c_shift[0] > 20:
            print('Error! c_shift out of range !')
            print('x0_radix =', x0_radix, 'y_radix =', y_radix, 'c_shift =', c_shift[0])
        # get f_shift
        f_shift = np.zeros((init_och))
        f_shift[0: och] = x0_radix - c_shift[0: och] - y_radix
        if f_shift[0] < 0 or f_shift[0] > 15:
            print('Error! f_shift out of range !')
            print('x0_radix =', x0_radix, 'y_radix =', y_radix, 'c_shift =', c_shift[0], 'f_shift', f_shift[0])
        # convert true value to pattern of weight.bin
        add_shift = self.add_shift_value2bin(add_shift)
        c_shift = CommonFunctions().c_shift_value2bin(c_shift)
        weight.c_shift = c_shift
        weight.f_shift = f_shift
        weight.add_shift = add_shift

    def add_shift_value2bin(self, add_shift):
        add_shift += 2
        return add_shift

    def gen_bn_weight(self, curr_node, weight, init_och, och):
        bn_a_bitwidth = curr_node.hardware_info['bn_a_bitwidth']
        bn_b_bitwidth = curr_node.hardware_info['bn_b_bitwidth']
        x_radix = curr_node.hardware_info['x_radix']
        bn_a_radix = curr_node.hardware_info['bn_a_radix']
        bn_b_radix = curr_node.hardware_info['bn_b_radix']
        och = curr_node.shape[1]
        # get float parameter
        bn_gamma = curr_node.bn_gamma # list
        bn_beta = curr_node.bn_beta # list
        bn_mean = curr_node.bn_mean # list
        bn_var = curr_node.bn_var # list
        bn_epsilon = curr_node.bn_param['epsilon'] # one value
        # get bn_a
        bn_a = np.zeros((init_och))

        bn_a[0: och] = bn_gamma / np.sqrt(bn_var + bn_epsilon)
        for ch in range(och):
            bn_a[ch] = np.round(bn_a[ch] * 2 ** bn_a_radix[ch])
        bn_a = CommonFunctions().overflow_clamp(bn_a, bn_a_bitwidth)
        # get bn_b
        bn_b = np.zeros((init_och))
        bn_b[0: och] = bn_beta - bn_gamma * bn_mean / np.sqrt(bn_var + bn_epsilon)
        for ch in range(och):
            bn_b[ch] = np.round(bn_b[ch] * 2 ** bn_b_radix[ch])
        bn_b = CommonFunctions().overflow_clamp(bn_b, bn_b_bitwidth)
        # get bn_shift
        bn_shift = np.zeros((init_och))
        for ch in range(och):
            bn_shift[ch] = x_radix[0] + bn_a_radix[ch] - bn_b_radix[ch] - 8
        ## convert true value to pattern of weight.bin
        bn_shift = self.bn_shift_value2bin(bn_shift)
        
        # print("bn_a shape: ", end="")
        # print(bn_a.shape)
        weight.bn_a = bn_a
        weight.bn_b = bn_b
        weight.bn_shift = bn_shift

    def bn_shift_value2bin(self, bn_shift):
        error_shift_num = 0
        dict_bn_shift_value2bin = {-12: 0, -10: 1, -8: 2, -6: 3, -4: 4, -3: 5, -2: 6, 
            -1: 7, 0: 8, 1: 9, 2: 10, 3: 11, 4: 12, 6: 13, 8: 14, 10: 15}
        for ch in range(len(bn_shift)):
            if(bn_shift[ch] not in dict_bn_shift_value2bin.keys()):
                error_shift_num += 1
        if error_shift_num != 0:
            print('Error! bn_shift value out of range!')
            print('bn_shift:')
            print(bn_shift)
            return
        for ch in range(len(bn_shift)):
            bn_shift[ch] = dict_bn_shift_value2bin[bn_shift[ch]]
        return bn_shift

    def gen_conv_weight(self, curr_node, weight, init_och, sub_node_list):
        kernel_weight_bitwidth = curr_node.hardware_info['conv_bitwidth']['kernel']
        bias_bitwidth = curr_node.hardware_info['conv_bitwidth']['bias']
        y_radix = curr_node.hardware_info['y_radix']
        psum_radix = curr_node.hardware_info['psum_radix']
        x_radix = curr_node.hardware_info['x_radix']
        w_kernel_radix = curr_node.hardware_info['kernel_weight_radix']
        pool_en = False
        for node in sub_node_list:
            if node.op_type in [NodeOpType.MaxPoolNode, NodeOpType.AveragePoolNode]:
                pool_en = True
        # get kernel weight
        input_bitwidth = curr_node.hardware_info['input_bitwidth']
        if ('group' in curr_node.conv_param.keys()
            and curr_node.conv_param['group'] != 1):
            ## depthwise conv
            (kernel_row, kernel_col, ich, och) = curr_node.conv_weight.shape
            kernel_weight = np.zeros((kernel_row, kernel_col, init_och))
            for c in range(och):
                kernel_weight[:, :, c] = np.round(curr_node.conv_weight[:, :, 0, c] * 2 ** w_kernel_radix[c])
            kernel_weight = CommonFunctions().overflow_clamp(kernel_weight, kernel_weight_bitwidth)
        else:
            (kernel_row, kernel_col, ich, och) = np.shape(curr_node.conv_weight)
            node_ich = ich
            if ich <= 4:
                ich = 4
            else:
                if pool_en == False:
                    if input_bitwidth == 8:
                        ich = math.ceil(ich / 64) * 64
                    elif input_bitwidth == 16:
                        ich = math.ceil(ich / 32) * 32
                else:
                    ich = math.ceil(ich / 16) * 16
            
            kernel_weight = np.zeros((kernel_row, kernel_col, ich, init_och))
            for c in range(och):
                kernel_weight[:, :, 0:node_ich, c] = np.round(curr_node.conv_weight[:, :, :, c] * 2 ** w_kernel_radix[c])
            kernel_weight = CommonFunctions().overflow_clamp(kernel_weight, kernel_weight_bitwidth)
        # get bias
        bias = np.zeros((init_och))
        if type(curr_node.conv_bias) is np.ndarray and len(curr_node.conv_bias) > 0:        
            for c in range(och):
                bias[c] = np.round(curr_node.conv_bias[c] * (2 ** y_radix[c]))
            bias = CommonFunctions().overflow_clamp(bias, bias_bitwidth)
        # get coarse shift
        c_shift = np.zeros((init_och))
        for c in range(och):
            c_shift[c] = 4 * int(math.floor((x_radix[0] + w_kernel_radix[c] - psum_radix[c])/4))
            if c_shift[c] < -4 or c_shift[c] > 20:
                print('Coarse shift out of range, error occurred !')
                print('c_shift =', c_shift[c])
                return
        # get fine shift
        f_shift = np.zeros((init_och))
        for c in range(och):
            f_shift[c] = x_radix[0] + w_kernel_radix[c] - c_shift[c] - y_radix[c]
            while(f_shift[c] > 15):
                f_shift[c] -= 4
            if f_shift[c] < 0 or f_shift[c] > 15:
                print('Fine shift out of range, error occurred !')
                print('f_shift =', f_shift[c])
                return
        # convert true value to the pattern in weight.bin
        c_shift = CommonFunctions().c_shift_value2bin(c_shift)
        ## generate weight
        weight.kernel_weight = kernel_weight
        weight.bias = bias
        weight.c_shift = c_shift
        weight.f_shift = f_shift

    def gen_leaky_relu_weight(self, curr_node, weight, init_och):
        prelu_alpha_bitwidth = curr_node.hardware_info['leaky_relu_alpha']
        alpha_radix = curr_node.hardware_info['w_radix']
        och = curr_node.shape[1]
        # get prelu_alpha
        prelu_alpha = curr_node.leakyReLu_param['alpha'] * np.ones((init_och))
        for c in range(och):
            prelu_alpha[c] = np.round(prelu_alpha[c] * 2 ** alpha_radix[c])
        prelu_alpha = CommonFunctions().overflow_clamp(prelu_alpha, prelu_alpha_bitwidth)

        weight.prelu_alpha = prelu_alpha

    def gen_prelu_weight(self, curr_node, weight, init_och):
        prelu_alpha_bitwidth = curr_node.hardware_info['prelu_alpha']
        och = curr_node.shape[1]
        prelu_alpha = np.zeros((init_och))
        radix = 18 * np.ones((init_och))
        for c in range(och):
            prelu_alpha[c] = curr_node.PReLu_weight[c]
            prelu_alpha[c] = np.round(prelu_alpha[c] * 2 ** radix[c])
        prelu_alpha = CommonFunctions().overflow_clamp(prelu_alpha, prelu_alpha_bitwidth)
        weight.prelu_alpha = prelu_alpha

    def gen_relu6_weight(self, curr_node, weight, init_och):
        # relu6_th_bitwidth = curr_node.hardware_info['relu6_th_bitwidth']
        relu6_th_bitwidth = 16
        och = curr_node.shape[1]
        relu6_th = np.zeros((init_och))
        radix = np.zeros((init_och))
        for c in range(och):
            radix[c] = curr_node.hardware_info['x_radix'][c]
        for c in range(och):
            relu6_th[c] = curr_node.clip_param['max']
            relu6_th[c] = np.round(relu6_th[c] * 2 ** radix[c])
        relu6_th = CommonFunctions().overflow_clamp(relu6_th, relu6_th_bitwidth)
        weight.relu6_th = relu6_th
