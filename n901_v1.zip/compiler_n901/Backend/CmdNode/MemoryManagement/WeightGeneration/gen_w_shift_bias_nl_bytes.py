from Backend.CmdNode.MemoryManagement.WeightGeneration.common_functions import CommonFunctions
import pdb
import numpy as np

class GenWeightShiftBiasNlBytes(object):
    def __init__(self, Hwbitwidth_info):
        self.Hwbitwidth_info = Hwbitwidth_info

    def gen_w_add_shift(self, weight, f_st, f_ed):
        w_add_shift = bytes('','utf-8')
        w_1920_bit = []
        f_num = f_ed - f_st
        # print("f_st: %d f_ed: %d" % (f_st, f_ed))
        weight_chunk = self._get_weight_chunk(weight, f_st, f_ed)
        add_shift_bitwidth = 3
        for cu_row in range(4): # cu row
            bit_st = 0
            for f in range(4):
                if(4*cu_row+f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.add_shift[4*cu_row+f ])
                for bit_num in range(add_shift_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            while len(w_1920_bit) % 480 != 0:
                w_1920_bit.append(0)
        w_add_shift+= CommonFunctions().gen_240byte_from_1920bit_list(w_1920_bit)
        return w_add_shift
    
    def gen_init_w_shift_bias_nl(self, weight, f_st, f_ed):
        w_shift_bias_nl = bytes('','utf-8')
        w_1920_bit = []
        f_num = f_ed - f_st
        # print("f_st: %d f_ed: %d" % (f_st, f_ed))
        weight_chunk = CommonFunctions().init_weight(self.Hwbitwidth_info, f_num)
        c_shift_bitwidth = 3
        add_shift_bitwidth = 3
        f_shift_bitwidth = 4
        bn_shift_bitwidth = 4
        truncate_shift_bitwidth = 4
        for cu_row in range(4):# cu row
            bit_st = 0
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.c_shift[curr_f])
                for bit_num in range(c_shift_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #fine shift
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.f_shift[curr_f])
                for bit_num in range(f_shift_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #bias
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.bias[curr_f])
                if(val < 0):
                    val = 2 ** weight_chunk.bias_bitwidth + val
                for bit_num in range(weight_chunk.bias_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #bn_a
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.bn_a[curr_f])
                if(val < 0):
                    val = 2 ** weight_chunk.bn_a_bitwidth + val
                for bit_num in range(weight_chunk.bn_a_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #bn_b
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.bn_b[curr_f])
                if(val < 0):
                    val = 2 ** weight_chunk.bn_b_bitwidth + val
                for bit_num in range(weight_chunk.bn_b_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #bn_shift
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.bn_shift[curr_f])
                for bit_num in range(bn_shift_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #prelu_alpha
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.prelu_alpha[curr_f])
                for bit_num in range(weight_chunk.prelu_alpha_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #relu6_th
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.relu6_th[curr_f])
                if(val < 0):
                    val = 2 ** weight_chunk.relu6_th_bitwidth + val
                for bit_num in range(weight_chunk.relu6_th_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #truncate_shift
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.truncate_shift[curr_f])
                for bit_num in range(truncate_shift_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            while len(w_1920_bit) % 480 != 0:
                w_1920_bit.append(0)
        w_shift_bias_nl = CommonFunctions().gen_240byte_from_1920bit_list(w_1920_bit)
        return w_shift_bias_nl
    
    def gen_w_shift_bias_nl_bytes(self, weight, f_st, f_ed):
        w_shift_bias_nl = bytes('','utf-8')
        w_1920_bit = []
        f_num = f_ed - f_st
        # print("f_st: %d f_ed: %d" % (f_st, f_ed))
        weight_chunk = self._get_weight_chunk(weight, f_st, f_ed)
        c_shift_bitwidth = 3
        add_shift_bitwidth = 3
        f_shift_bitwidth = 4
        bn_shift_bitwidth = 4
        truncate_shift_bitwidth = 4
        # f_list = [0, 1, 2, 3, 4, 5, 6, 7......]
        #coarse shift
        for cu_row in range(4):# cu row
            bit_st = 0
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.c_shift[curr_f])
                for bit_num in range(c_shift_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #fine shift
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.f_shift[curr_f])
                for bit_num in range(f_shift_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #bias
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.bias[curr_f])
                if(val < 0):
                    val = 2 ** weight_chunk.bias_bitwidth + val
                for bit_num in range(weight_chunk.bias_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #bn_a
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.bn_a[curr_f])
                if(val < 0):
                    val = 2 ** weight_chunk.bn_a_bitwidth + val
                for bit_num in range(weight_chunk.bn_a_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #bn_b
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.bn_b[curr_f])
                if(val < 0):
                    val = 2 ** weight_chunk.bn_b_bitwidth + val
                for bit_num in range(weight_chunk.bn_b_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #bn_shift
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.bn_shift[curr_f])
                for bit_num in range(bn_shift_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #prelu_alpha
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.prelu_alpha[curr_f])
                for bit_num in range(weight_chunk.prelu_alpha_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #relu6_th
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.relu6_th[curr_f])
                if(val < 0):
                    val = 2 ** weight_chunk.relu6_th_bitwidth + val
                for bit_num in range(weight_chunk.relu6_th_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            #truncate_shift
            for f in range(4):
                curr_f = 4*cu_row+f
                if(curr_f >= f_num):
                    val = 0
                else:
                    val = int(weight_chunk.truncate_shift[curr_f])
                for bit_num in range(truncate_shift_bitwidth):
                    w_1920_bit.append((val >> bit_num) % 2)
                    bit_st += 1
            while len(w_1920_bit) % 480 != 0:
                w_1920_bit.append(0)
        w_shift_bias_nl = CommonFunctions().gen_240byte_from_1920bit_list(w_1920_bit)
        return w_shift_bias_nl
        
    def _get_weight_chunk(self, weight, f_st, f_ed):
        total_f_num = np.shape(weight.c_shift)[0]
        f_num = f_ed - f_st
        weight_chunk = CommonFunctions().init_weight(self.Hwbitwidth_info, f_num)
        weight_chunk.bias_bitwidth = weight.bias_bitwidth
        weight_chunk.bn_a_bitwidth = weight.bn_a_bitwidth
        weight_chunk.bn_b_bitwidth = weight.bn_b_bitwidth
        weight_chunk.prelu_alpha_bitwidth = weight.prelu_alpha_bitwidth
        weight_chunk.relu6_th_bitwidth = weight.relu6_th_bitwidth
        for curr_f in range(f_num):
            if f_st + curr_f < total_f_num:
                weight_chunk.c_shift[curr_f] = weight.c_shift[f_st + curr_f]
                weight_chunk.f_shift[curr_f] = weight.f_shift[f_st + curr_f]
                weight_chunk.add_shift[curr_f] = weight.add_shift[f_st + curr_f]
                weight_chunk.bias[curr_f] = weight.bias[f_st + curr_f]
                weight_chunk.bn_a[curr_f] = weight.bn_a[f_st + curr_f]
                # print("weight bn_a shape: ", end="")
                # print(weight.bn_a.shape)
                weight_chunk.bn_b[curr_f] = weight.bn_b[f_st + curr_f]
                weight_chunk.bn_shift[curr_f] = weight.bn_shift[f_st + curr_f]
                weight_chunk.prelu_alpha[curr_f] = weight.prelu_alpha[f_st + curr_f]
                weight_chunk.relu6_th[curr_f] = weight.relu6_th[f_st + curr_f]
                weight_chunk.truncate_shift[curr_f] = weight.truncate_shift[f_st + curr_f]
        return weight_chunk
