import math
import sys
import pdb
from Backend.CmdNode.MemoryManagement.WeightGeneration.common_functions import CommonFunctions

class GenWeightChunkBytes(object):
    def __init__(self):
        pass

    def gen_3x3_w_kernel_byte(self, w, ch_num):
        if ch_num == 32:
            w_byte = self.gen_3x3_w_kernel_32ch_byte(w)
        elif ch_num == 64:
            w_byte = self.gen_3x3_w_kernel_64ch_byte(w)
        else:
            print("Error 3x3 kernel channel chunk!")
            sys.exit()
        return w_byte

    def gen_1x1_w_kernel_byte(self, w, ch_num):
        if ch_num == 32:
            w_byte = self.gen_1x1_w_kernel_32ch_byte(w)
        elif ch_num == 64:
            w_byte = self.gen_1x1_w_kernel_64ch_byte(w)
        else:
            print("Error 1x1 kernel channel chunk!")
            sys.exit()
        return w_byte

    def gen_3x3dw_w_kernel_byte(self, w, ch_num):
        if ch_num == 16:
            w_byte = self.gen_3x3dw_w_kernel_16ch_byte(w)
        elif ch_num == 32:
            w_byte = self.gen_3x3dw_w_kernel_32ch_byte(w)
        elif ch_num == 64:
            w_byte = self.gen_3x3dw_w_kernel_64ch_byte(w)
        else:
            print("Error 3x3dw kernel channel chunk!")
            sys.exit()
        return w_byte

    def gen_3x3_w_kernel_32ch_byte(self, w):
        w_32ch_16f = bytes('', 'utf-8')
        #row = 3, col = 3, channel <= 32, feature <= 16
        (r, c, channel, feature) = w.shape
        # f_list = [0, 1, 2, 3, 4, 5, 6, 7......]
        # ch_list = [0, 1, 2, 3, 16, 17, 18, 19, 4, 5, 6, 7, 20, 21, 22, 23......]
        for f_2 in range(8):
            for col in range(3):
                w_1920_bit_list = []
                for cu_row in range(4):
                    for ch in range(8):
                        curr_ch = 4 * cu_row + ch % 4 + 16 * math.floor(ch / 4)
                        for f in range(2):
                            curr_f = 2 * f_2 + f
                            for row in range(3):
                                if(curr_ch >= channel or curr_f >= feature):
                                    val = 0
                                else:
                                    val = int(w[row, col, curr_ch, curr_f])
                                if(val < 0):
                                    val = 2 ** 10 + val
                                for bit_num in range(10):
                                    w_1920_bit_list.append((val >> bit_num) % 2)
                pass
                w_32ch_16f += CommonFunctions().gen_240byte_from_1920bit_list(w_1920_bit_list)
                pass
        return w_32ch_16f

    def gen_3x3_w_kernel_64ch_byte(self, w):
        w_64ch_16f = bytes('', 'utf-8')
        #row = 3, col = 3, channel <= 64, feature <= 16
        (r, c, channel, feature) = w.shape
        # f_list = [0, 1, 2, 3, 4, 5, 6, 7......]
        # ch_list = [0, 1, 2, 3, 16, 17, 18, 19, 4, 5, 6, 7, 20, 21, 22, 23......]
        for f_4 in range(4):
            for ch_32 in range(2):
                for f_2 in range(2):
                    for col in range(3):
                        w_1920_bit_list = []
                        for cu_row in range(4):
                            for ch in range(8):
                                curr_ch = 4 * cu_row + ch % 4 + 16 * math.floor(ch / 4) + 32 * ch_32 
                                for f in range(2):
                                    curr_f = 4 * f_4 + 2 * f_2 + f
                                    for row in range(3):
                                        if(curr_ch >= channel or curr_f >= feature):
                                            val = 0
                                        else:
                                            val = int(w[row, col, curr_ch, curr_f])
                                        if(val < 0):
                                            val = 2 ** 10 + val
                                        for bit_num in range(10):
                                            w_1920_bit_list.append((val >> bit_num) % 2)
                        pass
                        w_64ch_16f += CommonFunctions().gen_240byte_from_1920bit_list(w_1920_bit_list)
                        pass
        return w_64ch_16f


    def gen_3x3rgba_w_kernel_byte(self, w):
        w_4ch_16f = bytes('', 'utf-8')
        #row = 3, col = 3, channel <= 4, feature <= 16
        (r, c, channel, feature) = w.shape
        # f_list = [0, 1, 2, 3, 4, 5, 6, 7......]
        # ch_list = [0, 1, 2, 3]
        for f_4 in range(4):
            w_1920_bit = []
            for ch in range(4):
                curr_ch = ch
                for f in range(4):
                    curr_f = 4*f_4+f
                    for col in range(3):
                        for row in range(3):
                            if(curr_ch >= channel or curr_f >= feature):
                                val = 0
                            else:
                                val = int(w[row, col, curr_ch, curr_f])
                            if(val < 0):
                                val = 2 ** 10 + val
                            for bit_num in range(10):
                                w_1920_bit.append((val >> bit_num) % 2)
                while len(w_1920_bit) % 480 != 0:
                    w_1920_bit.append(0)
            w_4ch_16f += CommonFunctions().gen_240byte_from_1920bit_list(w_1920_bit)
            pass
        return w_4ch_16f

    def gen_1x1_w_kernel_32ch_byte(self, w):
        w_32ch_16f = bytes('', 'utf-8')
        #channel <= 32, feature <= 16
        (channel, feature) = w.shape
        # f_list = [0, 1, 2, 3, 4, 5, 6, 7......]
        # ch_list = [0, 1, 2, 3, 16, 17, 18, 19, 4, 5, 6, 7, 20, 21, 22, 23......]
        for f_4 in range(4):
            w_1920_bit = []
            for cu_row in range(4):
                for f in range(4):
                    curr_f = 4*f_4+f
                    for ch in range(8):
                        curr_ch = 4 * cu_row + ch % 4 + 16 * math.floor(ch / 4)
                        if(curr_ch >= channel or curr_f >= feature):
                            val = 0
                        else:
                            val = int(w[curr_ch, curr_f])
                        if(val < 0):
                            val = 2 ** 10 + val
                        for bit_num in range(10):
                            w_1920_bit.append((val >> bit_num) % 2)
                    # make up the nineth hole
                    val = 0
                    for bit_num in range(10):
                        w_1920_bit.append((val >> bit_num) % 2)
                while len(w_1920_bit) % 480 != 0:
                    w_1920_bit.append(0)
            w_32ch_16f += CommonFunctions().gen_240byte_from_1920bit_list(w_1920_bit)
        return w_32ch_16f

    def gen_1x1_w_kernel_64ch_byte(self, w):
        w_64ch_16f = bytes('', 'utf-8')
        #channel <= 64, feature <= 16
        (channel, feature) = w.shape
        # f_list = [0, 1, 2, 3, 4, 5, 6, 7......]
        # ch_list = [0, 1, 2, 3, 16, 17, 18, 19, 4, 5, 6, 7, 20, 21, 22, 23......]
        for f_4 in range(4):
            for ch_32 in range(2):
                w_1920_bit = []
                for cu_row in range(4):
                    for f in range(4):
                        curr_f = 4*f_4+f                   
                        for ch in range(8):
                            curr_ch = 4 * cu_row + ch % 4 + 16 * math.floor(ch / 4) + 32 * ch_32                     
                            if(curr_ch >= channel or curr_f >= feature):
                                val = 0
                            else:
                                val = int(w[curr_ch, curr_f])
                            if(val < 0):
                                val = 2 ** 10 + val
                            for bit_num in range(10):
                                w_1920_bit.append((val >> bit_num) % 2)
                        # make up the nineth hole
                        val = 0
                        for bit_num in range(10):
                            w_1920_bit.append((val >> bit_num) % 2)
                    while len(w_1920_bit) % 480 != 0:
                        w_1920_bit.append(0)
                w_64ch_16f += CommonFunctions().gen_240byte_from_1920bit_list(w_1920_bit)
        return w_64ch_16f

    def gen_3x3dw_w_kernel_16ch_byte(self, w):
        w_16f = bytes('', 'utf-8')
        #row = 3, col = 3, feature <= 16
        (row, col, feature) = w.shape
        w_1920_bit = []
        for f_4 in range(4):
            for f in range(4):
                curr_f = 4 * f_4 + f 
                for col in range(3):
                    for row in range(3):
                        if(curr_f >= feature):
                            val = 0
                        else:
                            val = int(w[row, col, curr_f])
                        if(val < 0):
                            val = 2 ** 10 + val
                        for bit_num in range(10):
                            w_1920_bit.append((val >> bit_num) % 2)
            while len(w_1920_bit) % 480 != 0:
                w_1920_bit.append(0)
        w_16f += CommonFunctions().gen_240byte_from_1920bit_list(w_1920_bit)
        return w_16f

    def gen_3x3dw_w_kernel_32ch_byte(self, w):
        w_32f = bytes('', 'utf-8')
        #row = 3, col = 3, feature <= 16
        (row, col, feature) = w.shape
        for i in range(2):
            w_1920_bit = []
            for f_4 in range(4):
                for f in range(4):
                    curr_f = 4 * f_4 + f + 16 *i
                    for col in range(3):
                        for row in range(3):
                            if(curr_f >= feature):
                                val = 0
                            else:
                                val = int(w[row, col, curr_f])
                            if(val < 0):
                                val = 2 ** 10 + val
                            for bit_num in range(10):
                                w_1920_bit.append((val >> bit_num) % 2)
                while len(w_1920_bit) % 480 != 0:
                    w_1920_bit.append(0)
            w_32f += CommonFunctions().gen_240byte_from_1920bit_list(w_1920_bit)
        return w_32f

    def gen_3x3dw_w_kernel_64ch_byte(self, w):
        w_64f = bytes('', 'utf-8')
        #row = 3, col = 3, feature <= 64
        (row, col, feature) = w.shape
        for i in range(4):
            w_1920_bit = []
            for f_4 in range(4):
                for f in range(4):
                    curr_f = 4 * f_4 + f + 16 *i
                    for col in range(3):
                        for row in range(3):
                            if(curr_f >= feature):
                                val = 0
                            else:
                                val = int(w[row, col, curr_f])
                            if(val < 0):
                                val = 2 ** 10 + val
                            for bit_num in range(10):
                                w_1920_bit.append((val >> bit_num) % 2)
                while len(w_1920_bit) % 480 != 0:
                    w_1920_bit.append(0)
            w_64f += CommonFunctions().gen_240byte_from_1920bit_list(w_1920_bit)
        return w_64f
