import numpy as np
import struct
import os
import math
import pdb
import time
import multiprocessing
from multiprocessing import Process
class CommonFunctions(object):
    def __init__(self):
        pass

    def overflow_clamp(self, np_arr_x, bitwidth):
        overflow = 2 ** (bitwidth - 1) - 1
        np_arr_x[np.where(np_arr_x > overflow)] = overflow
        np_arr_x[np.where(np_arr_x < -overflow - 1)] = -overflow - 1
        return np_arr_x

    def c_shift_value2bin(self, c_shift):
        c_shift = c_shift / 4 + 1
        return c_shift

    def init_weight(self, Hwbitwidth_info, och):
        # print("och: %d" % (och))
        weight = Weight()
        weight.kernel_weight = 0
        weight.c_shift = np.ones((och))
        weight.f_shift = np.zeros((och))
        weight.bias = np.zeros((och))
        weight.add_shift = np.zeros((och))
        weight.bn_a = np.zeros((och))
        weight.bn_b = np.zeros((och))
        weight.bn_shift = np.zeros((och))
        weight.prelu_alpha = np.zeros((och))
        weight.relu6_th = np.zeros((och))
        weight.truncate_shift = np.zeros(och)
        weight.kernel_weight_bitwidth = Hwbitwidth_info['conv_bitwidth']['kernel']
        weight.bias_bitwidth = Hwbitwidth_info['conv_bitwidth']['bias']
        weight.bn_a_bitwidth = Hwbitwidth_info['bn_a_bitwidth']
        weight.bn_b_bitwidth = Hwbitwidth_info['bn_b_bitwidth']
        weight.prelu_alpha_bitwidth = Hwbitwidth_info['prelu_alpha']
        weight.relu6_th_bitwidth = Hwbitwidth_info['relu6_th_bitwidth']
        return weight
    
    def __get_frame_unicnt(self, process_cnt, frame_num):
        l, r = 0, frame_num
        while l < r:
            mid = (l + r + 1) // 2
            if mid * process_cnt > frame_num:
                r = mid - 1
            else:
                l =  mid
        return l
    
    def gen_240byte_from_1920bit_list(self, w_1920_bit_list):
        w_240byte = bytes('', 'utf-8')
        w_1920_bit_inv_list = []
        for i in range(192):
            for j in range(10):
                w_1920_bit_inv_list.insert(0, w_1920_bit_list[10 * i + (9 - j)])
        for num_8_bit in range(240):
            val = 0
            for num_1_bit in range(8):
                val += w_1920_bit_inv_list[1919 - (8 * num_8_bit + num_1_bit)] * 2 ** (7 - num_1_bit)
            val_w = struct.pack(">B", int(val))
            w_240byte += val_w
        return w_240byte

    def weight_bin_encoder(self, file_in, file_out):
        f_in = open(file_in, 'rb')
        f_out = open(file_out, 'ab')
        data_size = os.path.getsize(file_in)
        data_num = math.ceil(data_size * 8 / 10)
        assert(data_num % 64 == 0), "data num is {}".format(data_num)
        block_num = data_num // 64
        frame_num = math.ceil(block_num / 42)
        for i in range(frame_num):
            if i == frame_num - 1:
                curr_block_num = block_num - i * 42
            else:
                curr_block_num = 42
            header_val = 0
            for j in range(curr_block_num):
                header_val += 5 * 2 ** (3 * j)
            # write header
            val_w = struct.pack(">Q", int(header_val >> 64))
            f_out.write(val_w)
            val_w = struct.pack(">Q", int(header_val % (2 ** 64)))
            f_out.write(val_w)
            # write arranged data
            for j in range(curr_block_num):
                block_bit_list = [] #for one block of data with length of 640
                for k in range(80): #80 byte for 64 10-bit data
                    data_byte = f_in.read(1)
                    data_int = struct.unpack('>B', data_byte)
                    for m in range(8):
                        val_1bit = (int(data_int[0]) >> (7 - m)) % 2

                        block_bit_list.insert(0, val_1bit)
                for k in range(5):
                    data_128bit_int = 0
                    for m in range(64):
                        for n in range(2):
                            data_128bit_int += block_bit_list[10 * (63 - m) + 2 * k + n] * 2 ** (2 * m + n)
                    val_w = struct.pack(">Q", int(data_128bit_int >> 64))
                    f_out.write(val_w)
                    val_w = struct.pack(">Q", int(data_128bit_int % (2 ** 64)))
                    f_out.write(val_w)
        f_in.close()
        f_out.close()

    def weight_compress_bin(self, file_in, file_out, process_cnt = 1, result_path = '', is_Multi = False):
        f_in  = open(file_in, 'rb')
        f_out = open(file_out, 'ab')
        data_size = os.path.getsize(file_in)
        data_num = math.ceil(data_size * 8 / 10)
        block_num = data_num // 64
        frame_num = math.ceil(block_num / 42)
        if (is_Multi):
            process_cnt = min(process_cnt, frame_num)
            frame_unicnt = self.__get_frame_unicnt(process_cnt, frame_num)
            frame_cnt_list = [frame_unicnt for _ in range(process_cnt)]
            frame_total_num, frame_cnt_idx = frame_unicnt * process_cnt, 0
            while frame_total_num != frame_num:
                frame_cnt_list[0] += 1
                frame_total_num += 1
                frame_cnt_idx += 1
                if frame_cnt_idx >= process_cnt:
                    assert(False)
            tmp_file_in_list = []
            tmp_file_out_list = []
            f_in = open(file_in, "rb")
            for i in range(process_cnt):
                tmp_file_in_name = os.path.join(result_path, "compress_tmp_in_" + str(i))
                tmp_file_out_name = os.path.join(result_path, "compress_tmp_out_" + str(i))
                tmp_file_in_list.append(tmp_file_in_name)
                tmp_file_out_list.append(tmp_file_out_name)
                read_size = frame_cnt_list[i] * 64 * 42 // 8 * 10
                if i == process_cnt - 1:
                    read_size = data_size - read_size * i
                with open(tmp_file_in_name, "wb+") as f:
                    f.write(f_in.read(read_size))
            f_in.close()
            p_list = []
            total_block_cnt = 0
            for i in range(process_cnt):
                frame_cnt = frame_cnt_list[i]
                block_cnt = frame_cnt * 42
                if i == process_cnt - 1:
                    block_cnt = block_num - total_block_cnt 
                total_block_cnt += block_cnt
                if i == process_cnt - 1:
                    assert(total_block_cnt == block_num), "total block cnt: {} block num: {}".format(total_block_cnt, block_num)
                p_list.append(Process(target=self.compress_worker, args=(i, frame_cnt, block_cnt,\
                    tmp_file_in_list[i], tmp_file_out_list[i])))
                p_list[-1].start()
            for p in p_list:
                p.join()
            f_out = open(file_out, "ab")
            for tmp_file_out in tmp_file_out_list:
                with open(tmp_file_out, "rb") as f:
                    f_out.write(f.read(os.path.getsize(tmp_file_out)))
            f_out.close()  
            for file in tmp_file_in_list:
                os.remove(file)
            for file in tmp_file_out_list:
                os.remove(file)
        else:
            self.compress_worker(0, frame_num, block_num, file_in, file_out)

    def compress_worker(self, id,  frame_num, block_num, file_in, file_out):
        data_size = block_num * 80
        assert(data_size == os.path.getsize(file_in)), \
        "data size: {} file size: {} idx: {}".format(data_size, os.path.getsize(file_in), id)
        data_num = math.ceil(data_size * 8 / 10)
        data_org = []
        data_bits = []
        width_record = []
        f_in = open(file_in, "rb")
        f_out = open(file_out, "ab")
        half_bitwidth_list = []
        for i in range(data_size):
            data_byte = f_in.read(1)
            data_int = struct.unpack('>B', data_byte)
            for j in range(8):
                val_1bit = (int(data_int[0]) >> (7 - j)) % 2
                data_bits.append(val_1bit)
        f_in.close()
        for i in range(data_num):
            data_org.append(self.int10(data_bits[i * 10:10 * (i + 1)]))
        data_org_array = np.array(data_org)
        for k in range(block_num):
            width_record.append(self.get_bitwidth(data_org_array[k * 64: 64 * (k + 1)]))
        width_record_array = np.array(width_record)
        width_record_half = width_record_array / 2
        width_record_half = width_record_half.astype(np.int64)
        ## get the width of block and the data above
        record_list = []
        for i in range(len(width_record_half)):
            a = bin(width_record_half[i]).replace('b','0')
            for j in range(1,4):
                record_list.append(int(a[-j]))  ##from low to high
        if len(record_list) % 126 != 0:
            for i in range(math.ceil(len(record_list)/126)*126 - len(record_list)):
                record_list.append(0)
        for i in range(frame_num):
            header_64_high = 0
            header_64_low = 0
            if i == frame_num -1:
                bit_start = len(record_list) - i*126
            else:
                bit_start = 125
            for j in range(62):
                header_64_high += record_list[ i*126 + 125-j]<<(61-j)  ## find high then to low
            for k in range(62,126):
                header_64_low += record_list[ i*126 + 125-k]<<(125-k)
            # print(bin(header_64_high))
            # print(bin(header_64_low))
            pack_high_pack = struct.pack(">Q", header_64_high)
            f_out.write(pack_high_pack)
            pack_low_pack = struct.pack(">Q", header_64_low)
            f_out.write(pack_low_pack)  
            
            if i == frame_num - 1:
                curr_block_num = block_num - i * 42
            else:
                curr_block_num = 42
            header_val = 0
            for k in range(curr_block_num):
                for n in range(width_record_half[i * 42 + k]):
                    data_low = 0
                    data_high = 0
                    for m in range(32):
                        data_low  += ((data_org[i * 42 * 64 + k * 64 + m] >> (n * 2)) % 4) * 2 ** (m * 2)
                    for p in range(32,64):
                        data_high += ((data_org[i * 42 * 64 + k * 64 + p] >> (n * 2)) % 4) * 2 ** ((p-32) * 2)
                    
                    data_high = int(data_high)
                    data_low = int(data_low)
                    data_high_pack = struct.pack(">Q", data_high)
                    f_out.write(data_high_pack)
                    data_low_pack = struct.pack(">Q", int(data_low))
                    f_out.write(data_low_pack)
        f_out.close()

    def encode_worker(self, frame_num, block_num, file_in, file_out):
        data_size = block_num * 80
        f_in = open(file_in, 'rb')
        data_org = []
        for _ in range(data_size // 5):
            bit_sum = 0
            for i in range(5):
                val = int(struct.pack(">B", f_in.read(1))[0])
                bit_sum = (bit_sum << 8) + val
            for j in range(3, -1, -1):
                val = (bit_sum >> (j * 10)) & ((1 << 10) - 1)
                data_org.append(val)
        f_in.close()
        header_val_full_block = 0
        for i in range(42):
            header_val_full_block += (5 << (i * 3))     
        f_out = open(file_out, "ab")
        for i in range(frame_num):
            header_val = header_val_full_block            
            curr_block_num = 42
            if i == frame_num - 1:
                curr_block_num = block_num - i * 42
                header_val = 0
                for j in range(curr_block_num):
                    header_val += 5 * 2 ** (3 * j)
        # write header
        f_out.write(struct.pack(">Q", header_val >> 80))
        f_out.write(struct.pack(">Q", header_val % (2 ** 80)))
        # write arranged data
        val_128bit_list = [[] for _ in range(curr_block_num)]
        for j in range(curr_block_num):
            val_128bit_list[j] = [0 for _ in range(5)]
            for k in range(64):
                val = data_org[i * 42 * 80 + j * 80 + k]
                for m in range(5):
                    val_2_bit = (val >> (m * 2)) & ((1 << 2) - 1)
                    val_128bit_list[j][m] += (val_2_bit << (2 * k))
        for sub_list in val_128bit_list:
            for val_128bit in sub_list:
                f_out.write(struct.pack(">Q", val_128bit >> 80))
                f_out.write(struct.pack(">Q", val_128bit & ((1 << 80) - 1)))
        f_out.close()
        
    def int10(self, data):
        num = 0
        for i in range(10):
            num += data[-i - 1] * 2 ** i
        return num

    def get_bitwidth(self, data):
        data1 = data
        for i in range(len(data1)):
            if data1[i] == 512:
                data1[i] = 511
            elif data1[i] > 512:
                data1[i] = data1[i] - 1024
        data_abs = abs(data1)
        max_data = np.max(data_abs)
        if max_data == 0:
            bit_width = 2
        else:
            bit_width = math.ceil((math.floor(math.log(max_data, 2)) + 1 + 1) / 2) * 2
        return bit_width


class Weight(object):
    def __init__(self):
        self.kernel_weight = None
        self.c_shift = None
        self.f_shift = None
        self.bias = None
        self.add_shift = None
        self.bn_a = None
        self.bn_b = None
        self.bn_shift = None
        self.prelu_alpha = None
        self.relu6_th = None
        self.truncate_shift = None
        self.kernel_weight_bitwidth = 0
        self.bias_bitwidth = 0
        self.bn_a_bitwidth = 0
        self.bn_b_bitwidth = 0
        self.prelu_alpha_bitwidth = 0
        self.relu6_th_bitwidth = 0
 