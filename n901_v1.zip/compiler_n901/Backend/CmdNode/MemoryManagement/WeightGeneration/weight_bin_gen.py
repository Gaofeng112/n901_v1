from mimetypes import init
import numpy as np
import math
import struct
import pdb
from Frontend.Node.node_def import NodeOpType
from Backend.CmdNode.MemoryManagement.WeightGeneration.common_functions import CommonFunctions
from Backend.CmdNode.MemoryManagement.WeightGeneration.gen_weight_toolbox import GenWeightToolbox
from Backend.CmdNode.MemoryManagement.WeightGeneration.gen_w_shift_bias_nl_bytes import GenWeightShiftBiasNlBytes
from Backend.CmdNode.MemoryManagement.WeightGeneration.gen_weight_chunk_bytes import GenWeightChunkBytes
from Backend.CmdNode.MemoryManagement.WeightGeneration.write_weight_bin import WriteWeightBin
from ..lutnode_gen import lut_node_type
class WeightBinGen(object):
    def __init__(self, Hwbitwidth_info):
        self.Hwbitwidth_info = Hwbitwidth_info

    def get_dilated_weight_bin(self, sub_node_list, f_weight):
        first_node = sub_node_list[0] 
        ##get big kernel weight
        weight_big_kernel = self._gen_weight(sub_node_list)
        ## normal conv
        och = sub_node_list[-1].shape[1]
        num_16f = math.ceil(och/16)
        [kernel_row, kernel_col] = first_node.conv_param['kernel_shape']
        num_k_row, num_k_col = kernel_row, kernel_col
        for i in range(num_16f):
            for j in range(num_k_row):
                for k in range(num_k_col):
                    weight_1x1 = self._get_1x1_weight(weight_big_kernel, i, j, k, sub_node_list)
                    WriteWeightBin(self.Hwbitwidth_info).write_weight_bin(weight_1x1, sub_node_list, f_weight)

    def get_big_kernel_weight_bin(self, sub_node_list, f_weight):
        first_node = sub_node_list[0] 
        ##get big kernel weight
        weight_big_kernel = self._gen_weight(sub_node_list)
        ## normal conv
        och = sub_node_list[-1].shape[1]
        ich = sub_node_list[0].input_shape[0][1]
        num_16f = math.ceil(och/16)
        [kernel_row, kernel_col] = first_node.conv_param['kernel_shape']
        # print("ich: %d, och: %d, kernel row: %d, kernel col: %d" % (ich, och, kernel_row, kernel_col))
        num_k_row, num_k_col = math.ceil(kernel_row/3), math.ceil(kernel_col/3)
        for i in range(num_16f):
            for j in range(num_k_row):
                for k in range(num_k_col):
                    ## generate weight of 3x3 conv
                    # print('num_16f={}, num_k_row={}, num_k_col={}'.format(i, j, k))
                    weight_3x3 = self._get_3x3_weight(weight_big_kernel, i, j, k, sub_node_list)
                    WriteWeightBin(self.Hwbitwidth_info).write_weight_bin(weight_3x3, sub_node_list, f_weight)

    def big_kernel_avgpool_weight_bin(self, sub_node_list, f_weight):
        first_node = sub_node_list[0]
        weight_big_kernel = self._gen_weight(sub_node_list)
        och = sub_node_list[-1].shape[1]
        ich = sub_node_list[0].input_shape[0][1]
        [kernel_row, kernel_col] = first_node.conv_param['kernel_shape']
        input_bw = first_node.hardware_info['input_bitwidth']
        output_bw = first_node.hardware_info['output_bitwidth']
        num_k_row, num_k_col = math.ceil(kernel_row/3), math.ceil(kernel_col/3)
        ich_16bit, och_16bit = math.ceil(ich/32), math.ceil(32/16)
        ich_8bit, och_8bit = math.ceil(ich/64), math.ceil(64/16)
        if (input_bw == 16 and output_bw == 16):
            for z in range(ich_16bit):
                for i in range(och_16bit):
                    for j in range(num_k_row):
                        for k in range(num_k_col):
                            weight_3x3_32ch = self._get_3x3_weight_32ch(weight_big_kernel, i, j, k, z, sub_node_list)
                            WriteWeightBin(self.Hwbitwidth_info).write_weight_bin(weight_3x3_32ch, sub_node_list, f_weight)
        else:
            for z in range(ich_8bit):
                for i in range(och_8bit):
                    for j in range(num_k_row):
                        for k in range(num_k_col):
                            weight_3x3_64ch = self._get_3x3_weight_64ch(weight_big_kernel, i, j, k, z, sub_node_list)
                            WriteWeightBin(self.Hwbitwidth_info).write_weight_bin(weight_3x3_64ch, sub_node_list, f_weight)

    def _gen_weight(self, sub_node_list):
        init_och, och = self._get_init_och(sub_node_list)
        weight = CommonFunctions().init_weight(self.Hwbitwidth_info, init_och)
        # print("init och: %d" % (init_och))
        for i in range(len(sub_node_list)):
            curr_node = sub_node_list[i]
            if curr_node.op_type == NodeOpType.ConvNode:
                GenWeightToolbox().gen_conv_weight(curr_node, weight, init_och, sub_node_list)
            elif curr_node.op_type == NodeOpType.AddNode:
                GenWeightToolbox().gen_add_weight(curr_node, weight, init_och)
            elif curr_node.op_type == NodeOpType.BatchNormalizationNode:
                GenWeightToolbox().gen_bn_weight(curr_node, weight, init_och, och)
            elif curr_node.op_type == NodeOpType.LeakyReluNode:
                GenWeightToolbox().gen_leaky_relu_weight(curr_node, weight, init_och)
            elif (curr_node.op_type == NodeOpType.UpsampleNode
                or curr_node.op_type == NodeOpType.BypassNode):
                GenWeightToolbox().gen_bypass_weight(curr_node, weight, init_och)
            elif curr_node.op_type == NodeOpType.PReluNode:
                GenWeightToolbox().gen_prelu_weight(curr_node, weight, init_och)
            elif curr_node.op_type == NodeOpType.ClipNode:
                GenWeightToolbox().gen_relu6_weight(curr_node, weight, init_och)
            elif (curr_node.op_type == NodeOpType.MaxPoolNode
                or curr_node.op_type == NodeOpType.AveragePoolNode
                or curr_node.op_type == NodeOpType.NormalReluNode
                or curr_node.op_type == NodeOpType.TruncaterNode
                or curr_node.op_type in lut_node_type):
                pass
            else:
                print('Not supported node !')
                print('\t', curr_node.op_type)
                return
            if (i == len(sub_node_list)-1):
                GenWeightToolbox().gen_truncate_shift(curr_node, weight, init_och)
        return weight

    def _get_init_och(self, sub_node_list):
        och = sub_node_list[-1].shape[1]
        first_node = sub_node_list[0]
        pool_en = False
        for node in sub_node_list:
            if node.op_type in [NodeOpType.MaxPoolNode, NodeOpType.AveragePoolNode]:
                pool_en = True        
        ## depthwise conv
        ibw = first_node.hardware_info["input_bitwidth"]
        if (first_node.op_type == NodeOpType.ConvNode 
            and 'group' in first_node.conv_param.keys()
            and first_node.conv_param['group'] != 1):
            ## rgb depthwise conv
            if och <= 4:
                init_och = 4
            ## normal depthwise conv
            else: 
                ## if pool node in sub node list
                if pool_en: 
                    init_och = math.ceil(och / 16) * 16
                else:
                    if ibw == 8:
                        init_och = math.ceil(och / 64) * 64
                    else:
                        init_och = math.ceil(och / 32) * 32
        ## normal conv
        else:
            if och <= 4:
                init_och = 4
            else:
                init_och = math.ceil(och / 16) * 16
        return init_och, och

    def get_weight_bin(self, sub_node_list, f_weight):
        ## get weight
        weight = self._gen_weight(sub_node_list)
        WriteWeightBin(self.Hwbitwidth_info).write_weight_bin(weight, sub_node_list, f_weight)

    def _get_3x3_weight_32ch(self, weight_big_kernel, i, j, k, z, sub_node_list):
        [kernel_row, kernel_col] = sub_node_list[0].conv_param['kernel_shape']
        num_k_row, num_k_col = math.ceil(kernel_row/3), math.ceil(kernel_col/3)
        ich_32 = 32
        och_32 = 32
        f_st, f_ed = 32*z + 16*i, 32*z + 16*i + 16
        k_r_st = 3 * j
        k_c_st = 3 * k
        weight_3x3 = CommonFunctions().init_weight(self.Hwbitwidth_info, 16)
        weight_3x3.kernel_weight = np.zeros((3, 3, ich_32, 16))
        for l in range(3):
            for m in range(3):
                for n in range(ich_32):
                    for p in range(16):
                        if(k_r_st + l >= kernel_row or k_c_st + m >= kernel_col or f_st + p >= 32*z+och_32):
                            weight_3x3.kernel_weight[l, m, n, p] = 0
                        else:
                            weight_3x3.kernel_weight[l, m, n, p] = weight_big_kernel.kernel_weight[k_r_st+l, k_c_st+m, 32*z + n, f_st+p]
        # print(weight_big_kernel.c_shift.shape)
        weight_3x3.c_shift = weight_big_kernel.c_shift[f_st: f_ed]
        if(j == num_k_row - 1 and k == num_k_col - 1):
            weight_3x3.f_shift = weight_big_kernel.f_shift[f_st: f_ed]
            weight_3x3.bias  = weight_big_kernel.bias[f_st: f_ed]
            weight_3x3.add_shift  = weight_big_kernel.add_shift[f_st: f_ed]
            weight_3x3.bn_a  = weight_big_kernel.bn_a[f_st: f_ed]
            weight_3x3.bn_b  = weight_big_kernel.bn_b[f_st: f_ed]
            weight_3x3.bn_shift  = weight_big_kernel.bn_shift[f_st: f_ed]
            weight_3x3.prelu_alpha  = weight_big_kernel.prelu_alpha[f_st: f_ed]
            weight_3x3.relu6_th  = weight_big_kernel.relu6_th[f_st: f_ed]
            weight_3x3.truncate_shift = weight_big_kernel.truncate_shift[f_st: f_ed]
        return weight_3x3
    
    def _get_3x3_weight_64ch(self, weight_big_kernel, i, j, k, z, sub_node_list):
        [kernel_row, kernel_col] = sub_node_list[0].conv_param['kernel_shape']
        num_k_row, num_k_col = math.ceil(kernel_row/3), math.ceil(kernel_col/3)
        ich_64, och_64 = 64, 64
        f_st, f_ed = 64 * z + 16 * i, 64*z + 16 * i + 16
        k_r_st = 3 * j
        k_c_st = 3 * k
        weight_3x3 = CommonFunctions().init_weight(self.Hwbitwidth_info, 16)
        weight_3x3.kernel_weight = np.zeros((3, 3, ich_64, 16))
        for l in range(3):
            for m in range(3):
                for n in range(ich_64):
                    for p in range(16):
                        if(k_r_st + l >= kernel_row or k_c_st + m >= kernel_col or f_st + p >= 64*z+och_64):
                            weight_3x3.kernel_weight[l, m, n, p] = 0
                        else:
                            weight_3x3.kernel_weight[l, m, n, p] = weight_big_kernel.kernel_weight[k_r_st+l, k_c_st+m, 64*z+n, f_st+p]
        # print(weight_big_kernel.c_shift.shape)
        
        weight_3x3.c_shift = weight_big_kernel.c_shift[f_st: f_ed]
        if(j == num_k_row - 1 and k == num_k_col - 1):
            weight_3x3.f_shift = weight_big_kernel.f_shift[f_st: f_ed]
            weight_3x3.bias  = weight_big_kernel.bias[f_st: f_ed]
            weight_3x3.add_shift  = weight_big_kernel.add_shift[f_st: f_ed]
            weight_3x3.bn_a  = weight_big_kernel.bn_a[f_st: f_ed]
            weight_3x3.bn_b  = weight_big_kernel.bn_b[f_st: f_ed]
            weight_3x3.bn_shift  = weight_big_kernel.bn_shift[f_st: f_ed]
            weight_3x3.prelu_alpha  = weight_big_kernel.prelu_alpha[f_st: f_ed]
            weight_3x3.relu6_th  = weight_big_kernel.relu6_th[f_st: f_ed]
            weight_3x3.truncate_shift = weight_big_kernel.truncate_shift[f_st: f_ed]
        return weight_3x3
    
    def _get_3x3_weight(self, weight_big_kernel, i, j, k, sub_node_list):
        [kernel_row, kernel_col] = sub_node_list[0].conv_param['kernel_shape']
        num_k_row, num_k_col = math.ceil(kernel_row/3), math.ceil(kernel_col/3)
        ich = sub_node_list[0].input_shape[0][1]
        och = sub_node_list[-1].shape[1]
        # need to be complete num_k_row num_k_col
        ## feature start and feature end
        f_st, f_ed = 16 * i, 16 * i + 16
        ## kernel and data_range for each command
        k_r_st = 3 * j
        k_c_st = 3 * k
        ##get weight for each 3x3 conv
        weight_3x3 = CommonFunctions().init_weight(self.Hwbitwidth_info, 16)
        if ('group' in sub_node_list[0].conv_param.keys()
            and sub_node_list[0].conv_param['group'] != 1):
            ## 3x3depthwise conv
            weight_3x3.kernel_weight = np.zeros((3, 3, 16))
            for l in range(3):
                for m in range(3):
                    for p in range(16):
                        if(k_r_st + l >= kernel_row or k_c_st + m >= kernel_col or f_st + p >= och):
                            weight_3x3.kernel_weight[l, m, p] = 0
                        else:
                            weight_3x3.kernel_weight[l, m, p] = weight_big_kernel.kernel_weight[k_r_st+l, k_c_st+m, f_st+p]
        else:
            ## normal conv
            weight_3x3.kernel_weight = np.zeros((3, 3, ich, 16))
            for l in range(3):
                for m in range(3):
                    for n in range(ich):
                        for p in range(16):
                            if(k_r_st + l >= kernel_row or k_c_st + m >= kernel_col or f_st + p >= och):
                                weight_3x3.kernel_weight[l, m, n, p] = 0
                            else:
                                weight_3x3.kernel_weight[l, m, n, p] = weight_big_kernel.kernel_weight[k_r_st+l, k_c_st+m, n, f_st+p]
        # print(weight_big_kernel.c_shift.shape)
        weight_3x3.c_shift = weight_big_kernel.c_shift[f_st: f_ed]
        if(j == num_k_row - 1 and k == num_k_col - 1):
            weight_3x3.f_shift = weight_big_kernel.f_shift[f_st: f_ed]
            weight_3x3.bias  = weight_big_kernel.bias[f_st: f_ed]
            weight_3x3.add_shift  = weight_big_kernel.add_shift[f_st: f_ed]
            weight_3x3.bn_a  = weight_big_kernel.bn_a[f_st: f_ed]
            weight_3x3.bn_b  = weight_big_kernel.bn_b[f_st: f_ed]
            weight_3x3.bn_shift  = weight_big_kernel.bn_shift[f_st: f_ed]
            weight_3x3.prelu_alpha  = weight_big_kernel.prelu_alpha[f_st: f_ed]
            weight_3x3.relu6_th  = weight_big_kernel.relu6_th[f_st: f_ed]
            weight_3x3.truncate_shift = weight_big_kernel.truncate_shift[f_st: f_ed]
        return weight_3x3

    def _get_1x1_weight(self, weight_big_kernel, i, j, k, sub_node_list):
        [kernel_row, kernel_col] = sub_node_list[0].conv_param['kernel_shape']
        num_k_row, num_k_col = kernel_row, kernel_col
        ich = sub_node_list[0].input_shape[0][1]
        och = sub_node_list[-1].shape[1]
        # need to be complete num_k_row num_k_col
        ## feature start and feature end
        f_st, f_ed = 16 * i, 16 * i + 16
        ## kernel and data_range for each command
        k_r_st = j
        k_c_st = k
        ##get weight for each 3x3 conv
        weight_1x1 = CommonFunctions().init_weight(self.Hwbitwidth_info, 16)
        weight_1x1.kernel_weight = np.zeros((1, 1, ich, 16))
        for l in range(1):
            for m in range(1):
                for n in range(ich):
                    for p in range(16):
                        if(k_r_st + l >= kernel_row or k_c_st + m >= kernel_col):
                            weight_1x1.kernel_weight[l, m, n, p] = 0
                            assert(False), "1x1 kernel is out of the bound of 3x3 kernel"
                        else:
                            weight_1x1.kernel_weight[l, m, n, p] = weight_big_kernel.kernel_weight[k_r_st+l, k_c_st+m, n, f_st+p]
        weight_1x1.c_shift = weight_big_kernel.c_shift[f_st: f_ed]
        if(j == num_k_row - 1 and k == num_k_col - 1):
            weight_1x1.f_shift = weight_big_kernel.f_shift[f_st: f_ed]
            weight_1x1.bias = weight_big_kernel.bias[f_st: f_ed]
            weight_1x1.add_shift = weight_big_kernel.add_shift[f_st: f_ed]
            weight_1x1.bn_a = weight_big_kernel.bn_a[f_st: f_ed]
            weight_1x1.bn_b = weight_big_kernel.bn_b[f_st: f_ed]
            weight_1x1.bn_shift = weight_big_kernel.bn_shift[f_st: f_ed]
            weight_1x1.prelu_alpha = weight_big_kernel.prelu_alpha[f_st: f_ed]
            weight_1x1.relu6_th = weight_big_kernel.relu6_th[f_st: f_ed]
            weight_1x1.truncate_shift = weight_big_kernel.truncate_shift[f_st: f_ed]
        return weight_1x1



