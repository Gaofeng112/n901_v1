import struct
import math
import os
import pip
from Backend.CmdNode.MemoryManagement.CommandGeneration.registers_arrange import RegistersArrange
from Backend.CmdNode.MemoryManagement.CommandGeneration.register_gen import RegisterGen
from Frontend.Node.node_def import NodeOpType
from Frontend.HWToolBox.N900HWToolBox import N900HWToolBox
from .lutnode_gen import lut_node_type
from Backend.CmdNode.MemoryManagement.dma_info_gen import DMAInfoGenAgent
import logging
import pdb

class CmdGenAgent(object):
    def __init__(self):
        self.lutmode = None
        pass

    def fill_cmd(self, cmd_node_list, datanode_dict, lutnode_dict, group_list, start_addr_info_dict, result_path):
        ##generate cmd.bin and fill the members 'cmd_start_addr', 'cmd_len' of each cmdNode in cmd_node_list
        cmd_start_addr_next = start_addr_info_dict["cmd_start_addr"]
        list_len = len(cmd_node_list)
        
        result_file = os.path.join(result_path, "cmd.bin")
        dram_result_file = os.path.join(result_path, "dram_cmd.bin")
        with open(result_file, 'wb') as f_cmd:
            for i in range(list_len):
                # print('current cmd node group_idx={} chunk_id={}'.format(cmd_node_list[i].group_id, cmd_node_list[i].chunk_id))
                if cmd_node_list[i].type == 'NPUType':
                    self.__check_first_lutnode(cmd_node_list[i])
                    # get cmd_start_addr and cmd_len while generating cmd.bin
                    cmd_start_addr = cmd_start_addr_next
                    cmd_len = self._get_cmd_len(cmd_node_list[i], f_cmd, datanode_dict, lutnode_dict, cmd_node_list)
                    # fill cmd_node with npu cmd information
                    cmd_node_list[i].cmd_start_addr = cmd_start_addr
                    cmd_node_list[i].cmd_len = hex(cmd_len)
                    # get next cmd_start_addr 
                    cmd_start_addr_int = int(cmd_start_addr, 16)
                    cmd_start_addr_next_int = cmd_start_addr_int + cmd_len
                    cmd_start_addr_next = hex(cmd_start_addr_next_int)
        self._dram_cmd_gen(result_file, dram_result_file)

    def _get_cmd_len(self, cmd_node, f_cmd, datanode_dict, lutnode_dict, cmd_node_list):
        node_list_len = len(cmd_node.contents.node_list)
        cmd_len = 0
        didma_id = 0
        datanode_in_id = 0
        register_gen = RegisterGen()
        needOffset = False
        endAddNode = None
        offset = 0
        pipoIdx = 0

        for sub_id in range(node_list_len):
            curr_node = cmd_node.contents.node_list[sub_id]
            ## initialize all-zero reg
            if sub_id == 0:
                register_gen.reg_old = RegistersArrange()
                register_gen.didma_update_sram_data_map(cmd_node, didma_id, datanode_in_id, sub_id, datanode_dict, cmd_node_list)
                didma_id += 1
                datanode_in_id += 1
            if curr_node.op_type == NodeOpType.HardwareFusionNode:
                sub_node_list = curr_node.sub_node_list
            else:
                sub_node_list = [curr_node]
            first_node = sub_node_list[0]
            startOfRes = len(curr_node.children) == 2 and sub_id != node_list_len - 1
            flag, endNode = self.isRightBranchFirstNode(curr_node, sub_id, cmd_node.contents.node_list)
            if(startOfRes or flag):
                assert(not(startOfRes and flag)), "Cannot have both properties!"
                if(startOfRes):
                    endAddNode = curr_node.children[1]
                    assert(endAddNode.op_type == NodeOpType.AddNode or endAddNode.sub_node_list[0].op_type == NodeOpType.AddNode), "Not Add Node!"
                else:
                    endAddNode = endNode
                    assert(endAddNode.op_type == NodeOpType.AddNode or endAddNode.sub_node_list[0].op_type == NodeOpType.AddNode), "Not Add Node!"
                needOffset = True
                if(startOfRes):
                    offset = register_gen.pipo_update_sram_data_map(cmd_node, sub_id, needOffset=False, getOffset=True)
                else:
                    offset = register_gen.pipo_update_sram_data_map(cmd_node, sub_id, needOffset=False, getOffset=True, OffsetFromOut=False)
                if(startOfRes):
                    pipoIdx = 0
                else:
                    pipoIdx = 1
            elif(needOffset): ## curr node is in the branch 
                pipoIdx += 1
                tmp = register_gen.pipo_update_sram_data_map(cmd_node, sub_id, needOffset=needOffset, getOffset=False, OffsetFromOut=True, offset=offset, pipoIdx=pipoIdx)
                if(curr_node == endAddNode):
                    ## reach the end add node, clear all the relative variables
                    needOffset = False
                    offset = 0
                    pipoIdx = 0
                    endAddNode = None
            else:
                tmp = register_gen.pipo_update_sram_data_map(cmd_node, sub_id)
            if first_node.op_type == NodeOpType.AddNode:
                parentInSameGrp, parentStofRes, didmaAdd = DMAInfoGenAgent().addNodeNeedDMA(curr_node, cmd_node.contents.node_list)
                genCmd = False
                
                if (not parentInSameGrp):
                    if (didmaAdd):
                        register_gen.didma_update_sram_data_map(cmd_node, didma_id, datanode_in_id, sub_id, datanode_dict, cmd_node_list)
                        f_cmd.write(b'\x30\x02\x00\x00') # INT + NOP
                        f_cmd.write(b'\x10\x01\x00\x00') # SYNC + NOP
                        cmd_len += 8
                        didma_id += 1
                    else:
                        if(not parentStofRes):
                            register_gen.didma_update_sram_data_map(cmd_node, didma_id, datanode_in_id, sub_id, datanode_dict, cmd_node_list)
                            didma_id += 1
                            if (sub_id != 0):
                                # cmd_len += register_gen.gen_single_cmd_len(curr_node, sub_node_list, cmd_node, sub_id, f_cmd)
                                f_cmd.write(b'\x30\x02\x00\x00') # INT + NOP
                                f_cmd.write(b'\x10\x01\x00\x00') # SYNC + NOP
                                cmd_len += 8
                            cmd_len += register_gen.gen_single_cmd_len(curr_node, sub_node_list, cmd_node, sub_id, f_cmd)
                            genCmd = True
                    datanode_in_id += 1
                if(not genCmd and not didmaAdd):
                    cmd_len += register_gen.gen_single_cmd_len(curr_node, sub_node_list, cmd_node, sub_id, f_cmd)
            elif self.checkChangeLutMode(sub_node_list, lutnode_dict):  
                lutnode = None
                for sub_node in sub_node_list:
                    if(sub_node.op_type in lut_node_type):
                        lutnode = lutnode_dict[sub_node]
                        break
                assert(lutnode != None), "Not Find the lutnode!!"
                if self.lutmode != "head_node":
                    f_cmd.write(b'\x30\x02\x00\x00') # INT + NOP
                    f_cmd.write(b'\x10\x01\x00\x00') # SYNC + NOP
                    cmd_len += 8
                self.lutmode = str(lutnode.func_type) + "_" + str(lutnode.x_radix) + "_" + str(lutnode.y_radix) + "_" + str(lutnode.input_bitwidth)
                cmd_len += register_gen.gen_single_cmd_len(curr_node, sub_node_list, cmd_node, sub_id, f_cmd)
            else:
                cmd_len += register_gen.gen_single_cmd_len(curr_node, sub_node_list, cmd_node, sub_id, f_cmd)
            # register_gen.pipo_update_sram_data_map(cmd_node, sub_id)
            register_gen.reg_old = register_gen.reg_new
        f_cmd.write(b'\x30\x02\x00\x00') # INT + NOP
        f_cmd.write(b'\x10\x01\x00\x00') # SYNC + NOP
        cmd_len += 8
        cmd_node = self._check_avgpool_cmd(cmd_node)
        return cmd_len
    
    def _check_avgpool_cmd(self, cmd_node):
        if cmd_node.contents.avgpool_flag:
            cmd_node.cmd_len_list[-1] = cmd_node.cmd_len_list[-1]+8
        return cmd_node
    
    def _dram_cmd_gen(self, file_in, file_out):
        ## convert big end to little end for each 4 byte data
        f_in = open(file_in, 'rb')
        f_out = open(file_out, 'wb')
        data_size = os.path.getsize(file_in)
        num_4byte = math.ceil(data_size / 4)
        for i in range(num_4byte):
            buffer_4byte = []
            for j in range(4):
                buffer_4byte.insert(0, f_in.read(1))
            for j in range(4):
                f_out.write(buffer_4byte[j])
        f_in.close()
        f_out.close()
    
    def checkChangeLutMode(self, sub_node_list, lutnode_dict):
        ###  if there is no mish or silu node in sub_node_list, return False
        ###  if mode if curr node (func type, x_radix, y_raidx) is same as the previous one, return False
        ###  else return True
        node = None
        for sub_node in sub_node_list:
            if(sub_node.op_type in lut_node_type):
                node = sub_node
                break
        if(node == None):
            return False
        lutnode = lutnode_dict[node]
        mode = str(lutnode.func_type) + "_" + str(lutnode.x_radix) + "_" + str(lutnode.y_radix) + "_" + str(lutnode.input_bitwidth)
        if(mode == self.lutmode):
            return False;
        return True

    def __check_first_lutnode(self, cmd_node):
        if cmd_node.contents.node_list[0].op_type == NodeOpType.HardwareFusionNode:
            sub_node_list = cmd_node.contents.node_list[0].sub_node_list
        else:
            sub_node_list = [cmd_node.contents.node_list[0]]
        for sub_node in sub_node_list:
            if sub_node.op_type == NodeOpType.SiluNode or sub_node.op_type == NodeOpType.MishNode:
                self.lutmode = "head_node"
                break
    
    def isRightBranchFirstNode(self, node, sub_id, node_list):
        if(sub_id != 0):
            return False, None
        if(len(node.parents) != 1):
            return False, None
        pNode = node.parents[0]
        if(len(pNode.children) != 2):
            return False, None
        [child1, child2] = pNode.children
        EndAddNode = None
        if(child1 == node):
            EndAddNode = child2
        elif(child2 == node):
            EndAddNode = child1
        else:
            assert("False"), "Wrong parent node!"
        if(EndAddNode.op_type != NodeOpType.AddNode and \
            not (EndAddNode.op_type == NodeOpType.HardwareFusionNode and EndAddNode.sub_node_list[0].op_type == NodeOpType.AddNode)):
            return False, None
        if(EndAddNode not in node_list):
            return False, None
        checkNode = EndAddNode
        if(EndAddNode.op_type == NodeOpType.HardwareFusionNode):
            checkNode = EndAddNode.sub_node_list[0]
        if(N900HWToolBox().is_DIDMA_Add(checkNode)):
            return False, None
        currNode = node
        while(currNode != EndAddNode):
            if(len(currNode.children) != 1):
                return False, None
            currNode = currNode.children[0]
        return True, EndAddNode