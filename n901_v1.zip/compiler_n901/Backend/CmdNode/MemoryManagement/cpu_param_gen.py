import os
import struct
import pdb
from Backend.CmdNode.cmd_node_def import CPUShift_param, L2Norm_param

from Frontend.Node.node_def import NodeOpType

class CPUParamGenAgent(object):
    def __init__(self):
        pass

    def fill_cpu_param(self, cmd_node_list, start_addr, result_path):
        weight_file = os.path.join(result_path, "weight.bin")
        with open(weight_file, 'ab') as f_weight:
            for cmd_node in cmd_node_list:
                if (cmd_node.type == 'NPUType'):
                    continue
                for i in range(len(cmd_node.contents.node_list)):
                    curr_node = cmd_node.contents.node_list[i]
                    if curr_node.op_type == NodeOpType.ShiftNode:
                        start_addr = self._append_shift_node_param(cmd_node, curr_node, start_addr, f_weight)
                    elif curr_node.op_type == NodeOpType.L2NormalizationNode:
                        start_addr = self._append_L2N_node_param(cmd_node, curr_node, start_addr, f_weight)
        return start_addr
        
    def _append_L2N_node_param(self, cmd_node, curr_node, start_addr, f_weight):
        ch_num = len(curr_node.L2N_scale)
        ### write L2N scale to weight.bin
        byte_num = 0
        for val in curr_node.L2N_scale:
            val_w = struct.pack(">f", float(val))
            f_weight.write(val_w)
            byte_num += 4
        ### write L2N x_radix to weight.bin
        for val in curr_node.hardware_info[1]['x_radix']:
            val_w = struct.pack(">h", int(val))
            f_weight.write(val_w)
            byte_num += 2
        ### write L2N Y_raidx to weight.bin
        for val in curr_node.hardware_info[1]['y_radix']:
            val_w = struct.pack(">h", int(val))
            f_weight.write(val_w)
            byte_num += 2
        assert(byte_num == ch_num * 8), "Wrong Written bytes of L2N param"
        L2N_param = L2Norm_param()
        L2N_param.start_addr = start_addr
        L2N_param.len = hex(byte_num)
        cmd_node.CPU_param.append(L2N_param)
        ## get start addr for the next cpu param
        start_addr_next_int = int(start_addr, 16) + byte_num
        start_addr_next = hex(start_addr_next_int)
        return start_addr_next

    def _append_shift_node_param(self, cmd_node, curr_node, start_addr, f_weight):
        ## write shift param to weight.bin
        ch_num = len(curr_node.shift_param)
        byte_num = int(ch_num / 2)
        for i in range(byte_num):
            val_1 = curr_node.shift_param[2 * i]
            if val_1 < 0:
                val_1 = 16 + val_1
            val_2 = curr_node.shift_param[2 * i + 1]
            if val_2 < 0:
                val_2 = 16 + val_2
            val = val_1 + val_2 * 16
            val_w = struct.pack(">B", int(val))
            f_weight.write(val_w)
        ## instantiate a cpu_shift_param and append it to CPU_param list
        cpu_shift_param = CPUShift_param()
        cpu_shift_param.start_addr = start_addr
        cpu_shift_param.len = hex(byte_num)
        cmd_node.CPU_param.append(cpu_shift_param)
        ## get start addr for the next cpu param
        start_addr_next_int = int(start_addr, 16) + byte_num
        start_addr_next = hex(start_addr_next_int)
        return start_addr_next
