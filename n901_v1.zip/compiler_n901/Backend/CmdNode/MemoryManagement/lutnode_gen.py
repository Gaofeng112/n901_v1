from syslog import LOG_UPTO
from ..cmd_node_def import LutNode
from Frontend.Node.node_def import NodeOpType

lut_node_type = [NodeOpType.SiluNode, NodeOpType.MishNode]
class LutNodeGenAgent(object):
    def __init__(self):
        self.index = 0
        self.lut_node_map = {}

    def fill_lut_node(self, cmd_node_list, lut_node_dict, assigned_groups, start_addr = 0):
        self.st_addr = start_addr
        grp_to_cmd_node_map = {}

        for cmd_node in cmd_node_list:
            grp = cmd_node.contents
            if(grp not in grp_to_cmd_node_map):
                grp_to_cmd_node_map[grp] = [cmd_node]
            else:
                grp_to_cmd_node_map[grp].append(cmd_node)

        for grp in assigned_groups:
            for node in grp.node_list:
                sub_node = self.__check_lutnode(node)
                if(sub_node == None):
                    continue
                lut_node = self.__gen_lutnode(sub_node)
                lut_node_dict[sub_node] = lut_node
                for cmd_node in grp_to_cmd_node_map[grp]:
                    cmd_node.lutnode.append(lut_node)
    
    def __check_lutnode(self, node):
        if(node.op_type in lut_node_type):
            return node
        if(node.op_type == NodeOpType.HardwareFusionNode):
            for sub_node in node.sub_node_list:
                if(sub_node.op_type in lut_node_type):
                    return sub_node
        return None

    def __gen_lutnode(self, node):
        x_radix = node.hardware_info["x_radix"][0]
        y_radix = node.hardware_info["y_radix"][0]
        input_bitwidth = node.hardware_info["input_bitwidth"]
        function_type = None
        if(node.op_type == NodeOpType.MishNode):
            function_type = 0
        elif(node.op_type == NodeOpType.SiluNode):
            function_type = 1
        else:
            assert(False), "Not Support lut node type!!!"
        nodeKey = str(function_type) + "_" + str(x_radix) + "_" + str(y_radix) + "_" + str(input_bitwidth)
        lut_node = LutNode()
        lut_node.x_radix, lut_node.y_radix, lut_node.input_bitwidth, lut_node.func_type = x_radix, y_radix, input_bitwidth, function_type
        if(nodeKey in self.lut_node_map.keys()):
            lut_node.addr = self.lut_node_map[nodeKey].addr
        else:
            lut_node.addr = self.st_addr 
            self.st_addr += lut_node.addr_len
            self.lut_node_map[nodeKey] = lut_node
        lut_node.index = self.index
        self.index += 1
        return lut_node
        
    def change_lut_node_start_addr(self, cmd_node_list, addr_offset):
        lutNodeSet = set()
        for cmd_node in cmd_node_list:
            if(cmd_node.type == "CPUType"):
                continue
            for lnode in cmd_node.lutnode:
                if(lnode not in lutNodeSet):
                    lnode.addr += addr_offset
                    lutNodeSet.add(lnode)

    def display_lut_node_dict(self, lut_node_dict):
        for key, val in lut_node_dict.items():
            print("--------------------------------------")
            print("Node name: %s" % (key.name))
            self.display_lut_node(val)
    
    def display_lut_node(self, lut_node):
        print("lut node index: %d" % (lut_node.index))
        print("lut node addr: %d" % (lut_node.addr))
        print("lut node addr len: %d" % (lut_node.addr_len))
        print("lut node addr num: %d" % (lut_node.addr_num))
        if(lut_node.func_type == 0):
            print("lut node func type: %s" % ("Mish"))
        else:
            print("lut node func type: %s" % ("Silu"))