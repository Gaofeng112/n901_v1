import math
import pdb
from Frontend.Node.functions_fl import sub

from Frontend.Visitors.datanode_dict_visitor import DataNodeDictVisitor
from Frontend.Node.node_def import NodeOpType
res_id = []
class UpdateDataMap(object):
    def __init__(self, map_list):
        self.sram_data_map_list = map_list

    def didma_update_sram_data_map(self, cmd_node, didma_id, datanode_in_id, sub_id, datanode_dict, cmd_node_list):
        sram_data_map = self._get_didma_sram_data_map(cmd_node, didma_id, datanode_in_id, sub_id, datanode_dict, cmd_node_list)
        self._check_overlap(sram_data_map)
        self.sram_data_map_list.append(sram_data_map)
        node_list = cmd_node.contents.node_list
        curr_node = node_list[sub_id]
        
    def pipo_update_sram_data_map(self, cmd_node, sub_id, needOffset, getOffset, offset, pipoIdx, OffsetFromOut):
        node_list =  cmd_node.contents.node_list
        curr_node = node_list[sub_id]
        res = self._get_pipo_sram_data_map(cmd_node, sub_id, needOffset, getOffset, offset, pipoIdx, OffsetFromOut)
        if(getOffset):
            [sram_data_map, offset] = res
        else:
            [sram_data_map] = res
        # self._clean_sram_data_map(node_list, sub_id, sram_data_map)
        self._check_overlap(sram_data_map)
        self.sram_data_map_list.append(sram_data_map)
        if(getOffset):
            return offset
        return 0

    def _clean_sram_data_map(self, node_list, sub_id, sram_data_map):
        curr_node = node_list[sub_id]
        parent_nodes = curr_node.parents
        sram_node_id = [node.index for node in parent_nodes]
        sram_node_id.append(curr_node.index)
        if (self._check_res(curr_node, node_list) or self._node_in_res(curr_node)):
            if(self._check_res(curr_node, node_list)): 
                global res_id
                res_id = self._get_res_node_id(curr_node)

            for sram_data in self.sram_data_map_list:
                if (sram_data.node_id not in sram_node_id
                    and sram_data.node_id != res_id[0]):
                    self.sram_data_map_list.remove(sram_data)
        else:
            for sram_data in self.sram_data_map_list:
                if sram_data.node_id not in sram_node_id:
                    self.sram_data_map_list.remove(sram_data)

    def _node_in_res(self, curr_node):
        if curr_node.index in res_id:
            return True
        return False
    
    def _get_res_node_id(self, curr_node):
        res_id = []
        [child1, child2] = curr_node.children
        if child1.op_type == NodeOpType.AddNode:
            end_node = child1
            right_node = child2
        else:
            end_node = child2
            right_node = child1
        child_node = right_node
        res_id.append(curr_node.index)
        res_id.append(child_node.index)
        while(child_node != end_node):
            child_node = child_node.children[0]
            res_id.append(child_node.index)
        return res_id
    
    def _check_res(self, node, node_list):
        if len(node.children) != 2:
            return 0
        [child1, child2] = node.children

        if (node not in node_list):
            return 0
        ## If is not the case that one child has a parent and the other one has two, return false
        if (not(len(child1.parents) == 2 and len(child2.parents) == 1)) and (not(len(child1.parents) == 1 and len(child2.parents) == 2)):
            return 0
        if(len(child1.parents) == 1 and len(child2.parents) == 2):
            left_node = child2
            right_node = child1
        else:
            left_node = child1
            right_node = child2
        currNode = right_node
        branch_len = 0
        while(True):
            branch_len += 1
            if(currNode == left_node):
                break
            elif(len(currNode.children) != 1):
                branch_len = 0
                break
            currNode = currNode.children[0]
        return branch_len
    
    def _get_pipo_sram_data_map(self, cmd_node, sub_id, needOffset, getOffset, offset, pipoIdx, offsetFromOut):
        sram_data_map = SramDataInfo()
        ## get AB_order and sram_offset
        # initialize AB_order
        start_AB_order = cmd_node.DIDMA_param[0].dmem
        AB_order = (start_AB_order + sub_id + 1) % 2
        curr_node = cmd_node.contents.node_list[sub_id]
        if(not needOffset):
            sram_data_map.get_offset(AB_order, [0, 0])
        else:
            sram_data_map.get_offset(AB_order, [offset * (1 - (pipoIdx % 2)), 0])
        ## get max address for this piece of data in sram
        chunk_id = cmd_node.chunk_id
        chunk_dict = cmd_node.contents.output_chunk[sub_id][chunk_id]
        row_num = chunk_dict['row_ed'] - chunk_dict['row_st'] + 1
        col_num = chunk_dict['col_ed'] - chunk_dict['col_st'] + 1
        ch_num = chunk_dict['ch_ed'] - chunk_dict['ch_st'] + 1
        obw = cmd_node.contents.node_list[sub_id].hardware_info['output_bitwidth']
        ibw = cmd_node.contents.node_list[sub_id].hardware_info['input_bitwidth']
        if obw == 16:
            max_addr = col_num * math.ceil((row_num * math.ceil(ch_num / 32)) / 16) - 1
        else:
            max_addr = col_num * math.ceil((row_num * math.ceil(ch_num / 64)) / 16) - 1
        offsetRes = max_addr
        if(not offsetFromOut):
            in_chunk_dict = cmd_node.contents.input_chunk[sub_id][chunk_id]
            row_num = in_chunk_dict['row_ed'] - in_chunk_dict['row_st'] + 1
            col_num = in_chunk_dict['col_ed'] - in_chunk_dict['col_st'] + 1
            ch_num = in_chunk_dict['ch_ed'] - in_chunk_dict['ch_st'] + 1
            if ibw == 16:
                offsetRes = offset + col_num * math.ceil((row_num * math.ceil(ch_num / 32)) / 16) - 1
            else:
                offsetRes = offset + col_num * math.ceil((row_num * math.ceil(ch_num / 64)) / 16) - 1
        assert(max_addr < 2048), "sram overflow on node: %s, max_addr is %d" % (cmd_node.contents.node_list[sub_id].name, max_addr)
        sram_data_map.get_max_addr(max_addr)
        ## get node
        sram_data_map.get_node_id(cmd_node.contents.node_list[sub_id].index)
        sram_data_map.get_node(cmd_node.contents.node_list[sub_id])
        if(getOffset):
            return [sram_data_map, offsetRes + 1]
        return [sram_data_map]

    def _get_didma_sram_data_map(self, cmd_node, didma_id, datanode_in_id, sub_id, datanode_dict, cmd_node_list):
        sram_data_map = SramDataInfo()
        ## get AB_order and sram_offset
        curr_didma = cmd_node.DIDMA_param[didma_id]
        sram_data_map.get_offset(curr_didma.dmem, curr_didma.sram_offset)
        ## get max address for this piece of data in sram
        data_node = cmd_node.datanode_in[datanode_in_id]
        chunk_id = cmd_node.chunk_id
        chunk_dict = cmd_node.contents.input_chunk[sub_id][chunk_id]
        row_num = chunk_dict['row_ed'] - chunk_dict['row_st'] + 1
        col_num = chunk_dict['col_ed'] - chunk_dict['col_st'] + 1
        ch_num = chunk_dict['ch_ed'] - chunk_dict['ch_st'] + 1
        [offset_x, offset_y] = curr_didma.sram_offset
        if data_node.format == 0:
            ## 4 channel mode
            max_addr = offset_x + math.ceil(col_num / 8) \
                * math.ceil((offset_y + row_num) / 16) - 1
        elif data_node.format == 1:
            ## 32 channel mode
            max_addr = offset_x + col_num * math.ceil((offset_y + (row_num * math.ceil(ch_num / 32))) / 16) - 1
        elif data_node.format == 3:
            ## 4 channel, 16 col mode
            max_addr = offset_x + math.ceil(col_num / 16) \
                * math.ceil((offset_y + row_num) / 16) - 1
        elif data_node.format == 4:
            ## 64 channel mode
            max_addr = offset_x + col_num * math.ceil((offset_y + (row_num * math.ceil(ch_num / 64))) / 16) - 1
        sram_data_map.get_max_addr(max_addr)
        ## find out which node in model graph is this datanode from
        matched_node = DataNodeDictVisitor().get_matched_node(datanode_dict, data_node)
        sram_data_map.get_node_id(matched_node.index)
        sram_data_map.get_node(matched_node)
        return sram_data_map

    def _check_overlap(self, map_in):
        for curr_map in self.sram_data_map_list:
            if map_in.AB_order == curr_map.AB_order:
                if not (map_in.offset[0] > curr_map.max_addr
                    or map_in.max_addr < curr_map.offset[0]):
                    self.sram_data_map_list.remove(curr_map)

class SramDataInfo(object):
    def __init__(self):
        self.node_id = 0
        self.AB_order = 0
        self.offset = []
        self.max_addr = 0
        self.node = {}
    def get_offset(self, ab_order, sram_offset):
        self.AB_order = ab_order
        self.offset = sram_offset
    def get_node_id(self, node_id):
        self.node_id = node_id
    def get_node(self, node):
        if node.op_type == NodeOpType.HardwareFusionNode:
            self.node['node_name'] = node.name
            self.node['sub_node_list'] = []
            for sub_node in node.sub_node_list:
                self.node['sub_node_list'].append(sub_node.name)
        else:
            self.node['node_name'] = node.name
    def get_max_addr(self, addr):
        self.max_addr = addr
