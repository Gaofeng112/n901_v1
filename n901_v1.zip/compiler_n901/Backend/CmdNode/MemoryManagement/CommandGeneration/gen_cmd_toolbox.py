import math

from Frontend.Node.node_def import NodeOpType
from ..lutnode_gen import lut_node_type
from Frontend.HWToolBox.N900HWToolBox import N900HWToolBox
import pdb
class GenCmdToolbox(object):
    def __init__(self):
        pass
    def gen_bm_reg(self, node, sub_node_list, AB_order, cmd_node, out_chunk, reg_new, sram_data_map_list, i=0):
        ## upsample
        if sub_node_list[0].op_type == NodeOpType.UpsampleNode:
            upsample = 1
        else:
            upsample = 0
        ## offset
        node_list = cmd_node.contents.node_list
        if (sub_node_list[0].op_type == NodeOpType.AddNode):
            parent_0 = sub_node_list[0].parents[0]
            parent_1 = sub_node_list[0].parents[1]
            if(node.op_type == NodeOpType.HardwareFusionNode):
                parent_0 = node.parents[0]
                parent_1 = node.parents[1]
            [in1_x, in1_y] = self._get_parent_offset(parent_0, node, sram_data_map_list)
            [in2_x, in2_y] = self._get_parent_offset(parent_1, node, sram_data_map_list)
        else:
            assert(len(node.parents) == 1), "%s has 2 parents!" % (node.name)
            [in1_x, in1_y] = self._get_parent_offset(node.parents[0], node, sram_data_map_list)
            [in2_x, in2_y] = [0, 0]
        [out_x, out_y] = [0, 0]
        [psum_x, psum_y] = [0 ,0]
        for sram_data_map in sram_data_map_list:
            if(sram_data_map.node_id == node.index):
                [out_x, out_y] = sram_data_map.offset
        if(sub_node_list[0].op_type == NodeOpType.ConvNode):
            first_node = sub_node_list[0]
            kernel_h, kernel_w = sub_node_list[0].conv_param['kernel_shape'][0:2]
            ich = first_node.input_shape[0][1]
            if(kernel_h <= 3 and kernel_w <= 3 and 'group' in first_node.conv_param.keys() and first_node.conv_param['group'] != 1):
                pass #3x3 dw
            else: # normal conv / big kernel dw conv 
                row_out = out_chunk["row_ed"] - out_chunk["row_st"] + 1
                col_out = out_chunk["col_ed"] - out_chunk["col_st"] + 1
                ch_out = out_chunk["ch_ed"] - out_chunk["ch_st"] + 1
                psum_y = 0
                if sub_node_list[-1].hardware_info['output_bitwidth'] == 8:
                    psum_x = col_out * math.floor((row_out * math.floor((ch_out - 1) / 64) + row_out - 1) / 16) + col_out 
                elif sub_node_list[-1].hardware_info['output_bitwidth'] == 16:
                    psum_x = col_out * math.floor((row_out * math.floor((ch_out - 1) / 32) + row_out - 1) / 16) + col_out
                psum_x = self._check_res_psum(psum_x, node, sram_data_map_list)

            if('avgpool_flag' in sub_node_list[0].conv_param
               and sub_node_list[0].conv_param['avgpool_flag']):
                input_bw = sub_node_list[0].hardware_info['input_bitwidth']
                output_bw = sub_node_list[0].hardware_info['output_bitwidth']
                i_row, i_col = sub_node_list[0].input_shape[0][2], sub_node_list[0].input_shape[0][3]
                if input_bw == output_bw:
                    [out_x, out_y] = [((i*row_out) // 16) * col_out, (i*row_out) % 16]
                    [in1_x, in1_y] = [((i*i_row) // 16) * i_col, (i*i_row) % 16]
                else:
                    if input_bw == 8:
                        [in1_x, in1_y] = [((i*i_row) // 16) * i_col, (i*i_row) % 16]
                        [out_x, out_y] = [((i*row_out)*2 // 16) * col_out, (i*row_out*2) % 16]
                    else:
                        [in1_x, in1_y] = [((i*i_row*2) // 16) * i_col, (i*i_row*2) % 16]
                        [out_x, out_y] = [((i*row_out) // 16) * col_out, (i*row_out) % 16]
        bm_reg_dict = {'AB_order': AB_order, 'upsample': upsample,
            'in1_x': in1_x, 'in1_y': in1_y, 'in2_x': in2_x,
            'in2_y': in2_y, 'out_x': out_x, 'out_y': out_y,
            'psum_x': psum_x, 'psum_y': psum_y}
        reg_new.get_bm_reg(bm_reg_dict)
  
    # def _check_res_psum(self, psum_x, node, sram_data_map_list):
    #     for sram_data_map in sram_data_map_list:
    #         if (node.index == sram_data_map.node_id):
    #             psum_x = sram_data_map.offset[0] + psum_x
    #     return psum_x
        # offset_x = 0
    def _check_res_psum(self, psum_x, node, sram_data_map_list):
        offset_x = 0
        max_ = 0
        for sram_data_map in sram_data_map_list:
            if node.index == sram_data_map.node_id:
                offset_x = sram_data_map.offset[0]
                if offset_x > psum_x:
                    max_ = offset_x
                else:
                    max_ = psum_x
        if offset_x != 0:
            psum_x = max_ * 2
        return psum_x
    
    def _isResButStartNodeNotInRes(self, node, node_list):
        if node.children[0].op_type == NodeOpType.AddNode:
            AddNode = node.children[0]
            [p1, p2] = AddNode.parents
            currNode = None
            startNode = None
            if(len(p1.children) == 2):
                currNode = p2
                startNode = p1
            else:
                currNode = p1
                startNode = p2
            if(len(startNode.children) != 2):
                return False
            branchLen = 0
            while(currNode != startNode):
                branchLen += 1
                if (len(currNode.parents) != 1):
                    return False
                currNode = currNode.parents[0]
            if (branchLen and startNode not in node_list):
                return True
            else:
                return False

    def _get_parent_offset(self, parent_node, node, sram_data_map_list):
        offset = None 
        for sram_data_map in sram_data_map_list:
            if parent_node.index == sram_data_map.node_id:
                offset = sram_data_map.offset
        ## if not find the offset of parent node, curr_node must be the start of a group and it is not a didma node
        if(offset == None):
            offset = [0, 0]
        return offset
    
    
    def gen_cu_crop_pad_reg(self,sub_id, node, sub_node_list, out_chunk, in_chunk, cmd_node, reg_new):
        # cu, crop, pad
        mode_dict = {
            'BYPASS': 0,
            'CONV3x3': 1,
            'CONV3x3RGBA': 2,
            'CONV3x3DW': 3,
            'CONV1x1': 4,
            'ELE_ADD': 5,
            'ELE_MUL': 6
        }
        ich = in_chunk['ch_ed'] - in_chunk['ch_st'] + 1
        row_in_num = in_chunk['row_ed'] - in_chunk['row_st'] + 1
        col_in_num = in_chunk['col_ed'] - in_chunk['col_st'] + 1
        first_node = sub_node_list[0]
        ## get kernel shape
        if first_node.op_type == NodeOpType.ConvNode:
            [kernel_row, kernel_col] = first_node.conv_param['kernel_shape']
        else:
            [kernel_row, kernel_col] = [1, 1]
        if first_node.op_type == NodeOpType.ConvNode:
            ## get trim and pad
            trim = first_node.conv_param['strides'][0] - 1
            [pad1_t, pad1_b, pad2_l, pad2_r] \
                = self._get_pad(first_node.conv_param['pads'], cmd_node)
            ## get mode
            if ('group' in first_node.conv_param.keys()
                and first_node.conv_param['group'] != 1):
                ## depthwise conv
                mode = mode_dict['CONV3x3DW']
            elif ('dilations' in first_node.conv_param.keys() and first_node.conv_param['dilations'] != [1, 1]):
                ## dilated conv
                mode = mode_dict['CONV1x1']
            else:
                ## normal conv
                if first_node.conv_param['kernel_shape'] == [3,3]:
                    if ich <= 4: #input channel <= 4
                        mode = mode_dict['CONV3x3RGBA']
                    else:
                        mode = mode_dict['CONV3x3']
                elif first_node.conv_param['kernel_shape'] == [1,1]:
                    mode = mode_dict['CONV1x1']
                else: ## big kernel conv
                    if ich <= 4:
                        mode = mode_dict['CONV3x3RGBA']
                    else:
                        mode = mode_dict['CONV3x3']
        else:
            if first_node.op_type == NodeOpType.AddNode:
                mode = mode_dict['ELE_ADD']
                trim = 0
            else:
                mode = mode_dict['BYPASS']
                trim = 0
            pad1_t = 0
            pad1_b = 0
            pad2_l = 0
            pad2_r = 0

        if sub_node_list[0].hardware_info['input_bitwidth'] == 8:
            input_bw = 0
        elif sub_node_list[0].hardware_info['input_bitwidth'] == 16 or \
            sub_node_list[0].hardware_info['input_bitwidth'] == 14:
            input_bw = 1
        if sub_node_list[-1].hardware_info['output_bitwidth'] == 8:
            output_bw = 0
        elif sub_node_list[-1].hardware_info['output_bitwidth'] == 16 or \
            sub_node_list[-1].hardware_info['output_bitwidth'] == 14:
            output_bw = 1
        # get full_ch and ch_st
        full_ch = 1
        ch_st = 0
        # get crop
        row_st, col_st = 0, 0
        row_out = row_in_num
        col_out = col_in_num
        ## process the extra row and col
        extra_row = (row_in_num + pad1_t + pad1_b - kernel_row)%(trim + 1)
        if extra_row != 0:
            if extra_row <= pad1_b:
                pad1_b -= extra_row
            else:
                pad1_b = 0
                row_out -= extra_row - pad1_b
        extra_col = (col_in_num + pad2_l + pad2_r - kernel_col)%(trim + 1)
        if extra_col != 0:
            if extra_col <= pad2_r:
                pad2_r -= extra_col
            else:
                pad2_r = 0
                col_out -= extra_col - pad2_r
        row_st, col_st = 0, 0
        row_out = math.floor((row_in_num + pad1_t + pad1_b - kernel_row)/(trim + 1)) * (trim + 1) - pad1_t - pad1_b + kernel_row
        col_out = math.floor((col_in_num + pad2_l + pad2_r - kernel_col)/(trim + 1)) * (trim + 1) - pad2_l - pad2_r + kernel_col
        endOfBranch = False
        resStInSameGrp = True
        didmaAddChild = False
        child = node.children[0]

        if(len(node.children) == 1 and (child.op_type == NodeOpType.AddNode or (child.op_type == NodeOpType.HardwareFusionNode and child.sub_node_list[0].op_type == NodeOpType.AddNode))):
            assert(len(child.parents) == 2), "Not Add Node!"
            if(child.parents[0] in cmd_node.contents.node_list and child.parents[1] in cmd_node.contents.node_list):
                endOfBranch = True
                resStInSameGrp = True
            else:
                pNode = child.parents[0]
                if(pNode == node):
                    pNode = child.parents[1]
                if(pNode not in cmd_node.contents.node_list and self.checkStofRes(pNode, child)):
                    endOfBranch = True
                    resStInSameGrp = False
                    if(child.op_type == NodeOpType.AddNode):
                        didmaAddChild = N900HWToolBox().is_DIDMA_Add(child)
                    else:
                        didmaAddChild = N900HWToolBox().is_DIDMA_Add(child.sub_node_list[0]) 
        if(endOfBranch and not didmaAddChild):
            pNode = node.children[0].parents[0]
            if(len(node.children[0].parents[1].children) == 2):
                pNode = node.children[0].parents[1]
            assert(len(pNode.children) == 2), "Wrong Node!"
            row_out_st_other, row_out_ed_other = self.get_row_out_other_side(sub_id, node, pNode, cmd_node, type = resStInSameGrp)
            row_out_st, row_out_ed = out_chunk["row_st"], out_chunk["row_ed"]
            assert(row_out_st_other <= row_out_st and row_out_ed_other >= row_out_ed), "Wrong other side row out!"
            pad1_t += row_out_st - row_out_st_other
            pad1_b += row_out_ed_other - row_out_ed
        ### if node is add node or hw node starting with add node, change the row_st and row_out
        endOfRes = False
        resStInSameGrp = True
        didmaAdd = False
        if(node.op_type == NodeOpType.AddNode or (node.op_type == NodeOpType.HardwareFusionNode and node.sub_node_list[0].op_type == NodeOpType.AddNode)):
            for pNode in node.parents:
                if(self.checkStofRes(pNode, node)):
                    endOfRes = True
                    resStInSameGrp = pNode in cmd_node.contents.node_list
                    if(node.op_type == NodeOpType.AddNode):
                        didmaAdd = N900HWToolBox().is_DIDMA_Add(node)
                    else:
                        didmaAdd = N900HWToolBox().is_DIDMA_Add(node.sub_node_list[0])
                    break
        if(endOfRes and not didmaAdd):
            row_out_st_p, row_out_ed_p = self.get_row_out_parent(node, sub_id, cmd_node, type = resStInSameGrp)
            row_st = in_chunk["row_st"] - row_out_st_p
            row_out = in_chunk["row_ed"] - in_chunk["row_st"] + 1
            assert(row_st + row_out - 1 <= row_out_ed_p), "Out of input range!"
        cu_reg_dict = {'mode': mode, 'trim': trim, 'input_bw': input_bw, 'output_bw': output_bw, 'full_ch': full_ch, 
            'ch_st': ch_st, 'kernel_row': kernel_row, 'kernel_col': kernel_col}
        crop_reg_dict = {'col_st': col_st, 'col_out': col_out,
            'row_st': row_st, 'row_out': row_out}
        pad_reg_dict = {'pad1_b': pad1_b, 'pad1_t': pad1_t,
            'pad2_l': pad2_l, 'pad2_r': pad2_r}
        reg_new.get_cu_reg(cu_reg_dict)
        reg_new.get_crop_reg(crop_reg_dict)
        reg_new.get_pad_reg(pad_reg_dict)

    def get_row_out_other_side(self, sub_id, node, pNode, cmd_node, type):
        ## type is True, means the pNode is in the same grp with node
        ## node_list of cmd_node assures containing node 
        if(not type):
            chunk = cmd_node.contents.input_chunk[0][cmd_node.chunk_id]
        else:
            while(node != pNode):
                node = node.parents[0]
                sub_id -= 1
            chunk = cmd_node.contents.output_chunk[sub_id][cmd_node.chunk_id]
        return chunk["row_st"], chunk["row_ed"]
    
    def _get_pad(self, pad_list, cmd_node):
        if cmd_node.chunk_id == 0:
            pad1_t = pad_list[0]
        else:
            pad1_t = 0
        if cmd_node.chunk_id == cmd_node.contents.chunk_num - 1:
            pad1_b = pad_list[2]
        else:
            pad1_b = 0
        pad2_l = pad_list[1]
        pad2_r = pad_list[3]
        return [pad1_t, pad1_b, pad2_l, pad2_r]

    def gen_shape_reg(self,sub_id, node, sub_node_list, in_chunk, out_chunk, reg_new, cmd_node):
        input_bw = sub_node_list[0].hardware_info['input_bitwidth']
        pool_en = False
        for sub_node in sub_node_list:
            if sub_node.op_type in [NodeOpType.MaxPoolNode, NodeOpType.AveragePoolNode]:
                pool_en = True
        row = in_chunk['row_ed'] - in_chunk['row_st'] + 1
        col = in_chunk['col_ed'] - in_chunk['col_st'] + 1
        origin_ich = (in_chunk['ch_ed'] - in_chunk['ch_st']) + 1
        origin_och = (out_chunk['ch_ed'] - out_chunk['ch_st']) + 1
        if origin_ich <= 4:
            ich = 4
            och_st = 0
            och_ed = math.ceil(origin_och/16) * 16 - 1
        else:
            if(sub_node_list[0].op_type == NodeOpType.ConvNode \
                and ("group" not in sub_node_list[0].conv_param.keys() \
                    or ("group" in sub_node_list[0].conv_param.keys() \
                and sub_node_list[0].conv_param["group"] == 1))):
                if input_bw == 16 or input_bw == 14:
                    ich = math.ceil(origin_ich / 32) * 32
                elif input_bw == 8:
                    ich = math.ceil(origin_ich / 64) * 64
                och_st = 0
                och_ed = math.ceil(origin_och/16) * 16 - 1
            else:
                if not pool_en:
                    if input_bw == 16 or input_bw == 14:
                        ich = math.ceil(origin_ich / 32) * 32
                    elif input_bw == 8:
                        ich = math.ceil(origin_ich / 64) * 64
                else:
                    ich = math.ceil(origin_ich / 16) * 16
                och_st = 0
                och_ed = ich - 1
        if sub_node_list[0].op_type == NodeOpType.ConvNode:
            if ('avgpool_flag' in sub_node_list[0].conv_param
                and sub_node_list[0].conv_param['avgpool_flag']):
                input_bw = sub_node_list[0].hardware_info['input_bitwidth']
                output_bw = sub_node_list[0].hardware_info['output_bitwidth']
                if input_bw == 16 and output_bw == 16:
                    ich = 32
                else:
                    ich = 64
        endOfRes = False
        resStInSameGrp = True
        didmaAdd = False
        if(node.op_type == NodeOpType.AddNode or (node.op_type == NodeOpType.HardwareFusionNode and node.sub_node_list[0].op_type == NodeOpType.AddNode)):
            for pNode in node.parents:
                if(self.checkStofRes(pNode, node)):
                    endOfRes = True
                    resStInSameGrp = pNode in cmd_node.contents.node_list
                    if(node.op_type == NodeOpType.AddNode):
                        didmaAdd = N900HWToolBox().is_DIDMA_Add(node)
                    else:
                        didmaAdd = N900HWToolBox().is_DIDMA_Add(node.sub_node_list[0])
        if(endOfRes and not didmaAdd):
            row_out_st_p, row_out_ed_p = self.get_row_out_parent(node, sub_id, cmd_node, type = resStInSameGrp)
            row = max(row, row_out_ed_p - row_out_st_p + 1)
        reg_dict = {'row': row, 'col': col, 'ich': ich, \
            'och_st': och_st, 'och_ed': och_ed}
        reg_new.get_shape_reg(reg_dict)

    def gen_nl_reg(self, sub_node_list, cmd_node, reg_new):
        pool_mode = 0
        pool_kernel = 0
        pool_stride = 0
        relu_mode = 0
        pool_en = 0
        relu_en = 0
        bn_en = 0
        nl_en = 0
        nl_order = 0
        t = 0
        b = 0
        l = 0
        r = 0
        act_lut_en = 0
        nl_op_list = []
        for sub_node in sub_node_list:
            if sub_node.op_type == NodeOpType.BatchNormalizationNode:
                nl_op_list.append('BN')
                nl_en = 1
                bn_en = 1
            elif (sub_node.op_type == NodeOpType.NormalReluNode
                or sub_node.op_type == NodeOpType.LeakyReluNode
                or sub_node.op_type == NodeOpType.PReluNode
                or sub_node.op_type == NodeOpType.ClipNode):
                # or sub_node.op_type == NodeOpType.Relu6):
                nl_op_list.append('RELU')
                nl_en = 1
                relu_en = 1
                if sub_node.op_type == NodeOpType.NormalReluNode:
                    relu_mode = 0
                elif (sub_node.op_type == NodeOpType.LeakyReluNode
                    or sub_node.op_type == NodeOpType.PReluNode):
                    relu_mode = 1
                elif sub_node.op_type == NodeOpType.ClipNode:
                    relu_mode = 2
            elif (sub_node.op_type == NodeOpType.AveragePoolNode
                or sub_node.op_type == NodeOpType.MaxPoolNode):
                nl_op_list.append('POOL')
                nl_en = 1
                pool_en = 1
                if sub_node.op_type == NodeOpType.AveragePoolNode:
                    pool_mode = 1
                    pool_kernel = sub_node.avgpool_param['kernel_shape'][0] - 2
                    pool_stride = sub_node.avgpool_param['strides'][0] - 1
                    [t, b, l, r] = self._get_pad(sub_node.avgpool_param['pads'], cmd_node)
                elif sub_node.op_type == NodeOpType.MaxPoolNode:
                    pool_mode = 0
                    pool_kernel = sub_node.maxpool_param['kernel_shape'][0] - 2
                    pool_stride = sub_node.maxpool_param['strides'][0] - 1
                    [t, b, l, r] = self._get_pad(sub_node.maxpool_param['pads'], cmd_node)
            elif (sub_node.op_type in lut_node_type):
                input_bitwidth = sub_node.hardware_info["input_bitwidth"]
                if(input_bitwidth == 16):
                    act_lut_en = 1
                elif(input_bitwidth == 14):
                    act_lut_en = 2
                elif(input_bitwidth == 12):
                    act_lut_en = 3
                else:
                    assert(False), "Illegal input_bitwidth of Lut Node!!"
        nl_order = self._gen_nl_order(nl_op_list)
        nl_reg_dict = {
            'pool_mode': pool_mode, 'pool_kernel': pool_kernel, 
            'pool_stride': pool_stride, 'relu_mode': relu_mode,
            'pool_en': pool_en, 'relu_en': relu_en, 'bn_en': bn_en,
            'nl_en': nl_en, 'nl_order': nl_order,
            't': t, 'b': b, 'l': l, 'r': r, 'act_lut_en': act_lut_en}
        reg_new.get_nl_reg(nl_reg_dict)

    def _gen_nl_order(self, nl_op_list):
        # BN_RELU_POOL = 0;
        # BN_POOL_RELU = 1;
        # RELU_BN_POOL = 2;
        # RELU_POOL_BN = 3;
        # POOL_BN_RELU = 4;
        # POOL_RELU_BN = 5;
        first_order = 0
        second_order = 0
        for i in range(len(nl_op_list)):
            if i == 0:
                if nl_op_list[i] == 'BN':
                    first_order = 0
                elif nl_op_list[i] == 'RELU':
                    first_order = 1
                else: #nl_op_list[i] == 'POOL'
                    first_order = 2
            elif i == 1:
                if first_order == 0:
                    if nl_op_list[i] == 'RELU':
                        second_order = 0
                    else:
                        second_order = 1
                elif first_order == 1:
                    if nl_op_list[i] == 'BN':
                        second_order = 0
                    else:
                        second_order = 1
                else: #first_order == 2
                    if nl_op_list[i] == 'BN':
                        second_order = 0
                    else:
                        second_order = 1
        nl_order = 2 * first_order + second_order
        return nl_order
    
    def get_row_out_parent(self, node, sub_id, cmd_node, type):
        ## type is True, means the pNode is in the same grp with node
        ## node_list of cmd_node assures containing node 
        assert(len(node.parents) == 2), "Not add node!"
        if(not type):
            chunk = cmd_node.contents.input_chunk[0][cmd_node.chunk_id]
        else:
            pNode = node.parents[0]
            bpNode = node.parents[1]
            if(len(node.parents[1].children) == 2):
                pNode, bpNode = bpNode, pNode
            sameGroup = pNode in cmd_node.contents.node_list
            if not sameGroup:
                return sameGroup, 0, 0
            id = sub_id - 1
            currNode = bpNode
            while(currNode != pNode):
                id -= 1
                currNode = currNode.parents[0]
            chunk = cmd_node.contents.output_chunk[id][cmd_node.chunk_id]
        return chunk["row_st"], chunk["row_ed"]
    
    def checkStofRes(self, stNode, edNode):
        if(len(stNode.children) != 2):
            return False
        if(stNode.children[0] == edNode):
            node = stNode.children[1]
        else:
            node = stNode.children[0]
        while(node != edNode):
            if(len(node.children) != 1):
                return False
            node = node.children[0]
        return True 
        