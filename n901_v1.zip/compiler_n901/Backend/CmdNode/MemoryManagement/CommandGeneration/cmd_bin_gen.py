import struct
import pdb
class CommandBinGen(object):
    def __init__(self):
        pass

    def _write_val(self, val_old, val_new, all_write, reg_id_byte, f_cmd):
        cmd_len = 0
        if val_new != val_old or all_write == True:
            f_cmd.write(reg_id_byte) 
            val_w = struct.pack(">H", int(val_new))
            f_cmd.write(val_w)
            cmd_len += 4
        return cmd_len

    def gen_cmd_bin(self, reg_old, reg_new, f_cmd, all_write, write_och):
        ## initialize cmd_len
        cmd_len = 0
        ## generate reg write cmd only if new register is different from old register
        ## REGW: CONV_MODE
        val_old = reg_old.mode + reg_old.trim * 2**8 + reg_old.input_bw * 2 ** 10 \
            + reg_old.output_bw * 2 ** 11 + reg_old.AB_order * 2**12 \
            + reg_old.full_ch * 2**13 + reg_old.ch_st * 2**14 + reg_old.upsample * 2**15
        val_new = reg_new.mode + reg_new.trim * 2**8 + reg_new.input_bw * 2 ** 10 + \
            reg_new.output_bw * 2 ** 11 + reg_new.AB_order * 2**12 \
            + reg_new.full_ch * 2**13 + reg_new.ch_st * 2**14 + reg_new.upsample * 2**15
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x02', f_cmd)
        ## REGW FM_ROW
        val_old = reg_old.row
        val_new = reg_new.row
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x03', f_cmd)
        ## REGW FM_COL
        val_old = reg_old.col
        val_new = reg_new.col
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x04', f_cmd)
        ## REGW FM_ICH
        val_old = reg_old.ich
        val_new = reg_new.ich
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x05', f_cmd)
        ## REGW FM_OCH_ST
        val_old = reg_old.och_st
        val_new = reg_new.och_st
        if write_och == True:
            cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x06', f_cmd)
        ## REGW FM_OCH_ED
        val_old = reg_old.och_ed
        val_new = reg_new.och_ed
        if write_och == True:
            cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x07', f_cmd)
        ## REGW NL_MODE
        val_old = reg_old.pool_mode + reg_old.pool_kernel * 2 ** 2 + reg_old.pool_stride * 2 ** 3 + reg_old.relu_mode * 2 ** 5 + reg_old.pool_en * 2 ** 7\
            + reg_old.relu_en * 2 ** 8 + reg_old.bn_en * 2 ** 9 + reg_old.nl_en * 2 ** 10 + reg_old.nl_order * 2 ** 11 + reg_old.act_lut_en * 2 ** 14
        val_new = reg_new.pool_mode + reg_new.pool_kernel * 2 ** 2 + reg_new.pool_stride * 2 ** 3 + reg_new.relu_mode * 2 ** 5 + reg_new.pool_en * 2 ** 7\
            + reg_new.relu_en * 2 ** 8 + reg_new.bn_en * 2 ** 9 + reg_new.nl_en * 2 ** 10 + reg_new.nl_order * 2 ** 11 + reg_new.act_lut_en * 2 ** 14
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x08', f_cmd)
        ## REGW POOL_PAD
        val_old = reg_old.r + reg_old.l * 2 ** 2 + reg_old.b * 2 ** 4 + reg_old.t * 2 ** 6
        val_new = reg_new.r + reg_new.l * 2 ** 2 + reg_new.b * 2 ** 4 + reg_new.t * 2 ** 6
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x09', f_cmd)
        ## REGW MEM_IN1
        val_old = reg_old.in1_offset_y + reg_old.in1_offset_x * 2 ** 4
        val_new = reg_new.in1_offset_y + reg_new.in1_offset_x * 2 ** 4
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x0a', f_cmd)
        ## REGW MEM_IN2
        val_old = reg_old.in2_offset_y + reg_old.in2_offset_x * 2 ** 4
        val_new = reg_new.in2_offset_y + reg_new.in2_offset_x * 2 ** 4
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x0b', f_cmd)
        ## REGW MEM_OUT
        val_old = reg_old.out_offset_y + reg_old.out_offset_x * 2 ** 4
        val_new = reg_new.out_offset_y + reg_new.out_offset_x * 2 ** 4
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x0c', f_cmd)
        ## REGW CROP
        val_old = reg_old.col_st + reg_old.row_st * 2 ** 8
        val_new = reg_new.col_st + reg_new.row_st * 2 ** 8
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x0d', f_cmd)
        ## REGW CROP_ROW
        val_old = reg_old.row_out
        val_new = reg_new.row_out
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x0e', f_cmd)
        ## REGW CROP_COL
        val_old = reg_old.col_out
        val_new = reg_new.col_out
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x0f', f_cmd)
        ## REGW PAD1
        val_old = reg_old.pad1_b + reg_old.pad1_t * 2 ** 8
        val_new = reg_new.pad1_b + reg_new.pad1_t * 2 ** 8
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x10', f_cmd)
        ## REGW PAD2
        val_old = reg_old.pad2_r + reg_old.pad2_l * 2 ** 8
        val_new = reg_new.pad2_r + reg_new.pad2_l * 2 ** 8
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x11', f_cmd)
        ## REGW MEM_PSM
        val_old = reg_old.psum_offset_y + reg_old.psum_offset_x * 2 ** 4
        val_new = reg_new.psum_offset_y + reg_new.psum_offset_x * 2 ** 4
        cmd_len += self._write_val(val_old, val_new, all_write, b'\x58\x12', f_cmd)
        ## CONV + NOP 
        f_cmd.write(b'\x40\x00\x00\x00') 
        cmd_len += 4
        return cmd_len
