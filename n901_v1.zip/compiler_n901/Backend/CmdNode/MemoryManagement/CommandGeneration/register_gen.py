import struct
import math
import copy

from Backend.CmdNode.MemoryManagement.CommandGeneration.registers_arrange import RegistersArrange
from Frontend.Node.node_def import NodeOpType
from Backend.CmdNode.MemoryManagement.CommandGeneration.update_data_map import UpdateDataMap
from Backend.CmdNode.MemoryManagement.CommandGeneration.cmd_bin_gen import CommandBinGen

from Backend.CmdNode.MemoryManagement.CommandGeneration.gen_cmd_toolbox import GenCmdToolbox

import pdb

class RegisterGen(object):
    ## maintain the register and the map relation shipe between node and data in sram
    def __init__(self):
        ## contains the relationship between data in sram and hardwarefusion node
        self._sram_data_map_list = []
        self.reg_old = None
        self.reg_new = None

    # def didma_update_sram_data_map(self, cmd_node, didma_id, sub_id, datanode_dict, cmd_node_list):
    #     UpdateDataMap(self._sram_data_map_list)\
    #         .didma_update_sram_data_map(cmd_node, didma_id, sub_id, datanode_dict, cmd_node_list)
    def didma_update_sram_data_map(self, cmd_node, didma_id, datanode_in_id, sub_id, datanode_dict, cmd_node_list):
        UpdateDataMap(self._sram_data_map_list)\
            .didma_update_sram_data_map(cmd_node, didma_id, datanode_in_id, sub_id, datanode_dict, cmd_node_list)
        
    def pipo_update_sram_data_map(self, cmd_node, sub_id, needOffset = False, getOffset = False, OffsetFromOut = True, offset = 0, pipoIdx = 0):
        offset = UpdateDataMap(self._sram_data_map_list).pipo_update_sram_data_map(cmd_node, sub_id, needOffset, getOffset, offset, pipoIdx, OffsetFromOut)
        if(getOffset):
            return offset
        return 0

    def gen_single_cmd_len(self, curr_node, sub_node_list, cmd_node, sub_id, f_cmd):
        first_node = sub_node_list[0]
        if first_node.op_type == NodeOpType.ConvNode:
            if ('group' in first_node.conv_param.keys()
                and first_node.conv_param['group'] != 1
                and first_node.conv_param['kernel_shape'] != [3,3]):
                cmd_len = self._get_big_kernel_cmd_bin(curr_node, sub_node_list, cmd_node, sub_id, f_cmd, "conv_dw")
            elif (first_node.conv_param['kernel_shape'] != [3,3]
                and sub_node_list[0].conv_param['kernel_shape'] != [1,1]
                and 'avgpool_flag' in sub_node_list[0].conv_param
                and sub_node_list[0].conv_param['avgpool_flag']):
                cmd_len = self._get_big_kernel_avgpool_cmd_bin(curr_node, sub_node_list, cmd_node, sub_id, f_cmd, "conv")
            elif (first_node.conv_param['kernel_shape'] != [3,3]
                and sub_node_list[0].conv_param['kernel_shape'] != [1,1]):
                cmd_len = self._get_big_kernel_cmd_bin(curr_node, sub_node_list, cmd_node, sub_id, f_cmd, "conv")
            elif ("dilations" in first_node.conv_param.keys()
                and first_node.conv_param["dilations"] != [1,1]):
                cmd_len = self._get_big_kernel_cmd_bin(curr_node, sub_node_list, cmd_node, sub_id, f_cmd, "dilated")
            else:
                if first_node.conv_param['kernel_shape'][0]==1 and first_node.conv_weight.shape[2] > 2048:
                    cmd_len = self._get_vgg_conv1x1_cmd_bin(curr_node, sub_node_list, cmd_node, sub_id, f_cmd)
                else:
                    self._get_registers(curr_node, sub_node_list, cmd_node, sub_id)
                    cmd_len = self._gen_cmd_bin(f_cmd, all_write=(sub_id == 0))
        else:## bypass or elementwise add
            self._get_registers(curr_node, sub_node_list, cmd_node, sub_id)
            cmd_len = self._gen_cmd_bin(f_cmd, all_write=(sub_id == 0))
        return cmd_len
    
    def _get_vgg_conv1x1_cmd_bin(self, curr_node, sub_node_list, cmd_node, sub_id, f_cmd):
        cmd_len = 0
        first_node = sub_node_list[0]
        ich, och = first_node.conv_weight.shape[2], first_node.conv_weight.shape[3]
        w_2048_c = math.ceil(ich/2048)
        w_2048_f = math.ceil(och/2048)
        if och > 2048:
            loop_cnt = math.ceil(2048/16) - 2
        else:
            loop_cnt = math.ceil(och/16) -2 
        last_2048_c = False
        last_2048_f = False
        for i in range(w_2048_f):
            if i == w_2048_f-1:
                last_2048_f = True
            else:
                last_2048_f = False
            for j in range(2):
                if j == 0:
                    for k in range(w_2048_c):
                        if k == w_2048_c -1:
                            last_2048_c = True
                        else:
                            last_2048_c = False
                        if (last_2048_c==True):
                            self._gen_vgg_gemm_registers(curr_node, sub_node_list, cmd_node, sub_id, last_2048_f, last_2048_c)
                            cmd_len += self._gen_cmd_bin(f_cmd, all_write=(sub_id == 0))
                            self.reg_old = self.reg_new
                        else:
                            self._gen_vgg_gemm_registers(curr_node, sub_node_list, cmd_node, sub_id, last_2048_f, last_2048_c)
                            cmd_len += self._gen_cmd_bin(f_cmd)
                            self.reg_old = self.reg_new
                else:
                    self._loop_cnt_w2bin(loop_cnt, f_cmd)
                    cmd_len += 4
                    # REG_INC och_st and och_ed
                    self._och_reg_inc_w2bin(f_cmd)
                    cmd_len += 8
                    cmd_num = 2
                    for k in range(w_2048_c):
                        if k == w_2048_c -1:
                            last_2048_c = True
                        else:
                            last_2048_c = False
                        if (last_2048_c==True):
                            self._gen_vgg_gemm_registers(curr_node, sub_node_list, cmd_node, sub_id, last_2048_f, last_2048_c)
                            cmd_len_16ch = self._gen_cmd_bin(f_cmd, all_write=True, write_och=False)
                            cmd_len += cmd_len_16ch
                            cmd_num += cmd_len_16ch/4
                            self.reg_old = self.reg_new
                        else:
                            self._gen_vgg_gemm_registers(curr_node, sub_node_list, cmd_node, sub_id, last_2048_f, last_2048_c)
                            cmd_len_16ch = self._gen_cmd_bin(f_cmd, all_write=False, write_och=False)
                            cmd_len += cmd_len_16ch
                            cmd_num += cmd_len_16ch/4
                            self.reg_old = self.reg_new
                    ## LOOP
                    self._loop_w2bin(cmd_num, f_cmd)
                    cmd_len += 4
        return cmd_len
    def _gen_vgg_gemm_registers(self, curr_node, sub_node_list, cmd_node, sub_id, last_2048_f, last_2048_c):
        if curr_node.op_type == NodeOpType.HardwareFusionNode:
            first_node = curr_node.sub_node_list[0]
        else:
            first_node = curr_node
        self._get_registers(curr_node, sub_node_list, cmd_node, sub_id)
        ich = first_node.input_shape[0][1]
        och = first_node.shape[1]
        if ich > 2048:
            self.reg_new.ich = 2048
        if (last_2048_c==False):
            self.reg_new.och_st = 0
            self.reg_new.och_ed = 15
            self.reg_new.ch_st = 0
            self.reg_new.full_ch = 0
            self.reg_new.in1_offset_x = 0
        else:
            self.reg_new.och_st = 0
            self.reg_new.och_ed = 15
            self.reg_new.ch_st = 1
            self.reg_new.full_ch = 1
            self.reg_new.in1_offset_x =  self.get_in_offset_x(first_node)
        if (last_2048_f==False):
            self.reg_new.out_offset_x = 0
            self.reg_new.out_offset_y = 0
        else:
            self.reg_new.out_offset_x = self.get_out_offset_x(first_node)
            self.reg_new.out_offset_y = self.get_out_offset_y(first_node)
        if och <= 2048:
            self.reg_new.out_offset_x = 0
            self.reg_new.out_offset_y = 0
    def _get_big_kernel_avgpool_cmd_bin(self, curr_node, sub_node_list, cmd_node, sub_id, f_cmd, mode=None):
        cmd_len, cmd_len_ = 0, 0
        och = curr_node.shape[1]
        input_bw = curr_node.hardware_info['input_bitwidth']
        output_bw = curr_node.hardware_info['output_bitwidth']
        cmd_node.cmd_len_list = []
        if input_bw == 16 and output_bw == 16:
            loop_cnt = math.ceil(och/32)
            for i in range(loop_cnt):
                cmd_len += self._get_pool2conv_cmd_bin(curr_node, sub_node_list, cmd_node, sub_id, f_cmd, i, "conv")
                if i != loop_cnt - 1:
                    f_cmd.write(b'\x30\x02\x00\x00') # INT + NOP
                    f_cmd.write(b'\x10\x01\x00\x00') # SYNC + NOP
                    cmd_len += 8
                    cmd_node.cmd_len_list.append(cmd_len)
                    cmd_len = 0
                else:
                    cmd_node.cmd_len_list.append(cmd_len)
            for cmd_len in cmd_node.cmd_len_list:
                cmd_len_ += cmd_len
        else:
            loop_cnt = math.ceil(och/64)
            for i in range(loop_cnt):
                cmd_len += self._get_pool2conv_cmd_bin(curr_node, sub_node_list, cmd_node, sub_id, f_cmd, i, "conv")
                if i != loop_cnt - 1:
                    f_cmd.write(b'\x30\x02\x00\x00') # INT + NOP
                    f_cmd.write(b'\x10\x01\x00\x00') # SYNC + NOP
                    cmd_len += 8
                    cmd_node.cmd_len_list.append(cmd_len)
                    cmd_len = 0
                    # f_cmd.write(b'\x40\x00\x00\x00')
                    # cmd_len += 4
                else:
                    cmd_node.cmd_len_list.append(cmd_len)
            for cmd_len in cmd_node.cmd_len_list:
                cmd_len_ += cmd_len
        return cmd_len_
    
    def _get_pool2conv_cmd_bin(self, curr_node, sub_node_list, cmd_node, sub_id, f_cmd, i, mode=None):
        cmd_len = 0
        self._get_registers(curr_node, sub_node_list, cmd_node, sub_id, i)
        reg_big_kernel = self.reg_new
        ## get first conv node
        first_node = sub_node_list[0]
        ## get parameters
        och = reg_big_kernel.och_ed - reg_big_kernel.och_st + 1
        input_bw = sub_node_list[0].hardware_info['input_bitwidth']
        output_bw = sub_node_list[0].hardware_info['output_bitwidth']
        if input_bw == 16 and output_bw == 16:
            num_16f = math.ceil(32/16)
        else:
            num_16f = math.ceil(64/16)
        num_k_row = math.ceil(reg_big_kernel.kernel_row/3)
        num_k_col = math.ceil(reg_big_kernel.kernel_col/3)
        if num_16f >= 2:
            loop_cnt = num_16f - 2 # loop num_16f - 1 times
            for j in range(2):
                f_st = 16 * j
                f_ed = f_st + 16
                if j == 0:
                    for k in range(num_k_row):
                        for z in range(num_k_col):
                            #generate register configuration for single command
                            #config register
                            self._gen_single_registers(first_node, reg_big_kernel, j, k, z, mode)
                            #generate single cmd
                            if k == 0 and z == 0:
                                cmd_len += self._gen_cmd_bin(f_cmd, all_write=(sub_id == 0))
                                self.reg_old = self.reg_new
                            else:
                                cmd_len += self._gen_cmd_bin(f_cmd, all_write=False)
                                self.reg_old = self.reg_new
                else: # j == 1
                    if num_16f >= 2:
                        # LOOP_CNT
                        self._loop_cnt_w2bin(loop_cnt, f_cmd)
                        cmd_len += 4
                        # REG_INC och_st and och_ed
                        self._och_reg_inc_w2bin(f_cmd)
                        cmd_len += 8
                        cmd_num = 2
                        for k in range(num_k_row):
                            for z in range(num_k_col):
                                #generate register configuration for single command
                                #config register
                                self._gen_single_registers(first_node, reg_big_kernel, j, k, z, mode)
                                #generate single cmd
                                if j == 0 and k == 0:
                                    cmd_len_16ch = self._gen_cmd_bin(f_cmd, all_write=True, write_och=False)
                                    cmd_len += cmd_len_16ch
                                    cmd_num += cmd_len_16ch/4
                                    self.reg_old = self.reg_new
                                else:
                                    cmd_len_16ch = self._gen_cmd_bin(f_cmd, all_write=False, write_och=False)
                                    cmd_len += cmd_len_16ch
                                    cmd_num += cmd_len_16ch/4
                                    self.reg_old = self.reg_new
                        ## LOOP
                        self._loop_w2bin(cmd_num, f_cmd)
                        cmd_len += 4
        return cmd_len
    def _get_big_kernel_cmd_bin(self, curr_node, sub_node_list, cmd_node, sub_id, f_cmd, mode=None):
        cmd_len = 0
        ## get config for big kernel
        need_split = False
        last_2048_c = False
        last_2048_f = False
        first_node = sub_node_list[0]
        ich = first_node.conv_weight.shape[2]
        och = first_node.conv_weight.shape[3]
        w_2048_num = math.ceil(och/2048)
        if och > 2048:
            need_split = True
            last_2048_c = True
        for w_2048_f in range(w_2048_num):
            if w_2048_f == w_2048_num -1:
                last_2048_f = True
            self._get_registers(curr_node, sub_node_list, cmd_node, sub_id, need_split=need_split, last_2048_c=last_2048_c, last_2048_f=last_2048_f)
            reg_big_kernel = self.reg_new
            ## get first conv node
            first_node = sub_node_list[0]
            ## get parameters
            och = reg_big_kernel.och_ed - reg_big_kernel.och_st + 1
            num_16f = math.ceil(och/16)
            num_k_row = math.ceil(reg_big_kernel.kernel_row/3)
            num_k_col = math.ceil(reg_big_kernel.kernel_col/3)
            if(mode == 'dilated'):
                num_k_row = reg_big_kernel.kernel_row
                num_k_col = reg_big_kernel.kernel_col
            if num_16f >= 2:
                loop_cnt = num_16f - 2 # loop num_16f - 1 times
            for i in range(2):
                f_st = 16 * i
                f_ed = f_st + 16
                if i == 0:
                    for j in range(num_k_row):
                        for k in range(num_k_col):
                            #generate register configuration for single command
                            #config register
                            self._gen_single_registers(first_node, reg_big_kernel, i, j, k, mode)
                            #generate single cmd
                            if j == 0 and k == 0:
                                cmd_len += self._gen_cmd_bin(f_cmd, all_write=(sub_id == 0))
                                self.reg_old = self.reg_new
                            else:
                                cmd_len += self._gen_cmd_bin(f_cmd, all_write=False)
                                self.reg_old = self.reg_new
                else: # i == 1
                    if num_16f >= 2:
                        # LOOP_CNT
                        self._loop_cnt_w2bin(loop_cnt, f_cmd)
                        cmd_len += 4
                        # REG_INC och_st and och_ed
                        self._och_reg_inc_w2bin(f_cmd)
                        cmd_len += 8
                        cmd_num = 2
                        for j in range(num_k_row):
                            for k in range(num_k_col):
                                #generate register configuration for single command
                                #config register
                                self._gen_single_registers(first_node, reg_big_kernel, i, j, k, mode)
                                #generate single cmd
                                if j == 0 and k == 0:
                                    cmd_len_16ch = self._gen_cmd_bin(f_cmd, all_write=True, write_och=False)
                                    cmd_len += cmd_len_16ch
                                    cmd_num += cmd_len_16ch/4
                                    self.reg_old = self.reg_new
                                else:
                                    cmd_len_16ch = self._gen_cmd_bin(f_cmd, all_write=False, write_och=False)
                                    cmd_len += cmd_len_16ch
                                    cmd_num += cmd_len_16ch/4
                                    self.reg_old = self.reg_new
                        ## LOOP
                        self._loop_w2bin(cmd_num, f_cmd)
                        cmd_len += 4
        return cmd_len

    def _loop_cnt_w2bin(self, loop_cnt, f_cmd):
        val = loop_cnt + 24 * 2 ** 10
        val_w = struct.pack(">H", int(val))
        f_cmd.write(val_w)
        f_cmd.write(b'\x00\x00')

    def _och_reg_inc_w2bin(self, f_cmd):
        # REG_INC och_st
        f_cmd.write(b"\x68\x06")
        val_w = struct.pack(">H", int(16))
        f_cmd.write(val_w)
        # REG_INC och_ed
        f_cmd.write(b"\x68\x07")
        val_w = struct.pack(">H", int(16))
        f_cmd.write(val_w)

    def _loop_w2bin(self, cmd_num, f_cmd):
        val = cmd_num + 1 + 28 * 2 ** 10
        val_w = struct.pack(">H", int(val))
        f_cmd.write(val_w)
        f_cmd.write(b'\x00\x00')

    def _gen_single_registers(self, first_node, reg_big_kernel, i, j, k, mode):
        reg_single = copy.deepcopy(reg_big_kernel)
        cu_in_row = reg_big_kernel.row_out + reg_big_kernel.pad1_t + reg_big_kernel.pad1_b
        cu_in_col = reg_big_kernel.col_out + reg_big_kernel.pad2_l + reg_big_kernel.pad2_r
        cu_out_row = ((cu_in_row - reg_big_kernel.kernel_row)/(reg_big_kernel.trim+1)) + 1
        cu_out_col = ((cu_in_col - reg_big_kernel.kernel_col)/(reg_big_kernel.trim+1)) + 1
        num_k_row = math.ceil(reg_big_kernel.kernel_row/3)
        num_k_col = math.ceil(reg_big_kernel.kernel_col/3)
        if(mode == 'dilated'):
            [dilation1, dilation2] = first_node.conv_param['dilations']
            num_k_row, num_k_col= reg_big_kernel.kernel_row, reg_big_kernel.kernel_col
            dilated_k_row = num_k_row + (num_k_row - 1) * (dilation1 - 1)
            dilated_k_col = num_k_col + (num_k_col - 1) * (dilation2 - 1)
            cu_out_row = ((cu_in_row - dilated_k_row)/(reg_big_kernel.trim+1)) + 1
            cu_out_col = ((cu_in_col - dilated_k_col)/(reg_big_kernel.trim+1)) + 1

        #get psum offset_y
        ich = reg_big_kernel.ich
        num_in_ch_group = math.ceil(ich / 16)
        odd_3x3conv = ((num_k_row * num_k_col) % 2 == 1)
        odd_ich_group = (num_in_ch_group % 2 == 1)
        if(mode == 'conv'):
            if odd_3x3conv and odd_ich_group:
                reg_single.psum_offset_y = 0
            else:
                reg_single.psum_offset_y = 8
        elif(mode == 'conv_dw'):
            if(odd_3x3conv):
                reg_single.psum_offset_y = 0
            else:
                reg_single.psum_offset_y = 8

        #data_range for each command
        data_r_st = 3 * j
        data_r_ed = data_r_st + ((cu_out_row - 1) * (reg_big_kernel.trim+1)) + 3
        data_c_st = 3 * k
        data_c_ed = data_c_st + ((cu_out_col - 1) * (reg_big_kernel.trim+1)) + 3
        if(mode == "dilated"):
            data_r_st = dilation1 * j
            data_r_ed = data_r_st + (cu_out_row - 1) * (reg_big_kernel.trim + 1) + 1
            data_c_st = dilation2 * k
            data_c_ed = data_c_st + (cu_out_col - 1) * (reg_big_kernel.trim + 1) + 1
            reg_single.kernel_row, reg_single.kernel_col = 1, 1
        if(j == num_k_row - 1 and k == num_k_col - 1):
            reg_single.full_ch = 1
        else:
            reg_single.full_ch = 0
            reg_single.nl_en = 0
            reg_single.pool_en = 0
            reg_single.relu_en = 0
            reg_single.bn_en = 0
        if(j == 0 and k == 0):
            reg_single.ch_st = 0
        else:
            reg_single.ch_st = 1
        if ('group' in first_node.conv_param.keys()
            and first_node.conv_param['group'] != 1):
            reg_single.ich = 16
        reg_single.och_st = 16 * i
        reg_single.och_ed = 16 * i + 15
        #data crop and pad
        if(data_r_st < reg_big_kernel.pad1_t):
            reg_single.pad1_t = reg_big_kernel.pad1_t - data_r_st
        else:
            reg_single.pad1_t = 0
            reg_single.row_st += data_r_st - reg_big_kernel.pad1_t
            reg_single.row_out -= data_r_st - reg_big_kernel.pad1_t
        if(data_r_ed > reg_big_kernel.row_out + reg_big_kernel.pad1_t):
            reg_single.pad1_b += data_r_ed - cu_in_row
        else:
            reg_single.pad1_b = 0
            reg_single.row_out -= reg_big_kernel.row_out + reg_big_kernel.pad1_t - data_r_ed
        if(data_c_st < reg_big_kernel.pad2_l):
            reg_single.pad2_l = reg_big_kernel.pad2_l - data_c_st
        else:
            reg_single.pad2_l = 0
            reg_single.col_st += data_c_st - reg_big_kernel.pad2_l
            reg_single.col_out -= data_c_st - reg_big_kernel.pad2_l
        if(data_c_ed > reg_big_kernel.col_out + reg_big_kernel.pad2_l):
            reg_single.pad2_r += data_c_ed - cu_in_col
        else:
            reg_single.pad2_r = 0
            reg_single.col_out -= reg_big_kernel.col_out + reg_big_kernel.pad2_l - data_c_ed
        self.reg_new = reg_single

    def _get_registers(self, curr_node, sub_node_list, cmd_node, sub_id, i=0, need_split=False, last_2048_c=False, last_2048_f=False):
        ## initialize AB_order
        start_AB_order = cmd_node.DIDMA_param[0].dmem
        AB_order = (start_AB_order + sub_id) % 2
        ## extract current input chunk and current output chunk
        in_chunk = cmd_node.contents.input_chunk[sub_id][cmd_node.chunk_id]
        out_chunk = cmd_node.contents.output_chunk[sub_id][cmd_node.chunk_id]
        ## initialize an all-zero register
        self.reg_new = RegistersArrange()
        ## cu, crop, pad
        GenCmdToolbox().gen_cu_crop_pad_reg(sub_id, curr_node, sub_node_list, out_chunk, in_chunk, cmd_node, self.reg_new)
        ## bm
        GenCmdToolbox().gen_bm_reg(curr_node, sub_node_list, AB_order, cmd_node, out_chunk, self.reg_new, self._sram_data_map_list, i)
        ## shape
        GenCmdToolbox().gen_shape_reg(sub_id, curr_node, sub_node_list, in_chunk, out_chunk, self.reg_new, cmd_node)
        ## nl, pool_shape
        GenCmdToolbox().gen_nl_reg(sub_node_list, cmd_node, self.reg_new)
        if (need_split):
            self.change_reg(curr_node,  last_2048_c, last_2048_f)
    def change_reg(self, curr_node,  last_2048_c=False, last_2048_f=False):
        first_node = curr_node.sub_node_list[0]
        ich = first_node.conv_weight.shape[2]
        if ich > 2048:
            self.reg_new.ich = 2048
        if curr_node.op_type == NodeOpType.HardwareFusionNode:
            first_node = curr_node.sub_node_list[0]
            if first_node.op_type == NodeOpType.ConvNode:
                self.reg_new.och_st = 0
                self.reg_new.och_ed = 2047
                if (last_2048_c==True and last_2048_f==True):
                    self.reg_new.out_offset_x = self.get_out_offset_x(curr_node)
                    self.reg_new.out_offset_y = self.get_out_offset_y(curr_node)
                else:
                    self.reg_new.out_offset_x = 0
                    self.reg_new.out_offset_y = 0
                if (last_2048_c==False and last_2048_f==False):
                    self.reg_new.ch_st = 0
                    self.reg_new.in1_offset_x = 0
                    self.reg_new.full_ch = 0
                elif (last_2048_c==False and last_2048_f==True):
                    self.reg_new.ch_st = 1
                    if(ich>2048):
                        self.reg_new.in1_offset_x = self.get_in_offset_x(curr_node)
                    self.reg_new.full_ch = 1
                elif (last_2048_c==True and last_2048_f==False):
                    self.reg_new.ch_st = 0
                    self.reg_new.in1_offset_x = 0
                    self.reg_new.full_ch = 0
                elif(last_2048_c==True and last_2048_f==True):
                    self.reg_new.ch_st = 1
                    if(ich>2048):
                        self.reg_new.in1_offset_x = self.get_in_offset_x(curr_node)
                    self.reg_new.full_ch = 1
        elif curr_node.op_type == NodeOpType.ConvNode:
            self.reg_new.och_st = 0
            self.reg_new.och_ed = 2047
            if (last_2048_c==True and last_2048_f==True):
                self.reg_new.out_offset_x = self.get_out_offset_x(curr_node)
                self.reg_new.out_offset_y = self.get_out_offset_y(curr_node)
            else:
                self.reg_new.out_offset_x = 0
                self.reg_new.out_offset_y = 0
            if (last_2048_c==False and last_2048_f==False):
                self.reg_new.ch_st = 0
                self.reg_new.in1_offset_x = 0
                self.reg_new.full_ch = 0
            elif (last_2048_c==True and last_2048_f==False):
                self.reg_new.ch_st = 1
                if(ich>2048):
                    self.reg_new.in1_offset_x = self.get_in_offset_x(curr_node)
                self.reg_new.full_ch = 1
            elif (last_2048_c==False and last_2048_f==True):
                self.reg_new.ch_st = 0
                self.reg_new.in1_offset_x = 0
                self.reg_new.full_ch = 0
            elif(last_2048_c==True and last_2048_f==True):
                self.reg_new.ch_st = 1
                if(ich>2048):
                    self.reg_new.in1_offset_x = self.get_in_offset_x(curr_node)
                self.reg_new.full_ch = 1
    
    def get_in_offset_x(self, curr_node):
        ibw = self.reg_new.input_bw
        row_num, col_num, ch_num = curr_node.shape[2], curr_node.shape[3], 2048
        if ibw == 1:
            offset = col_num * math.ceil((row_num * math.ceil(ch_num / 32)) / 16)
        else:
            offset = col_num * math.ceil((row_num * math.ceil(ch_num / 64)) / 16)
        return offset
    
    def get_out_offset_x(self, curr_node):
        obw = self.reg_new.output_bw
        row_num, col_num, ch_num = curr_node.shape[2], curr_node.shape[3], 2048
        if obw == 1:
            offset = col_num * math.ceil((row_num * math.ceil(ch_num / 32)) / 16)
        else:
            offset = col_num * math.ceil((row_num * math.ceil(ch_num / 64)) / 16)
        return offset
    
    def get_out_offset_y(self, curr_node):
        obw = self.reg_new.output_bw
        row_num, col_num, ch_num = curr_node.shape[2], curr_node.shape[3], 2048
        if obw == 1:
            offset = math.ceil(ch_num / 32) * row_num % 16
        else:
            offset = math.ceil(ch_num / 64) * row_num % 16
        return offset
    
    def _check_avgpool2conv(self, sub_node_list):
        first_node = sub_node_list[0]
        if first_node.op_type == NodeOpType.ConvNode:
            if ('avgpool_flag' in first_node.conv_param
            and first_node.conv_param['avgpool_flag']):
                return True
            else:
                return False
        else:
            return False
    def _gen_cmd_bin(self, f_cmd, all_write=True, write_och=True):
        reg_old = self.reg_old
        reg_new = self.reg_new
        cmd_len = CommandBinGen().gen_cmd_bin(reg_old, reg_new, f_cmd, all_write, write_och)
        return cmd_len

    def display_reg_new(self):
        print('--reg new--')
        print(self.reg_new.__dict__)
    
    def display_reg_old(self):
        print('--reg old--')
        print(self.reg_old.__dict__)
    
    def display_map_list(self):
        print('--sram_data_map_list--')
        for i in range(len(self._sram_data_map_list)):
            print(self._sram_data_map_list[i].__dict__)
