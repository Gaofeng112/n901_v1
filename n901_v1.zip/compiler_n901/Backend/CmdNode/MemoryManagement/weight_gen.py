import numpy as np
import math
import struct
import os
import sys
from Frontend.Node.node_def import NodeOpType
from Backend.CmdNode.MemoryManagement.WeightGeneration.weight_bin_gen import WeightBinGen
from Backend.CmdNode.MemoryManagement.WeightGeneration.common_functions import CommonFunctions
from multiprocessing import Process
from rich.progress import track
import pdb


class WeightGenAgent(object):
    def __init__(self):
        self.Hwbitwidth_info = None

    def fill_weight_single(self, cmd_node_list, myHw_info1, result_path, weight_gen_start_addr, compress_weight):
        self.Hwbitwidth_info = myHw_info1.hardware_info
        ## get length of pdma weight
        weight_file = os.path.join(result_path, "weight.bin")
        dram_weight_file = os.path.join(result_path, "dram_weight.bin")
        weight_len_before = os.path.getsize(weight_file)
        ##generate weight.bin and fill the members 'weight_start_addr', 'weight_len' of each cmdNode in cmd_node_list 
        weight_start_addr_next = weight_gen_start_addr
        list_len = len(cmd_node_list)

        weight_origin_file = os.path.join(result_path, "weight_origin.bin")
        with open(weight_origin_file, 'wb') as f_weight:
            for i in range(list_len):
                if cmd_node_list[i].type == 'NPUType':
                    ## get weight_start_addr and weight_len while generating weight.bin
                    # weight_start_addr = weight_start_addr_next
                    self._get_weight_len(cmd_node_list[i], f_weight)
                    ## fill weight_node with npu weight information
                    # cmd_node_list[i].weight_start_addr = weight_start_addr
                    # cmd_node_list[i].weight_len = hex(weight_len)
                    ## get next weight_start_addr 
                    # weight_start_addr_int = int(weight_start_addr, 16)
                    # weight_start_addr_next_int = weight_start_addr_int + weight_len
                    # weight_start_addr_next = hex(weight_start_addr_next_int)
        
        ### change by mengxiao @ 20200718
        if compress_weight:
            CommonFunctions().weight_compress_bin(weight_origin_file, weight_file)
        else:
            CommonFunctions().weight_bin_encoder(weight_origin_file, weight_file)
        cmd_node_list[0].weight_start_addr = weight_start_addr_next
        cmd_node_list[0].weight_len = hex(os.path.getsize(weight_file) - weight_len_before)
        return int(cmd_node_list[0].weight_start_addr, 16) + int(cmd_node_list[0].weight_len, 16)
        # self._dram_weight_gen(weight_file, dram_weight_file)
        # cmd_node_list[0].weight_len = hex(os.path.getsize(weight_origin_file) - weight_len_before_origin)
        # self._dram_weight_gen(weight_origin_file, dram_weight_file)
        # self._dram_weight_gen(weight_compressed_file, dram_weight_compressed_file)

    def fill_weight_multi(self, cmd_node_list, myHw_info1, result_path, process_cnt, weight_gen_start_addr, compress_weight):
        self.Hwbitwidth_info = myHw_info1.hardware_info
        ## get length of pdma weight
        weight_file = os.path.join(result_path, "weight.bin")
        weight_len_before = os.path.getsize(weight_file)
        ## generate weight.bin and fill the members 'weight_start_addr', 'weight_len' of each cmdNode in cmd_node_list 
        weight_start_addr_next = weight_gen_start_addr
        if (process_cnt!=1):
            is_Multi = True
        else:
            is_Multi = False
        npu_cmd_node_list = []
        for cmd_node in cmd_node_list:
            if (cmd_node.type == 'NPUType'):
                npu_cmd_node_list.append(cmd_node)
        gen_weight_node_list = []
        gen_weight_node_len = []
        j = 0
        gen_weight_node_list.append(npu_cmd_node_list[j])
        for i in range(len(npu_cmd_node_list)):
            if npu_cmd_node_list[i].group_id != npu_cmd_node_list[j].group_id:
                gen_weight_node_list.append(npu_cmd_node_list[i])
                gen_weight_node_len.append(i - j)
                j = i
        gen_weight_node_len.append(i - j + 1)
        assert(len(gen_weight_node_list) == len(gen_weight_node_len))
        sub_file_list = []
        loop_cnt = math.ceil(len(gen_weight_node_list) / process_cnt)
        for i in range(loop_cnt):
            st_idx = i * process_cnt
            ed_idx = min(st_idx + process_cnt, len(gen_weight_node_list))
            process_list = []
            for j in range(st_idx, ed_idx):
                gen_node = gen_weight_node_list[j]
                rep_cnt = gen_weight_node_len[j]
                weight_file_name = "weight_origin" + str(j) + ".bin"
                weight_file_rep_name = "weight_origin_rep" + str(j) + ".bin"
                weight_file_path = os.path.join(result_path, weight_file_name)
                weight_file_rep_path = os.path.join(result_path, weight_file_rep_name)
                sub_file_list.append(weight_file_rep_path)
                process_list.append(Process(target=self._get_weight_len_multi, args=(gen_node, rep_cnt, weight_file_path, weight_file_rep_path, )))
            for p in process_list:
                p.start()
            for p in process_list:
                p.join()
        weight_origin_file = os.path.join(result_path, "weight_origin.bin")
        with open(weight_origin_file, "wb") as f_out:
            for sub_file in track(sub_file_list, description= 'Write Weight Origin File'):
                with open(sub_file, "rb") as f_in:
                    data_size = os.path.getsize(sub_file)
                    f_out.write(f_in.read(data_size))
                os.remove(sub_file)
        if compress_weight:
            CommonFunctions().weight_compress_bin(weight_origin_file, weight_file, process_cnt=process_cnt, result_path=result_path, is_Multi=is_Multi)
        else:
            CommonFunctions().weight_bin_encoder(weight_origin_file, weight_file)
        cmd_node_list[0].weight_start_addr = weight_start_addr_next
        cmd_node_list[0].weight_len = hex(os.path.getsize(weight_file) - weight_len_before)
        return int(cmd_node_list[0].weight_start_addr, 16) + int(cmd_node_list[0].weight_len, 16)
    
    def _get_weight_len_multi(self, cmd_node, rep_cnt, weight_file_path, weight_file_rep_path):
        with open(weight_file_path, "wb") as f_weight:
            node_list_len = len(cmd_node.contents.node_list)
            weight_len = 0
            for sub_id in track(range(node_list_len), description= 'Generating Weights'):
                curr_node = cmd_node.contents.node_list[sub_id]
                if curr_node.op_type == NodeOpType.HardwareFusionNode:
                    sub_node_list = curr_node.sub_node_list
                else:
                    sub_node_list = [curr_node]
                # generate weight
                self._get_single_weight_len(sub_node_list, f_weight)
        data_size = os.path.getsize(weight_file_path)
        with open(weight_file_path, "rb") as f_read:
            with open(weight_file_rep_path, "wb") as f_out:
                for i in range(rep_cnt):
                    f_read.seek(0, 0)
                    f_out.write(f_read.read(data_size))
        os.remove(weight_file_path)

    def _get_weight_len(self, cmd_node, f_weight):
        node_list_len = len(cmd_node.contents.node_list)
        weight_len = 0
        for sub_id in range(node_list_len):
            curr_node = cmd_node.contents.node_list[sub_id]
            # print('--curr_node_index--:', curr_node.index)
            if curr_node.op_type == NodeOpType.HardwareFusionNode:
                sub_node_list = curr_node.sub_node_list
            else:
                sub_node_list = [curr_node]
            # generate weight
            self._get_single_weight_len(sub_node_list, f_weight)
      

    def _get_single_weight_len(self, sub_node_list, f_weight):
        first_node = sub_node_list[0]
        if first_node.op_type == NodeOpType.ConvNode:
            if ('group' in first_node.conv_param.keys()
                and first_node.conv_param['group'] != 1
                and first_node.conv_param['kernel_shape'] != [3,3]):
                ## depthwise conv
                WeightBinGen(self.Hwbitwidth_info).get_big_kernel_weight_bin(sub_node_list, f_weight)
            elif(first_node.conv_param['kernel_shape'] != [3,3]
                and first_node.conv_param['kernel_shape']!= [1,1]
                and 'avgpool_flag' in first_node.conv_param
                and first_node.conv_param['avgpool_flag']):
                ## global avgpool to conv
                WeightBinGen(self.Hwbitwidth_info).big_kernel_avgpool_weight_bin(sub_node_list, f_weight)
            elif (first_node.conv_param['kernel_shape'] != [3,3]
                and first_node.conv_param['kernel_shape'] != [1,1]):
                ## normal conv
                WeightBinGen(self.Hwbitwidth_info).get_big_kernel_weight_bin(sub_node_list, f_weight)
            elif (first_node.conv_param['kernel_shape'] != [3,3]
                and first_node.conv_param['kernel_shape'] != [1,1]):
                ## normal conv
                WeightBinGen(self.Hwbitwidth_info).get_big_kernel_weight_bin(sub_node_list, f_weight)
            elif('dilations' in first_node.conv_param.keys()
                 and first_node.conv_param["dilations"] != [1, 1]):
                WeightBinGen(self.Hwbitwidth_info).get_dilated_weight_bin(sub_node_list, f_weight)
            else:
                WeightBinGen(self.Hwbitwidth_info).get_weight_bin(sub_node_list, f_weight)
        else:
            # print(first_node.op_type)
            WeightBinGen(self.Hwbitwidth_info).get_weight_bin(sub_node_list, f_weight)

    def _dram_weight_gen(self, file_in, file_out, pdma_byte_num, cpu_node_byte_num):
        f_in = open(file_in, 'rb')
        f_out = open(file_out, 'wb')
        pdma_16byte = math.ceil(pdma_byte_num / 16)
        for i in range(pdma_16byte):
            buffer_16byte = []
            for j in range(16):
                buffer_16byte.insert(0, f_in.read(1))
            for j in range(16):
                f_out.write(buffer_16byte[j])
        f_in.seek(pdma_byte_num, 0)
        cpu_4byte = math.ceil(cpu_node_byte_num / 4)
        for i in range(cpu_4byte):
            buffer_4byte = []
            for j in range(4):
                buffer_4byte.insert(0, f_in.read(1))
            for j in range(4):
                f_out.write(buffer_4byte[j])
        f_in.seek(pdma_byte_num+cpu_node_byte_num, 0)
        all_data = os.path.getsize(file_in)
        r_npu_size = all_data - pdma_byte_num - cpu_node_byte_num
        num_16byte = math.ceil(r_npu_size/ 16)
        for i in range(num_16byte):
            buffer_16byte_ = []
            for j in range(16):
                buffer_16byte_.insert(0, f_in.read(1))
            for j in range(16):
                f_out.write(buffer_16byte_[j])
        f_in.close()
        f_out.close()
 

