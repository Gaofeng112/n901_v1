from distutils import cmd
from pickletools import int4
from ..cmd_node_def import DIDMA_param
from ..cmd_node_def import DODMA_param
from Frontend.HWToolBox.N900HWToolBox import N900HWToolBox
from Frontend.Node.node_def import NodeOpType
from Middleend.GroupAssigner.node_group_toolbox import NodeGroupToolbox
import math
import pdb
import logging
import re
class DMAInfoGenAgent(object):
    def __init__(self):
        pass
    
    def fill_dma_info(self, cmd_node_list):
        ## fill the members 'DIDMA_param', 'DODMA_param' of each cmdNode in cmd_node_list 
        for cmd_node in cmd_node_list:
            if (cmd_node.type == "CPUType"):
                continue
            
            cmd_node.DIDMA_param.append(DIDMA_param())
            datanode_in_format = cmd_node.datanode_in[0].format
            datanode_in_id = cmd_node.datanode_in[0].index
            self.set_DIDMA_param(cmd_node, datanode_in_format, datanode_in_id, cmd_node.datanode_in[0])
            exist_parent_ConcatNode = self.is_exist_parent_ConcatNode(cmd_node)
            if (exist_parent_ConcatNode):
                cmd_node.DIDMA_param[0].preprocessType = 1
                radix_dict = self.parent_ConcatNode_info(cmd_node)
                cmd_node.DIDMA_param[0].set_concat_shift(radix_dict)

            else:
                cmd_node.DIDMA_param[0].preprocessType = 0
                
            exist_AddNode = self.is_exist_AddNode(cmd_node)
            if exist_AddNode:
                addnode_index, datanode_in_index, x0_radix_list, x1_radix_list, y_radix_list, add_DIDMA_dmem_list = self.AddNode_info(cmd_node)
                DIDMA_AddCnt = 0
                for i in range(len(addnode_index)):
                    cmd_node.DIDMA_param.append(DIDMA_param())
                    datanode_in_format = cmd_node.datanode_in[datanode_in_index[i]].format
                    add_index = addnode_index[i]
                    self.set_ADD_DIDMA_param(cmd_node, datanode_in_format, add_index, cmd_node.datanode_in[datanode_in_index[i]].index, cmd_node.datanode_in[i + 1])
                    cmd_node.DIDMA_param[-1].dmem = add_DIDMA_dmem_list[i]
                    x0_radix, x1_radix, y_radix = x0_radix_list[i], x1_radix_list[i], y_radix_list[i]
                    radix_diff = [x0_radix[i] - x1_radix[i] for i in range(len(x0_radix))]
                    if (abs(radix_diff[0])) <= 2:
                        ### element-wise add
                        add_index = addnode_index[i]
                        self.set_Add_DIDMA_sram_offset(cmd_node, datanode_in_format, add_index)
                        cmd_node.DIDMA_param[i + 1].preprocessType = 0
                    else:
                        ### didma_add
                        DIDMA_AddCnt += 1
                        cmd_node.DIDMA_param[i + 1].set_dma_add_shift(x0_radix, x1_radix, y_radix)
                        cmd_node.DIDMA_param[i + 1].preprocessType = 2
                        
            datanode_out_format = cmd_node.datanode_out[0].format
            datanode_out_id = cmd_node.datanode_out[0].index
            self.set_DODMA_param(cmd_node, datanode_out_format, datanode_out_id, cmd_node.datanode_out[0])
            node_list = cmd_node.contents.node_list
            
            ### DIDMA_add 
            cmd_node.DODMA_param.smem = ((len(node_list) - DIDMA_AddCnt) & 1 if exist_AddNode 
                                        else len(node_list) & 1) 
    def is_exist_parent_ConcatNode(self, cmd_node):
        node_list = cmd_node.contents.node_list
        exist_ConcatNode = False
        for current_node in node_list:
            for parent_node in (current_node.parents):
                if (parent_node.op_type == NodeOpType.ConcatNode):
                    exist_ConcatNode = True
                    break
        return exist_ConcatNode

    def parent_ConcatNode_info(self, cmd_node):
        node_list = cmd_node.contents.node_list
        radix_dict = {}
        re_match_pattern_x = "x[0-9]_radix"
        re_match_pattern_y = "y_radix"
        for current_node in node_list:
            for parent_node in (current_node.parents):
                input_idx = 0
                if (parent_node.op_type == NodeOpType.ConcatNode):
                    for i in range(10):
                        x_radix ='x' + str(i) +'_radix'
                        if x_radix in parent_node.hardware_info.keys():
                            radix_name = x_radix
                            radix_val = parent_node.hardware_info[x_radix]
                            if re.match(re_match_pattern_x, radix_name) != None:
                                input_channel = parent_node.input_shape[input_idx][1]
                                input_idx += 1
                                radix_dict[radix_name] = radix_val[0:input_channel]
                        else:
                            continue
                    radix_val_y = parent_node.hardware_info['y_radix']
                    if re.match(re_match_pattern_y, 'y_radix') != None:
                        radix_dict['y_radix'] = radix_val_y
        return radix_dict 

    def set_concat_shift(self, radix_dict):
        x_radix, y_radix = [], []
        for radix_name, radix_val in radix_dict.items():
            if radix_name == "y_radix":
                y_radix.extend(radix_val)
            else:
                x_radix.extend(radix_val)
        while len(y_radix) < len(x_radix):
            y_radix.append(y_radix[-1])
        self.concat_shift = [x_radix[i] - y_radix[i] for i in range(len(y_radix))]

    def is_exist_AddNode(self, cmd_node):
        node_list = cmd_node.contents.node_list
        exist_AddNode = False    
        for node in node_list:
            if (node.op_type == NodeOpType.AddNode):
                exist_AddNode = True
                break
            if (node.op_type == NodeOpType.HardwareFusionNode):
                if (node.sub_node_list[0].op_type == NodeOpType.AddNode):
                    exist_AddNode = True
                    break
        return exist_AddNode
    
    def AddNode_info(self, cmd_node):
        addnode_index = []
        datanode_in_index = []
        datanode_st_index = 1
        x0_radix_list, x1_radix_list, y_radix_list = [], [], []
        add_DIDMA_dmem_list = []
        didma_add_cnt = 0
        node_list = cmd_node.contents.node_list
        for i, node in enumerate(node_list):
            if node.op_type == NodeOpType.HardwareFusionNode:
                sub_node = node.sub_node_list[0]
            else:
                sub_node = node
            if sub_node.op_type == NodeOpType.AddNode:
                ## pnode_in_same_grp: parent node of add node is in the same group (true) or not (false)
                ## pnode_startof_res: parent node of add node is the begin of a simple res structure (true) or not (false) 
                ## didma_add: the add node is a DIDMA_add node (true) or not (false)
                pnode_in_same_grp, pnode_startof_res, didma_add = self.addNodeNeedDMA(node, node_list)
                if not pnode_in_same_grp:
                    ## if not pnode_in_same_grp, there is a datanode need to deal (datanodeStIdx += 1)
                    if ((not pnode_startof_res) or didma_add):
                        if didma_add:
                            didma_add_cnt += 1
                            assert(i != 0), "First node of a group is an DIDMA add!"
                        add_DIDMA_dmem_list.append((i - didma_add_cnt) % 2)
                        if (add_DIDMA_dmem_list[-1] == 1):
                            logging.debug("node: {} need a add didma deme of 1".format(sub_node.name))
                        addnode_index.append(i)
                        datanode_in_index.append(datanode_st_index)
                        x0_radix_list.append(sub_node.hardware_info["x0_radix"])
                        x1_radix_list.append(sub_node.hardware_info["x1_radix"])
                        y_radix_list.append(sub_node.hardware_info["y_radix"])
                    datanode_st_index += 1
        return addnode_index, datanode_in_index, x0_radix_list, x1_radix_list, y_radix_list, add_DIDMA_dmem_list

    def set_Add_DIDMA_sram_offset(self, cmd_node, datanode_format, add_index):
        add_input_chunk_dict = cmd_node.contents.input_chunk[add_index][cmd_node.chunk_id]   ### dict() {row_st: row_ed: col_st: col_ed: ch_st: ch_ed}
        add_input_row_st, add_input_row_ed = add_input_chunk_dict["row_st"], add_input_chunk_dict["row_ed"]
        add_input_col_st, add_input_col_ed = add_input_chunk_dict["col_st"], add_input_chunk_dict["col_ed"]
        add_input_ch_st, add_input_ch_ed = add_input_chunk_dict["ch_st"], add_input_chunk_dict["ch_ed"]
        offset_x, offset_y = 0, 0
        input_row = add_input_row_ed - add_input_row_st + 1
        input_col = add_input_col_ed - add_input_col_st + 1
        input_ch = add_input_ch_ed - add_input_ch_st + 1
        if (datanode_format == 0):
            ### Entry format = 8 col * 4 ch, used for 16 bits CONV3x3RGBA
            sram_offset_x = offset_x + math.ceil(input_col / 8) * math.ceil(offset_y + input_row * math.ceil(input_ch / 4) / 16)
            sram_offset_y = 0
            sram_offset = [sram_offset_x, sram_offset_y]
            cmd_node.DIDMA_param[-1].set_sram_offset(sram_offset)
        elif (datanode_format == 3):
            ### Entry format = 16 col * 4 ch, used for 8 bits CONV3x3RGBA
            sram_offset_x = offset_x + math.ceil(input_col / 16) * math.ceil(offset_y + input_row * math.ceil(input_ch / 4) / 16)
            sram_offset_y = 0
            sram_offset = [sram_offset_x, sram_offset_y]
            cmd_node.DIDMA_param[-1].set_sram_offset(sram_offset)
        elif (datanode_format == 1):
            ### Entry format = 1 col * 32 ch, used for 16 bits other modes
            sram_offset_x = offset_x + input_col * math.ceil(offset_y + input_row * math.ceil(input_ch / 32) / 16)
            sram_offset_y = 0
            sram_offset = [sram_offset_x, sram_offset_y]
            cmd_node.DIDMA_param[-1].set_sram_offset(sram_offset)
        elif (datanode_format == 4):
            ### Entry format = 1 col * 64 ch, used for 8 bits other modes
            sram_offset_x = offset_x + input_col * math.ceil(offset_y + input_row * math.ceil(input_ch / 64) / 16)
            sram_offset_y = 0
            sram_offset = [sram_offset_x, sram_offset_y]
            cmd_node.DIDMA_param[-1].set_sram_offset(sram_offset)
        else:
            assert(False), "Not Support Datanode Format!"
    
    def set_DIDMA_param(self, cmd_node, datanode_format, datanode_in_id, datanode):
        input_chunk_dict = cmd_node.contents.input_chunk[0][cmd_node.chunk_id]
        feature_shape = cmd_node.contents.input_shape[0]
        self.set_DIDOMA_param(cmd_node, datanode_format, cmd_node.DIDMA_param[-1], input_chunk_dict, datanode_in_id, None, datanode, feature_shape, DMA_type=0)
        
    def set_DODMA_param(self, cmd_node, datanode_format, datanode_out_id, datanode):
        output_chunk_dict = cmd_node.contents.output_chunk[-1][cmd_node.chunk_id]
        feature_shape = cmd_node.contents.shape
        self.set_DIDOMA_param(cmd_node, datanode_format, cmd_node.DODMA_param, output_chunk_dict, None, datanode_out_id, datanode, feature_shape, DMA_type=1)

    def set_ADD_DIDMA_param(self, cmd_node, datanode_format, add_index, datanode_in_id, datanode):
        add_input_chunk_dict = cmd_node.contents.input_chunk[add_index][cmd_node.chunk_id]
        feature_shape = cmd_node.contents.node_list[add_index].input_shape[0]
        self.set_DIDOMA_param(cmd_node, datanode_format, cmd_node.DIDMA_param[-1], add_input_chunk_dict, datanode_in_id, None, datanode, feature_shape, DMA_type=0)
    
    def addNodeNeedDMA(self, node, node_list):
        parentInSameGrp = True
        for pNode in node.parents:
            if (pNode not in node_list):
                parentInSameGrp = False
                break
        parentStofRes = False
        for pNode in node.parents:
            if NodeGroupToolbox().check_branch(pNode) != 0:
                parentStofRes = True
                break
        if(node.op_type == NodeOpType.AddNode):
            didmaAdd = N900HWToolBox().is_DIDMA_Add(node)
        else:
            didmaAdd = N900HWToolBox().is_DIDMA_Add(node.sub_node_list[0])
        return parentInSameGrp, parentStofRes, didmaAdd
    
    def set_DIDOMA_param(self, cmd_node, datanode_format, DMA_param, chunk_dict, datanode_in_id, datanode_out_id, datanode, feature_shape, DMA_type):
        ### DMA_type: 0. DIDMA 1.DODMA
        row_st, row_ed = chunk_dict["row_st"], chunk_dict["row_ed"]
        col_st, col_ed = chunk_dict["col_st"], chunk_dict["col_ed"]
        ch_st, ch_ed = chunk_dict["ch_st"], chunk_dict["ch_ed"]
        [_, f_channel, f_height, f_width] = feature_shape
        if (datanode_format == 0):
            ### Entry format = 8 col * 4 ch, used for 16 bits CONV3x3RGBA
            offset = row_st * ((f_width + 7) // 8 * 8) * 4 * 2 + col_st * 4 * 2
            rowLen = (col_ed - col_st + 1 + 7) // 8 * 8 * 4 * 2     ### number of pixels
            rowPitchLen = (f_width + 7) // 8 * 8 * 4 * 2           ### number of bytes
            rowPitchNum =  row_ed - row_st + 1
            chPitchLen = f_height * ((f_width + 7) // 8 * 8) * 4 * 2
            chPitchNum = 1                              ###(input_ch_ed - input_ch_st + 1) // 4 + 1
            DMA_param.set_offset(offset)
            DMA_param.set_addr_param(rowLen, rowPitchLen, rowPitchNum, chPitchLen, chPitchNum)
            if DMA_type == 0:
                DMA_param.set_datanode_in_id(datanode_in_id, datanode)
            else:
                DMA_param.set_datanode_out_id(datanode_out_id, datanode)
        elif (datanode_format == 3):
            ### Entry format = 16 col * 4 ch, used for 8 bits CONV3x3RGBA
            offset = row_st * ((f_width + 15) // 16 * 16) * 4 + col_st * 4
            rowLen = (col_ed - col_st + 1 + 15) // 16 * 16 * 4     ### number of pixels
            rowPitchLen = (f_width + 15) // 16 * 16 * 4        ### number of bytes
            rowPitchNum =  row_ed - row_st + 1
            chPitchLen = f_height * ((f_width + 15) // 16 * 16) * 4
            chPitchNum = 1
            DMA_param.set_offset(offset)
            DMA_param.set_addr_param(rowLen, rowPitchLen, rowPitchNum, chPitchLen, chPitchNum)
            if DMA_type == 0:
                DMA_param.set_datanode_in_id(datanode_in_id, datanode)
            else:
                DMA_param.set_datanode_out_id(datanode_out_id, datanode)
        elif (datanode_format == 1):
            ### Entry format = 1 col * 32 ch, used for 16 bits other modes
            ch_ed = (ch_ed + 32) // 32 * 32 - 1
            offset = ch_st // 32 * (f_height * f_width * 32 * 2) + (row_st * f_width + col_st) * 32 * 2
            rowLen = (col_ed - col_st + 1) * 32 * 2     ### number of pixels  --> bytes * 2
            rowPitchLen = f_width * 32 * 2           ### number of bytes
            rowPitchNum = row_ed - row_st + 1 
            chPitchLen = f_height * f_width * 32 * 2
            chPitchNum = (ch_ed - ch_st + 1) // 32 
            DMA_param.set_offset(offset)
            DMA_param.set_addr_param(rowLen, rowPitchLen, rowPitchNum, chPitchLen, chPitchNum)
            if DMA_type == 0:
                DMA_param.set_datanode_in_id(datanode_in_id, datanode)
            else:
                DMA_param.set_datanode_out_id(datanode_out_id, datanode)
        elif(datanode_format == 4):
            ### Entry format = 1 col * 64 ch, used for 8 bits other modes
            ch_ed = (ch_ed + 64) // 64 * 64 - 1
            offset = ch_st // 64 * (f_height * f_width * 64) + (row_st * f_width + col_st) * 64
            rowLen = (col_ed - col_st + 1) * 64
            rowPitchLen = f_width * 64
            rowPitchNum = row_ed - row_st + 1
            chPitchLen = f_height * f_width * 64
            chPitchNum = (ch_ed - ch_st + 1) // 64
            DMA_param.set_offset(offset)
            DMA_param.set_addr_param(rowLen, rowPitchLen, rowPitchNum, chPitchLen, chPitchNum)
            if DMA_type == 0:
                DMA_param.set_datanode_in_id(datanode_in_id, datanode)
            else:
                DMA_param.set_datanode_out_id(datanode_out_id, datanode)
        else:
            assert(False), "Not Support Datanode Format!"

    def display_DIDMA(self, DIDMA_param):
        for i, param in enumerate(DIDMA_param):
            print("DIDMA[{}]: offset: {}".format(i, param.offset))
            # print("rowPitchLen: {} rowPitchNum {}".format(param.rowPitchLen, param.rowPitchNum))
            # print("rowLen: {}".format(param.rowLen)) 
            # print("chPitchLen: {} chPitchNum: {}".format(param.chPitchLen, param.chPitchNum))
            print("dmem: {} preprocessType: {}".format(param.dmem, param.preprocessType))
            print("concat_shift: {}".format(param.concat_shift))
            print("dma_add_shift: {}".format(param.dma_add_shift))

    def display_DODMA(self, param):
        print("DODMA: offset: {}".format(param.offset))
        print("rowPitchLen: {} rowPitchNum {}".format(param.rowPitchLen, param.rowPitchNum))
        print("rowLen: {}".format(param.rowLen)) 
        print("chPitchLen: {} chPitchNum: {}".format(param.chPitchLen, param.chPitchNum))
        print("smem: {}".format(param.smem))
