import pdb
import math
from Backend.CmdNode.cmd_node_def import DataNode, DIDMA_param, DODMA_param
  
class CompressGenAgent(object):
    def __init__(self, cmd_node_list, output_datanode_dict):
        self.cmd_node_list = cmd_node_list
        self.datanode_list = []
        self.output_datanode_dict = output_datanode_dict
    ## update cmd_node_list
    def fill_compress_info(self):
        # self.fill_burst_list()
        self.fill_datanode_information()
        self.fill_didma_info()
        self.fill_dodma_info()
        Config_Sram(self.cmd_node_list, self.datanode_list).update_config_sram()
        for datanode in self.datanode_list:
            datanode.F_information = datanode.C_information + datanode.D_information + 2     
            datanode.K_information = datanode.C_information + (3 * datanode.D_information) + 2

    def fill_datanode_list(self):
        datanode_in_list = []
        datanode_out_list = []
        inputnode_list = []
        outputnode_list = []
        ## look for all datanodes that don't repeat
        for cmd_node in self.cmd_node_list:
            for i in range(len(cmd_node.datanode_in)):
                datanode_in = cmd_node.datanode_in[i]
                datanode_in_list.append(datanode_in)     
            for i in range(len(cmd_node.datanode_out)):
                datanode_out = cmd_node.datanode_out[i]  
                datanode_out_list.append(datanode_out)  
        datanode_list_temp = datanode_in_list + datanode_out_list

        for cmd_node in self.cmd_node_list:
            if cmd_node.parent == None:
                for i in range(len(cmd_node.datanode_in)):
                    datanode_in_v = cmd_node.datanode_in[i]
                    inputnode_list.append(datanode_in_v)
        outputnode_list = list(self.output_datanode_dict.values())
            
        for datanode_temp in datanode_list_temp:
            if datanode_temp not in self.datanode_list and datanode_temp not in inputnode_list and datanode_temp not in outputnode_list:
               self.datanode_list.append(datanode_temp)    
            else:
                continue
        for cmd_node in self.cmd_node_list:
            if cmd_node.type == "CPUType":
                for i in range(len(cmd_node.datanode_in)):
                    datanode_in = cmd_node.datanode_in[i]
                    self.datanode_list.remove(datanode_in)
                for j in range(len(cmd_node.datanode_out)):
                    datanode_out = cmd_node.datanode_out[j]
                    self.datanode_list.remove(datanode_out)
        for datanode in self.datanode_list:
            if datanode.format == 3 or datanode.format == 4:
                self.datanode_list.remove(datanode)
            else:
                continue   
    ## divide bursts and fill the burst_list of the datanode,then fill the information of datanode
    def fill_burst_list(self):
        self.fill_datanode_list()
        for datanode in self.datanode_list:      
            burst_list_temp_v = []
            burst_list_temp = []
            st_tran_list = []
            end_tran_list = []
            st_list = []
            end_list = []
            burst_list = []
            for cmd_node in self.cmd_node_list:
                for i in range(len(cmd_node.DIDMA_param)):
                    didma_start_row = 0
                    didma_end_row = 0
                    didma = cmd_node.DIDMA_param[i]
                    if didma.datanode_in_id == datanode.index:
                        didma_start_row = int(math.floor(didma.offset / didma.rowPitchLen))
                        didma_end_row = didma_start_row + didma.rowPitchNum - 1
                        st_tran_list.append(didma_start_row)
                        end_tran_list.append(didma_end_row)
            
            for cmd_node in self.cmd_node_list:
                dodma = cmd_node.DODMA_param
                if datanode.index == dodma.datanode_out_id:
                    dodma_start_row = int(math.floor(dodma.offset / dodma.rowPitchLen))
                    dodma_end_row = dodma_start_row + dodma.rowPitchNum - 1
                    st_tran_list.append(dodma_start_row)
                    end_tran_list.append(dodma_end_row)
                else:
                    continue
            for i in st_tran_list:
                if i not in st_list:
                    st_list.append(i)
                else:
                    continue
            for i in end_tran_list:
                if i not in end_list:
                    end_list.append(i)
                else:
                    continue
            st_list = sorted(st_list)
            end_list = sorted(end_list)
            datanode.burst_list = st_list + end_list
            list_temp = st_list + end_list
            list_temp = sorted(list_temp)
            for i in list_temp:
                if i in st_list and i not in end_list:
                    burst_list_temp_v.append(i)
                elif i in st_list and i in end_list:
                    if i != end_list[-1]:
                        burst_list_temp_v.append(i)
                        i = i+1
                        burst_list_temp_v.append(i)
                    else:
                        burst_list_temp_v.append(i)
                elif i in end_list and i not in st_list:
                    if i != list_temp[-1]:
                        i = i+1
                        burst_list_temp_v.append(i)
                    else:
                        burst_list_temp_v.append(i)

            for i in burst_list_temp_v:
                if i not in burst_list_temp:
                    burst_list_temp.append(i)
                else:
                    continue
            burst_list_temp = sorted(burst_list_temp)
            # if datanode.index == 100022:
            #     pdb.set_trace()
            one_burst_one_row = self.one_burst_one_row(burst_list_temp)
            if one_burst_one_row:
                start_row = burst_list_temp[0]
                end_row = burst_list_temp[0]
                burst = Burst()
                burst.start_row = start_row
                burst.end_row = end_row
                burst_list.append(burst)
            else:
                for i in range(len(burst_list_temp)):
                    if i <= len(burst_list_temp) - 2:
                        if i <= len(burst_list_temp) - 3:
                            start_row = burst_list_temp[i]
                            end_row = burst_list_temp[i+1] - 1
                        else:
                            start_row = burst_list_temp[i]
                            end_row = burst_list_temp[i+1]
                    else:
                        continue
                    burst = Burst()
                    burst.start_row = start_row
                    burst.end_row = end_row
                    burst_list.append(burst)
            datanode.burst_list = burst_list
    def one_burst_one_row(self, burst_list_temp):
        one_burst_one_row = None
        if len(burst_list_temp) == 1 and burst_list_temp[0] == 0:
            one_burst_one_row =True 
        return one_burst_one_row       
    
    def fill_datanode_information(self):
        self.fill_burst_list()
        for datanode in self.datanode_list:
            uncompress_burst_len = 0
            A_infomation_len = 0
            for burst in datanode.burst_list:
                uncompress_burst_len = int((burst.end_row - burst.start_row + 1) * datanode.width * math.ceil(datanode.channel / 32) * 32 * 2 * 8 / 128)
                datanode.A_information.append(uncompress_burst_len)
            burst_num = len(datanode.burst_list)
            datanode.D_information = burst_num
            datanode.E_information = datanode.addr

            if datanode.format == 1:
                datanode.format = 5
            for cmd_node in self.cmd_node_list:
                uncompress_dodma_len = 0
                dodma_burst_list = []
                dodma = cmd_node.DODMA_param
                if dodma.datanode_out_id == datanode.index:
                    do_start_row = math.floor(dodma.offset / dodma.rowPitchLen)
                    do_end_row = do_start_row + dodma.rowPitchNum - 1
                    for burst in datanode.burst_list:
                        if burst.start_row >= do_start_row and burst.end_row <= do_end_row:
                            dodma_burst_list.append(burst)
                        else:
                            continue
                    for burst in dodma_burst_list:
                        burst_len = int((burst.end_row - burst.start_row + 1) * datanode.width * math.ceil(datanode.channel / 32) * 32 * 2 * 8 /128)
                        uncompress_dodma_len += burst_len
                    datanode.H_information.append(uncompress_dodma_len)
                else:
                    continue
            datanode.sram_len = 3 * burst_num + len(datanode.H_information) + 2

    def fill_didma_info(self):
        self.fill_burst_list()
        for cmd_node in self.cmd_node_list:
            for i in range(len(cmd_node.DIDMA_param)):
                didma = cmd_node.DIDMA_param[i]
                didma_burst_list = []
                di_start_row = 0
                di_end_row = 0
                row_num = 0
                for datanode in self.datanode_list:
                    if didma.datanode_in_id == datanode.index:
                        di_start_row = int(math.floor(didma.offset / didma.rowPitchLen))
                        di_end_row = di_start_row + didma.rowPitchNum - 1
                        for burst in datanode.burst_list:
                            if (burst.start_row >= di_start_row and burst.end_row <= di_end_row):
                                didma_burst_list.append(burst)
                            else:
                                continue
                        didma.N_information = len(didma_burst_list)
                        for didma_burst in didma_burst_list:
                            di_burst_row_list = []
                            difference = didma_burst_list[0].start_row
                            start_row = didma_burst.start_row - difference
                            end_row = didma_burst.end_row - difference
                            di_burst_row_list.append(start_row)
                            di_burst_row_list.append(end_row)
                            didma.O_information.append(di_burst_row_list)
                    else:
                        continue
    def fill_dodma_info(self):
        for cmd_node in self.cmd_node_list:
            for datanode in self.datanode_list:
                dodma = cmd_node.DODMA_param
                dodma_burst_list = []
                do_start_row = 0
                do_end_row = 0
                if dodma.datanode_out_id == datanode.index:
                    do_start_row = math.floor(dodma.offset / dodma.rowPitchLen)
                    do_end_row = do_start_row + dodma.rowPitchNum - 1
                    for burst in datanode.burst_list:
                        if burst.start_row >= do_start_row and burst.end_row <= do_end_row:
                            dodma_burst_list.append(burst)
                        else:
                            continue
                    dodma.Q_information = len(dodma_burst_list)
                    for dodma_burst in dodma_burst_list:
                        do_burst_row_list = []
                        difference = dodma_burst_list[0].start_row
                        start_row = dodma_burst.start_row - difference
                        end_row = dodma_burst.end_row - difference
                        do_burst_row_list.append(start_row)
                        do_burst_row_list.append(end_row)
                        dodma.I_information.append(do_burst_row_list)
                else:
                    continue

        
class Config_Sram(object):
    def __init__(self, cmd_node_list, datanode_list):
        self.cmd_node_list = cmd_node_list
        self.dma_list = []
        self.config_sram = []
        self.datanode_list = datanode_list
        for cmd_node in self.cmd_node_list:
            for datanode in self.datanode_list:
                for i in range(len(cmd_node.DIDMA_param)):
                    didma = cmd_node.DIDMA_param[i]
                    if didma.datanode_in_id == datanode.index:
                        self.dma_list.append(didma)
                    else:
                        continue

                dodma = cmd_node.DODMA_param
                if dodma.datanode_out_id == datanode.index:
                    self.dma_list.append(dodma)         
        # return self.dma_list
    def update_config_sram(self):
        for i in range(len(self.dma_list)):
            dma = self.dma_list[i]
            for datanode in self.datanode_list:
                if datanode.index == dma.datanode_out_id:
                    if dma == self.dma_list[0]:
                        datanode.C_information = 0
                        self.config_sram.append(datanode)
                        self.fill_R_information(dma, datanode)
                        self.config_sram.append(dma)
                    else:
                        del self.config_sram[-1]
                        self.update_sram_datanode(i, datanode)
                        self.fill_R_information(dma, datanode)
                        self.config_sram.append(dma)
                elif datanode.index == dma.datanode_in_id:
                    del self.config_sram[-1]
                    self.update_sram_datanode(i, datanode)
                    self.fill_M_information(dma, datanode)
                    self.config_sram.append(dma)
                else:
                    continue          
        
    def update_sram_datanode(self, i, datanode):
        j_list = []
        for j in range(i, len(self.dma_list)):
            dma = self.dma_list[j]
            if datanode.index == dma.datanode_in_id:
                j_list.append(j)
            elif datanode.index == dma.datanode_out_id:
                j_list.append(j)
            else:
                continue
        datanode.end_dma = max(j_list)
        for datanode_v in self.config_sram:
            if i == datanode_v.end_dma + 1:
               self.config_sram.remove(datanode_v)
            else:
                continue
        self.fill_C_information(datanode)
        if datanode not in self.config_sram:
            self.config_sram.append(datanode)
        else:
            pass
        
    def fill_C_information(self, datanode):
        if datanode in self.config_sram:
            pass
        else:
            if len(self.config_sram) == 0:
                datanode.C_information = 0
            else:
                if len(self.config_sram) == 1:
                    if self.config_sram[0].C_information == 0:
                        datanode.C_information = self.config_sram[0].sram_len
                    else:
                        remaining_len = self.config_sram[0].sram_st_addr
                        if datanode.sram_len < remaining_len:
                            datanode.C_information = 0
                else:
                    for i in range(len(self.config_sram)):
                        sram_datanode = self.config_sram[i] 
                        if i == 0:
                            remaining_len = sram_datanode.sram_st_addr
                            if datanode.sram_len < remaining_len:
                                datanode.C_information = 0
                                break
                            else:
                                continue
                        else:
                            remaining_len = sram_datanode.sram_st_addr - (self.config_sram[i-1].sram_st_addr + self.config_sram[i-1].sram_len)
                            if datanode.sram_len < remaining_len:
                                datanode.C_information = self.config_sram[i-1].sram_st_addr + self.config_sram[i-1].sram_len
                                break
                            else:
                                if i == len(self.config_sram) - 1:
                                    datanode.C_information = sram_datanode.sram_st_addr + sram_datanode.sram_len
                                    break
                                else:
                                    continue
        datanode.sram_st_addr = datanode.C_information

    def fill_R_information(self, dma, datanode):
        current_burst = 0
        start_row = math.floor(dma.offset / dma.rowPitchLen)
        for k in range(len(datanode.burst_list)):
            burst = datanode.burst_list[k]
            if start_row == burst.start_row:
                current_burst = k
            else:
                continue
        dma.R_information = datanode.C_information + len(datanode.A_information) + 2 * current_burst + 2

    def fill_M_information(self, dma, datanode):
        current_burst = 0
        start_row = math.floor(dma.offset / dma.rowPitchLen)
        for k in range(len(datanode.burst_list)):
            burst = datanode.burst_list[k]
            if start_row == burst.start_row:
                current_burst = k
        dma.M_information = datanode.C_information + len(datanode.A_information) + 2 * current_burst + 2

class Burst(object):
    def __init__(self):
        self.start_row = 0
        self.end_row = 0