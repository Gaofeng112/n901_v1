from operator import concat
import os
import struct
import math

from Backend.CmdNode.cmd_node_def import PDMA_param
from Frontend.Node.node_def import NodeOpType
from Frontend.Visitors.datanode_dict_visitor import DataNodeDictVisitor

import pdb
class PDMAInfoGenAgent(object):
    def __init__(self):
        pass

    def fill_pdma_info(self, cmd_node_list, start_addr_info_dict, datanode_dict, result_path):
        ## fill the member 'PDMA_param' of each cmdNode in cmd_node_list
        pdma_start_addr_next = start_addr_info_dict["weight_start_addr"]

        weight_file = os.path.join(result_path, "weight.bin")
        with open(weight_file, 'wb') as f_weight:
            for cmd_node in cmd_node_list:
                if (cmd_node.type == 'CPUType'):
                    continue
                for i in range(len(cmd_node.DIDMA_param)):
                    didma_param = cmd_node.DIDMA_param[i]
                    data_node_in = cmd_node.datanode_in[i]
                    if didma_param.preprocessType == 0:
                        ## bypass type
                        continue
                    elif didma_param.preprocessType == 1:
                        ## only shift
                        pdma_param, pdma_start_addr_next = self._get_shift_pdma_param(data_node_in, didma_param, pdma_start_addr_next)
                        cmd_node.PDMA_param.append(pdma_param)
                        self._write_shift_weight_bin(f_weight, didma_param, pdma_param)
                    elif didma_param.preprocessType == 2:
                        ## shift and add
                        pdma_param, pdma_start_addr_next = self._get_shift_add_pdma_param(data_node_in, didma_param, pdma_start_addr_next)
                        cmd_node.PDMA_param.append(pdma_param)
                        self._write_shift_add_weight_bin(datanode_dict, f_weight, didma_param, data_node_in, cmd_node, cmd_node_list, i, pdma_param)
        # self._display_pdma(cmd_node_list)
        # print('fill_pdma_end')
        return pdma_start_addr_next

    def _get_data_bw(self, datanode):
        if datanode.format in [3, 4, 6]:
            ## 8 bit
            data_bw = 0
        elif datanode.format in [0, 1, 5]:
            ## 16 bit
            data_bw = 1
        return data_bw

    def _get_shift_pdma_param(self, data_node_in, didma_param, pdma_start_addr_next):
        pdma_param = PDMA_param()
        data_bw = self._get_data_bw(data_node_in)
        pdma_param.data_bw = hex(data_bw)
        pdma_param.start_addr = pdma_start_addr_next
        pdma_param.len, real_len = self._get_shift_pdma_len(didma_param, data_bw)
        pdma_start_addr_next_int = int(pdma_param.start_addr, 16) + real_len
        pdma_start_addr_next = hex(pdma_start_addr_next_int)
        return pdma_param, pdma_start_addr_next

    def _get_shift_add_pdma_param(self, data_node_in, didma_param, pdma_start_addr_next):
        pdma_param = PDMA_param()
        data_bw = self._get_data_bw(data_node_in)
        pdma_param.data_bw = hex(data_bw)
        pdma_param.start_addr = pdma_start_addr_next
        pdma_param.len, real_len = self._get_shift_add_pdma_len(didma_param, data_bw)
        pdma_start_addr_next_int = int(pdma_param.start_addr, 16) + real_len
        pdma_start_addr_next = hex(pdma_start_addr_next_int)
        return pdma_param, pdma_start_addr_next

    def _get_shift_pdma_len(self, didma_param, data_bw):
        ch_num = math.ceil(len(didma_param.concat_shift)/32) * 32
        pdma_len = (ch_num * 4) / 8
        if data_bw == 0: #8 bit
            pdma_len = pdma_len / 2
        ## get real length
        real_len = int((ch_num * 4) / 8)
        pdma_len = hex(int(pdma_len))
        return pdma_len, real_len

    def _get_shift_add_pdma_len(self, didma_param, data_bw):
        ch_num = len(didma_param.dma_add_shift[0])
        pdma_len = 2 * (ch_num * 4) / 8
        if data_bw == 0: #8 bit
            pdma_len = pdma_len / 2
        ## get real length
        real_len = 2 * (ch_num * 4) / 8
        pdma_len = hex(int(pdma_len))
        return pdma_len, real_len

    def _write_shift_weight_bin(self, f_weight, didma_param, pdma_param):
        ## get interleaved concat shift
        concat_shift = self._interleave_dataformat(didma_param.concat_shift, int(pdma_param.data_bw, 16))
        ## get second interleaved concat shift if data bitwdith = 8 bit
        concat_shift = self._interleave_for_shift_module(concat_shift, int(pdma_param.data_bw, 16))
        ## get third interleaved concat shift for the need of 128bit big end format
        concat_shift = self._interleave_for_128bit_bigend(concat_shift)
        for curr_shift in concat_shift:
            assert(-4 <= curr_shift <= 4, "concat shift overflow!, curr shift:{}".format(curr_shift))
        for i in range(len(concat_shift) // 2):
            val_1 = concat_shift[2 * i]
            if val_1 < 0:
                val_1 = 16 + val_1
            val_2 = concat_shift[2 * i + 1]
            if val_2 < 0:
                val_2 = 16 + val_2
            val = val_1 + val_2 * 16
            val_w = struct.pack(">B", int(val))
            f_weight.write(val_w)

    
    def _write_shift_add_weight_bin(self, datanode_dict, f_weight, didma_param, data_node_in, cmd_node, cmd_node_list, didma_id, pdma_param):
        ## determine which piece of data from dram and which from sram add
        ## first find which node is data_node_in from
        matched_node = DataNodeDictVisitor().get_matched_node(datanode_dict, data_node_in)
        addnode_list = self._get_addnodes_sub_id(cmd_node)
        for parent_id, parent_node in enumerate(addnode_list[didma_id - 1].parents):
            if matched_node == parent_node:
                dram_add_shift = didma_param.dma_add_shift[parent_id]
                sram_add_shift = didma_param.dma_add_shift[1 - parent_id]
        ## get interleaved add shift
        dram_add_shift = self._interleave_dataformat(dram_add_shift, int(pdma_param.data_bw, 16))
        sram_add_shift = self._interleave_dataformat(sram_add_shift, int(pdma_param.data_bw, 16))
        ## get second interleaved add shift if data bitwdith = 8 bit
        add_shift = self._interleave_for_shift_add_module(dram_add_shift, sram_add_shift, int(pdma_param.data_bw, 16))
        ## get third interleaved concat shift for the need of 128bit big end format
        add_shift = self._interleave_for_128bit_bigend(add_shift)
        ## write add shift
        for i in range(len(add_shift) // 2):
            val_1 = add_shift[2 * i]
            if val_1 < 0:
                val_1 = 16 + val_1
            val_2 = add_shift[2 * i + 1]
            if val_2 < 0:
                val_2 = 16 + val_2
            val = val_1 + val_2 * 16
            val_w = struct.pack(">B", int(val))
            f_weight.write(val_w)

    def _interleave_dataformat(self, input_list, data_bw):
        output_list = []
        ch_num = len(input_list)
        if data_bw == 1:
            num_32ch = int(math.ceil(ch_num / 32))
            for ch32 in range(num_32ch):
                for ch8 in range(4):
                    for ch4 in range(2):
                        for ch in range(4):
                            curr_ch = 32 * ch32 + 4 * ch8 + 16 * ch4 + ch
                            if curr_ch >= ch_num:
                                val = 0
                            else:
                                val = input_list[curr_ch]
                            output_list.append(val)
        elif data_bw == 0:
            num_64ch = int(math.ceil(ch_num / 64))
            for ch64 in range(num_64ch):
                for ch16 in range(4):
                    for ch8 in range(2):
                        for ch in range(8):
                            curr_ch = 64 * ch64 + 8 * ch16 + 32 * ch8 + ch
                            if curr_ch >= ch_num:
                                val = 0
                            else:
                                val = input_list[curr_ch]
                            output_list.append(val)
        return output_list

    def _interleave_for_128bit_bigend(self, input_list):
        num_32ch = math.ceil(len(input_list) / 32)
        output_list = []
        for ch32 in range(num_32ch):
            for ch2 in range(15, -1, -1):
                output_list.append(input_list[32 * ch32 + 2 * ch2])
                output_list.append(input_list[32 * ch32 + 2 * ch2 + 1])
        return output_list

    def _interleave_for_shift_module(self, concat_shift, data_bw):
        if data_bw == 1:
            concat_shift_fn = []
            num_32ch = int(math.ceil(len(concat_shift) / 32))
            for ch32 in range(num_32ch):
                for ch1 in range(16):
                    concat_shift_fn.append(concat_shift[32 * ch32 + ch1])
                    concat_shift_fn.append(concat_shift[32 * ch32 + 16 + ch1])
        elif data_bw == 0:
            ch_num = len(concat_shift)
            shift_1, shift_2 = [], []
            num_64ch = int(math.ceil(ch_num / 64))
            for ch64 in range(num_64ch):
                # for ch1 in range(8):
                #     ## for the first sram
                #     shift_1.append(concat_shift[64 * ch64 + ch1])
                #     shift_1.append(concat_shift[64 * ch64 + 32 + ch1])
                #     ## for the second sram
                #     shift_2.append(concat_shift[64 * ch64 + 8 + ch1])
                #     shift_2.append(concat_shift[64 * ch64 + 40 + ch1])
                # for ch1 in range(8):
                #     ## for the first sram
                #     shift_1.append(concat_shift[64 * ch64 + 16 + ch1])
                #     shift_1.append(concat_shift[64 * ch64 + 48 + ch1])
                #     ## for the second sram
                #     shift_2.append(concat_shift[64 * ch64 + 24 + ch1])
                #     shift_2.append(concat_shift[64 * ch64 + 56 + ch1])
                for ch1 in range(8):
                    ## for the first sram
                    shift_1.append(concat_shift[64 * ch64 + ch1])
                    shift_1.append(concat_shift[64 * ch64 + 16 + ch1])
                    ## for the second sram
                    shift_2.append(concat_shift[64 * ch64 + 8 + ch1])
                    shift_2.append(concat_shift[64 * ch64 + 24 + ch1])
                for ch1 in range(8):
                    ## for the first sram
                    shift_1.append(concat_shift[64 * ch64 + 32 + ch1])
                    shift_1.append(concat_shift[64 * ch64 + 48 + ch1])
                    ## for the second sram
                    shift_2.append(concat_shift[64 * ch64 + 40 + ch1])
                    shift_2.append(concat_shift[64 * ch64 + 56 + ch1])
            shift_1.extend(shift_2)
            concat_shift_fn = shift_1
        return concat_shift_fn

    def _interleave_for_shift_add_module(self, dram_shift, sram_shift, data_bw):
        if data_bw == 1:
            add_shift_fn = []
            for i in range(len(dram_shift)):
                add_shift_fn.append(dram_shift[i])
                add_shift_fn.append(sram_shift[i])
        elif data_bw == 0:
            ch_num = len(dram_shift)
            shift_1, shift_2 = [], []
            num_32ch = int(math.ceil(ch_num / 32))
            for ch32 in range(num_32ch):
                for ch16 in range(2):
                    for ch1 in range(8):
                        ## the first sram
                        shift_1.append(dram_shift[32 * ch32 + 16 * ch16 + ch1])
                        shift_1.append(sram_shift[32 * ch32 + 16 * ch16 + ch1])
                        ## the second sram
                        shift_2.append(dram_shift[32 * ch32 + 16 * ch16 + 8 + ch1])
                        shift_2.append(sram_shift[32 * ch32 + 16 * ch16 + 8 + ch1])
            shift_1.extend(shift_2)
            add_shift_fn = shift_1
        return add_shift_fn


    def _get_addnodes_sub_id(self, cmd_node):
        addnode_list = []
        node_list = cmd_node.contents.node_list
        for node in node_list:
            if node.op_type == NodeOpType.AddNode:
                addnode_list.append(node)
            elif (node.op_type == NodeOpType.HardwareFusionNode):
                if (node.sub_node_list[0] == NodeOpType.AddNode):
                    addnode_list.append(node)
        return addnode_list        

    def _display_pdma(self, cmd_node_list):
        for i in range(len(cmd_node_list)):
            for j in range(len(cmd_node_list[i].PDMA_param)):
                pdma_param = cmd_node_list[i].PDMA_param[j]
                print(pdma_param.__dict__)