from configparser import DuplicateOptionError
from ..cmd_node_def import DataNode
from Frontend.Node.node_def import NodeOpType, InputNode
import math
from Middleend.GroupAssigner.node_group_def import NodeGroup 
import pdb
import copy

###random_list = [i for i in range(1, 100000)]
###
def get_index(index_list):
    index = index_list[0]
    index_list.remove(index)
    #index = random.choice(random_list)
    #random_list.remove(index)
    return index
    
class DataNodeGenAgent(object):
    def __init__(self):
        pass
    
    def fill_data_node(self, cmd_node_list, output_datanode_dict, datanode_dict, 
                       assigned_groups, graph, start_addr_info_dict):
        #### traverse assigned_groups??
        #need to check if there is more than one input
        allocator = Allocator()
        datanode_list = []
        #for node in graph.nodes:
            #datanode_dict[node] = []
        index_list = [i for i in range(100000, 200000)]
        init_addr = start_addr_info_dict["data_start_addr"]
        init_addr = int(init_addr, 16)
        allocator.end_addr = init_addr
        parent_len_dict = {}
        for node_group in assigned_groups:
            parent_len_dict[node_group] = len(node_group.children)
        
        #create datanode of InputNode's output first
        inputs = graph.inputs
        input_datanode_list = []
        input_datanode_dict = {}
        for model_input in inputs:
            datanode = self.__datanode_gen(model_input, datanode_list, index_list)
            datanode.addr = allocator.allocate(datanode.addr_len, init_addr)
            #change from hex str to hex num
            datanode.addr = hex(datanode.addr)
            input_datanode_list.append(datanode)
        
        for i in range(len(inputs)):
            input_datanode_dict[inputs[i]] = input_datanode_list[i]
        
        
        parent_dict = {}
        for node_group in assigned_groups:
            parent_dict[node_group] = []
            
        for i in range(len(assigned_groups)):
            node_group = assigned_groups[i]
            for j in range(len(node_group.node_list)):
                node = node_group.node_list[j]
                for parent in node.parents:
                    is_extra_parent = True
                    if parent in node_group.node_list:
                        is_extra_parent = False
                    for group_parent in node_group.parents:
                        if parent in group_parent.node_list:
                            is_extra_parent = False
                            parent_dict[node_group].append(group_parent)
                    #if there is extra parent, it must be an input node
                    if is_extra_parent == True:
                        parent_dict[node_group].append(parent)
                        
        #create network's output datanode
        outputs = graph.outputs
        output_datanode_list = []
        for model_output in outputs:
            datanode = self.__datanode_gen(model_output, datanode_list, index_list)
            datanode.addr = allocator.allocate(datanode.addr_len, init_addr)
            #change from hex str to hex num
            datanode.addr = hex(datanode.addr)
            output_datanode_list.append(datanode)
        
        for i in range(len(outputs)):
            output_datanode_dict[outputs[i]] = output_datanode_list[i]
        
        #change init_addr to the end of output_datanode_list
        #to avoid free output_datanode of network
        init_addr = int(output_datanode_list[-1].addr, 16) + \
            output_datanode_list[-1].addr_len
        for i in range(len(assigned_groups)):
            node_group = assigned_groups[i]
            
            if node_group.type == 'NPUType':
                #check if datanode_input exists
                for parent in parent_dict[node_group]:
                    #if parent is InputNode, get datanode from input_datanode_list
                    if parent.__class__.__name__ == 'InputNode':
                        for j in range(len(inputs)):
                            if parent == inputs[j]:
                                curr_datanode = input_datanode_list[j]
                    else:
                        for datanode in datanode_list:
                            for cmd_node in cmd_node_list:
                                #print(cmd_node.group_id)
                                if cmd_node.contents == parent and \
                                    datanode == cmd_node.datanode_out[-1]:
                                    curr_datanode = cmd_node.datanode_out[-1]

                    for cmd_node in cmd_node_list:
                        if cmd_node.contents == node_group:
                            cmd_node.datanode_in.append(curr_datanode)
                            
                #node_group only have one output and its datanode_output has not been created
                #need to check if output is network's output
                is_model_output = False
                for j in range(len(outputs)):
                    if outputs[j] in node_group.node_list[-1].children:
                        datanode = output_datanode_list[j]
                        is_model_output = True
                if is_model_output == False:
                    datanode = self.__datanode_gen(node_group, datanode_list, index_list)
                    datanode.addr = allocator.allocate(datanode.addr_len, init_addr)
                    datanode.addr = hex(datanode.addr)
                #datanode.output.append(node_group)
                for cmd_node in cmd_node_list:
                    if cmd_node.contents == node_group:
                        cmd_node.datanode_out.append(datanode)
                        datanode_dict[cmd_node.contents.node_list[-1]] = datanode
                # delete parents' datanode_out if parent's children has been intercepted
                self.__delete_used_addr(node_group, parent_len_dict, cmd_node_list, allocator)


            #CPU node_group may have more than one datanode_in and datanode_out
            elif node_group.type == 'CPUType':
                for i in range(len(node_group.node_list)):
                    node = node_group.node_list[i]
                    #check if the node is a concate_node
                    if node.op_type == NodeOpType.ConcatNode:
                        datanode_out_addr, is_model_output = self.__concat_process(node, 
                            node_group, datanode_list, cmd_node_list, init_addr, 
                            allocator, outputs, output_datanode_list)
                        # ConcatNode's datanode_out = datanode_in joined together
                        
                        if is_model_output == False:
                            datanode = self.__datanode_gen(node, datanode_list, index_list)
                            # datanode_out_addr = datanode_in_addr
                            datanode.addr = datanode_out_addr
                            #datanode.output.append(node_group)
                            for cmd_node in cmd_node_list:
                                if cmd_node.contents == node_group:
                                    cmd_node.datanode_out.append(datanode)
                                    datanode_dict[cmd_node.contents.node_list[i]] = datanode

                    else:
                        for parent in node.parents:
                            if parent.op_type == NodeOpType.InputNode:
                                for j in range(len(inputs)):
                                    if parent == inputs[j]:
                                        curr_datanode = input_datanode_list[j]
                            else:
                                for datanode in datanode_list:
                                    for cmd_node in cmd_node_list:
                                        if parent in cmd_node.contents.node_list and \
                                            datanode in cmd_node.datanode_out:
                                            curr_datanode = datanode
                                        
                            for cmd_node in cmd_node_list:
                                if cmd_node.contents == node_group:
                                    cmd_node.datanode_in.append(curr_datanode)

                        #node_group datanode_out
                        is_model_output = False
                        for j in range(len(outputs)):
                            if outputs[j] in node.children:
                                datanode = output_datanode_list[j]
                                is_model_output = True
                        if is_model_output == False:
                            datanode = self.__datanode_gen(node, datanode_list, index_list)
                            datanode.addr = allocator.allocate(datanode.addr_len, init_addr)
                            datanode.addr = hex(datanode.addr)
                        #datanode.output.append(node_group)
                        for cmd_node in cmd_node_list:
                            if cmd_node.contents == node_group:
                                cmd_node.datanode_out.append(datanode)
                                datanode_dict[cmd_node.contents.node_list[i]] = datanode
                        # delete parents' datanode_out if parent's children has been intercepted
                        if i == 0:
                            self.__delete_used_addr(node_group, parent_len_dict, 
                                cmd_node_list, allocator)

                        else:
                            if node.parents[0].op_type == NodeOpType.ConcatNode:
                                continue
                            for cmd_node in cmd_node_list:
                                if (cmd_node.contents == node_group and 
                                    cmd_node.chunk_id == 0):
                                    datanode_out = cmd_node.datanode_out[-2]
                                    addr = int(datanode_out.addr, 16)
                                    addr_len = datanode_out.addr_len
                                    allocator.free(addr, addr_len)
        datanode_dict.update(input_datanode_dict)
        # self.display_datanode_in(cmd_node_list)
        #print(input_datanode_dict)
        #print('------------------')
        #print(datanode_dict)

       
    def __datanode_gen(self, node_group, datanode_list, index_list):
        datanode_list.append(DataNode())
        datanode = datanode_list[-1]
        datanode.index = get_index(index_list)
        datanode_shape = node_group.shape
        bitwidth = 0
        if isinstance(node_group, NodeGroup):
            node = node_group.node_list[-1]
        else:
            node = node_group
        if(node.op_type == NodeOpType.InputNode):
            # pdb.set_trace()
            bitwidth = node.children[0].hardware_info["input_bitwidth"]
        elif(node.op_type == NodeOpType.OutputNode):
            # pdb.set_trace()
            bitwidth = node.parents[0].hardware_info["output_bitwidth"]
        else:
            if node.op_type.name == 'L2NormalizationNode':
                bitwidth = node.hardware_info[1]["output_bitwidth"]
            else:
                bitwidth = node.hardware_info["output_bitwidth"]
        # print("-----------------datanode_shape------------", end=": ")
        # print(datanode_shape)
        datanode.bitwidth = bitwidth
        if len(datanode_shape) == 4:
            datanode.height = datanode_shape[2]
            datanode.width = datanode_shape[3]
            datanode.channel = datanode_shape[1]
        elif len(datanode_shape) == 2:
            datanode.channel = datanode.width = 1
            datanode.height = datanode_shape[1]
        datanode.format, datanode.addr_len = self.__get_len_format(datanode.height, 
            datanode.width, datanode.channel, datanode.bitwidth, node_group)
        return datanode
        
    def __delete_used_addr(self, node_group, parent_len_dict, cmd_node_list, allocator):
        for parent in node_group.parents:
            parent_len_dict[parent] -= 1
            if parent_len_dict[parent] == 0:
                #a concat_node's parent should be checked if it is zero
                if parent.node_list[0].op_type == NodeOpType.ConcatNode:
                    for grandparent in parent.parents:
                        parent_len_dict[grandparent] -= 1
                        if (grandparent.node_list[0].op_type == 
                            NodeOpType.ConcatNode):
                            for greatgrandparent in grandparent.parents:
                                parent_len_dict[greatgrandparent] -= 1
                            if parent_len_dict[greatgrandparent] == 0:
                                for cmd_node in cmd_node_list:
                                    if (cmd_node.contents == greatgrandparent and 
                                        cmd_node.chunk_id == 0):
                                        addr = int(cmd_node.datanode_out[-1].addr, 16)
                                        addr_len = cmd_node.datanode_out[-1].addr_len
                                        allocator.free(addr, addr_len)
                        else:
                            if parent_len_dict[grandparent] == 0:
                                for cmd_node in cmd_node_list:
                                    if (cmd_node.contents == grandparent and 
                                        cmd_node.chunk_id == 0):
                                        addr = int(cmd_node.datanode_out[-1].addr, 16)
                                        addr_len = cmd_node.datanode_out[-1].addr_len
                                        allocator.free(addr, addr_len)

                else:
                    for cmd_node in cmd_node_list:
                        if (cmd_node.contents == parent 
                            and cmd_node.chunk_id == 0):
                            addr = int(cmd_node.datanode_out[-1].addr, 16)
                            addr_len = cmd_node.datanode_out[-1].addr_len
                            allocator.free(addr, addr_len)
    
    def __concat_process(self, node, node_group, datanode_list, cmd_node_list, 
                         init_addr, allocator, outputs, output_datanode_list):
        is_model_output = False
        for j in range(len(outputs)):
            if outputs[j] in node_group.node_list[-1].children:
                datanode = output_datanode_list[j]
                is_model_output = True
        
        if is_model_output == True:
            datanode_out_addr = None
            for cmd_node in cmd_node_list:
                if cmd_node.contents == node_group:
                    cmd_node.datanode_out.append(datanode)
            for parent in node.parents:
                for datanode in datanode_list:
                    for cmd_node in cmd_node_list:
                        if parent in cmd_node.contents.node_list and \
                            datanode in cmd_node.datanode_out:
                            curr_datanode = datanode

                for cmd_node in cmd_node_list:
                    if cmd_node.contents == node_group:
                        cmd_node.datanode_in.append(curr_datanode)
            
        else:
            for parent in node.parents:
                for node_group_parent in node_group.parents:
                    if node_group_parent.node_list[0].op_type != NodeOpType.ConcatNode:
                        for datanode in datanode_list:
                            for cmd_node in cmd_node_list:
                                # check if datanode in node.datanode_in
                                if (parent in cmd_node.contents.node_list and 
                                    datanode == cmd_node.datanode_out[0] and 
                                    cmd_node.chunk_id == 0):
                                    # copy datanode to a new datanode
                                    curr_datanode = datanode
                                    addr = int(curr_datanode.addr, 16)
                                    addr_len = curr_datanode.addr_len
                                    #for concat_node, we won't minus its parents' value in 
                                    #parent_len_dict by 1
                                    allocator.free(addr, addr_len)
                                    new_datanode = copy.deepcopy(curr_datanode)
                                    new_datanode.addr = allocator.allocate(new_datanode.addr_len, 
                                        init_addr, place_to_end = True)
                                    new_datanode.addr = hex(new_datanode.addr)
                                    '''if (parent in cmd_node.contents.node_list and 
                                    datanode in cmd_node.datanode_out):
                                    cmd_node.datanode_out = [new_datanode if \
                                        x == curr_datanode else x for x in \
                                        cmd_node.datanode_out]'''
                                    # add concate_node datanode_in info
                                    for cmd_node1 in cmd_node_list:
                                        if cmd_node1.contents == node_group:
                                            cmd_node1.datanode_in.append(new_datanode)
                                    if parent == node.parents[0]:
                                        datanode_out_addr = new_datanode.addr
                                    #elif parent == node.parents[-1]:
                                        #datanode_out_addr_end = datanode_addr + \
                                            #datanode_addr_len
                                    # change curr_datanode to new_datanode
                                    for cmd_node2 in cmd_node_list:
                                        cmd_node2.datanode_in = [new_datanode if \
                                            x == curr_datanode else x for x in \
                                            cmd_node2.datanode_in]
                                        cmd_node2.datanode_out = [new_datanode if \
                                            x == curr_datanode else x for x in \
                                            cmd_node2.datanode_out]
                #if concat_node's parent is concat_node
                    else:
                        grandparent = node_group_parent.node_list[0]
                        for datanode in datanode_list:
                            for cmd_node in cmd_node_list:
                                # check if datanode in node.datanode_in
                                if (grandparent in cmd_node.contents.node_list and 
                                    datanode == cmd_node.datanode_out[0] and 
                                    cmd_node.chunk_id == 0):
                                    # copy datanode to a new datanode
                                    curr_datanode = datanode
                                    new_datanode = DataNode()
                                    addr = int(curr_datanode.addr, 16)
                                    addr_len = curr_datanode.addr_len
                                    #for concat_node, we won't minus its parents' value in 
                                    #parent_len_dict by 1
                                    allocator.free(addr, addr_len)
                                    new_datanode = copy.deepcopy(curr_datanode)
                                    new_datanode.addr = allocator.allocate(new_datanode.addr_len, 
                                        init_addr, place_to_end = True)
                                    new_datanode.addr = hex(new_datanode.addr)
                                    '''if (parent in cmd_node.contents.node_list and 
                                    datanode in cmd_node.datanode_out):
                                    cmd_node.datanode_out = [new_datanode if \
                                        x == curr_datanode else x for x in \
                                        cmd_node.datanode_out]'''
                                    # add concate_node datanode_in info
                                    for cmd_node1 in cmd_node_list:
                                        if cmd_node1.contents == node_group:
                                            cmd_node1.datanode_in.append(new_datanode)
                                    if grandparent == node.parents[0]:
                                        datanode_out_addr = new_datanode.addr
                                    #elif parent == node.parents[-1]:
                                        #datanode_out_addr_end = datanode_addr + \
                                            #datanode_addr_len
                                    # change curr_datanode to new_datanode
                                    for cmd_node2 in cmd_node_list:
                                        cmd_node2.datanode_in = [new_datanode if \
                                            x == curr_datanode else x for x in \
                                            cmd_node2.datanode_in]
                                        cmd_node2.datanode_out = [new_datanode if \
                                            x == curr_datanode else x for x in \
                                            cmd_node2.datanode_out]
        return datanode_out_addr, is_model_output
    
    def __get_len_format(self, height, width, channel, bitwidth, node_group):
        concat = False
        if(isinstance(node_group, NodeGroup)):
            if(node_group.node_list[-1].op_type == NodeOpType.ConcatNode):
                concat = True
            for cgrp in node_group.children:
                if(cgrp.node_list[0].op_type == NodeOpType.ConcatNode):
                    concat = True
                    break
        else:
            
            if(node_group.op_type == NodeOpType.ConcatNode):
                concat = True
            for cnode in node_group.children:
                if(cnode.op_type == NodeOpType.ConcatNode):
                    concat = True
                    break 

        if(channel <= 4):
            if(bitwidth == 16):
                format = 0
                addr_len = height * math.ceil(width / 8) * 8 * 4 * 2
            elif(bitwidth == 8):
                format = 3
                addr_len = height * math.ceil(width / 16) * 16 * 4 * 1
            else:
                assert(False), "Not Support Bitwidth!"
        else:
            if(bitwidth == 16):
                format = 1
                if concat == True:
                    addr_len = height * width * math.ceil(channel / 32) * 32 * 2 
                else:
                    addr_len = math.ceil(height * width * math.ceil(channel / 32) * 32 * 2 / 16) * 16
            elif(bitwidth == 8):
                format = 4
                addr_len = height * width * math.ceil(channel / 64) * 64
        return format, addr_len
    
    def display_datanode_in(self, cmd_node_list):
        for cmd_node in cmd_node_list:
            fnode, lnode = cmd_node.contents.node_list[0], cmd_node.contents.node_list[-1]
            print("first node name: %s" % (fnode.name))
            print("last node name: %s" % (lnode.name))
            for dnode in cmd_node.datanode_in:
                print("height: %d width: %d channel: %d input_bitwidth: %d" % (dnode.height, dnode.width, dnode.channel, dnode.bitwidth))
    
class Allocator(object):
    def __init__(self):
        self.interval_list = []
        self.end_addr = 0
    
    def allocate(self, addr_len, init_addr, place_to_end = False):
        len_list = []
        if self.interval_list == []:
            start_addr = init_addr
            self.interval_list.append([start_addr, start_addr + addr_len - 1])
            self.end_addr = max(self.end_addr, start_addr + addr_len - 1)
            return start_addr
        if place_to_end == True:
            start_addr = self.end_addr + 1
            self.interval_list.append([start_addr, start_addr + addr_len - 1])
            self.end_addr = start_addr + addr_len - 1
            return start_addr
        for i in range(len(self.interval_list)):
            interval = self.interval_list[i]
            if i == 0:
                len_list.append(interval[0] - init_addr)
            else:
                len_list.append(self.interval_list[i][0] - self.interval_list[i - 1][1] - 1)

        len_min = max(len_list)
        if len_min < addr_len:
            start_addr = self.interval_list[-1][1] + 1
            index = len(self.interval_list)
        else:
            for i in range(len(len_list)):
                if len_list[i] >= addr_len and len_list[i] <= len_min:
                    index = i
                    len_min = len_list[i]
            if index == 0:
                start_addr = init_addr
            else:
                start_addr = self.interval_list[index - 1][1] + 1
        self.interval_list.insert(index, [start_addr, start_addr + addr_len - 1])
        self.end_addr = max(self.end_addr, start_addr + addr_len - 1)
        return start_addr

    def free(self, addr, addr_len):
        interval = [addr, addr + addr_len - 1]
        #assert interval in self.interval_list
        if interval in self.interval_list:
            self.interval_list.remove(interval)
        else:
            print('output node cannot be freed!')
