from Backend.BackendToolbox.backend_toolbox import BackendToolbox
from .MemoryManagement.cmd_gen import CmdGenAgent
from .MemoryManagement.weight_gen import WeightGenAgent
from .MemoryManagement.datanode_gen import DataNodeGenAgent
from .MemoryManagement.dma_info_gen import DMAInfoGenAgent
from .MemoryManagement.pdma_info_gen import PDMAInfoGenAgent
from .MemoryManagement.cpu_param_gen import CPUParamGenAgent
from .MemoryManagement.lutnode_gen import LutNodeGenAgent
from .cmd_node_def import CmdNode
from .MemoryManagement.compress_gen import CompressGenAgent
from .MemoryManagement.WeightGeneration.lut_bin_gen import LutDataGenAgent
import json
import pdb

class CmdNodeContainer(object):  ###, group_assigner : GroupAssigner):
    
    json_file_path = "./config/memory.json"   ###
    result_path = "./Resutls"
    def __init__(self, compress_weight, compress_fm):
        self.cmd_node_list = []
        self.output_datanode_dict = {}
        self.datanode_dict = {}
        self.lutnode_dict = {}
        self.compress_weight = compress_weight
        self.compress_fm = compress_fm
    def build_cmdnode(self, group_assigner, graph, myHw_info1, process_cnt, json_file_path = json_file_path, result_path = result_path):
        for grp_id in range(len(group_assigner)):
            for ch_id in range(group_assigner[grp_id].chunk_num):
                myCmdNode = CmdNode(grp_id, ch_id, group_assigner[grp_id])
                self.cmd_node_list.append(myCmdNode)
        
        json_file = open(json_file_path, 'r', encoding='utf-8')
        start_addr_info_dict = json.load(json_file)

        
        DataNodeGenAgent().fill_data_node(self.cmd_node_list, self.output_datanode_dict, 
            self.datanode_dict, group_assigner, graph, start_addr_info_dict)
        DMAInfoGenAgent().fill_dma_info(self.cmd_node_list)
        LutNodeGenAgent().fill_lut_node(self.cmd_node_list, self.lutnode_dict, group_assigner)
        # BackendToolbox().get_8bit_datanode_dma(self.cmd_node_list)
        CmdGenAgent().fill_cmd(self.cmd_node_list, self.datanode_dict, self.lutnode_dict, group_assigner, 
            start_addr_info_dict, result_path)
        weight_start_addr = PDMAInfoGenAgent().fill_pdma_info(self.cmd_node_list, 
            start_addr_info_dict, self.datanode_dict, result_path)
        pdma_byte_num = int(weight_start_addr, 16) - int(start_addr_info_dict['weight_start_addr'], 16)
        pdma_ed_addr = weight_start_addr
        weight_start_addr = CPUParamGenAgent().fill_cpu_param(self.cmd_node_list,
            weight_start_addr, result_path)
        cpu_node_byte_num = int(weight_start_addr, 16) - int(pdma_ed_addr, 16)
        if (process_cnt != 1):
            weight_start_addr = WeightGenAgent().fill_weight_multi(self.cmd_node_list, myHw_info1, result_path, process_cnt, weight_start_addr, self.compress_weight)
        else:
            weight_start_addr = WeightGenAgent().fill_weight_single(self.cmd_node_list, myHw_info1, result_path, weight_start_addr, self.compress_weight)
        # weight_start_addr = WeightGenAgent().fill_weight_multi(self.cmd_node_list, myHw_info1, result_path, weight_start_addr, self.compress_weight)
        LutNodeGenAgent().change_lut_node_start_addr(self.cmd_node_list, weight_start_addr)
        LutDataGenAgent().fill_lut_data(self.cmd_node_list, result_path, pdma_byte_num, cpu_node_byte_num)
        self.set_parents_children()
        # if self.compress_fm:
        #     CompressGenAgent(self.cmd_node_list, self.output_datanode_dict).fill_compress_info()
            
    def set_parents_children(self):
        self.cmd_node_list[0].parent = None
        self.cmd_node_list[-1].child = None

        for i in range(len(self.cmd_node_list) - 1):
            self.cmd_node_list[i].child = self.cmd_node_list[i+1]

        for i in range(1, len(self.cmd_node_list)):
            self.cmd_node_list[i].parent = self.cmd_node_list[i-1]