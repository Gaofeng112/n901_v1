from Middleend.GroupAssigner.node_group_def import NodeGroup
from Middleend.GroupAssigner.group_assigner import GroupAssigner
from Backend.ComputationNode.computation_node_def import NodeType
import pdb

class CmdNode(object):
    def __init__(self, grp_id, ch_id, node_group):



        self.group_id = grp_id
        self.chunk_id = ch_id
        self.name  = "CmdNode_" + str(self.group_id)+ "_" + str(self.chunk_id)
        self.parent = None
        self.child = None
        self.contents = node_group
        self.type = self.contents.type
        
        self.cmd_start_addr = 0x0
        self.cmd_len = 0
        self.weight_start_addr = 0x0
        self.weight_len = 0

        self.datanode_in = []               ## list of DataNode
        self.datanode_out = []      ###
        self.lutnode = []

        self.DIDMA_param = []  ### DIDMA_add  DIDMA_param
        self.DODMA_param = DODMA_param()
        self.PDMA_param = []

        self.CPU_param = []
    

class DataNode(object):

    def __init__(self):
        self.node_type = NodeType.DataType
        self.index = 0
        self.addr = 0
        self.addr_len = 0
        self.format = ""
        self.height = 0
        self.width = 0
        self.channel = 0
        self.bitwidth = 0
        self.end_dma = 0
        self.burst_list = []
        self.A_information = []
        self.sram_len = 0
        self.sram_st_addr = 0
        self.C_information = 0
        self.D_information = 0
        self.F_information = 0
        self.H_information = []
        self.K_information = 0

class LutNode(object):
    def __init__(self):
        self.node_type = NodeType.LutType
        self.index = 0
        self.addr = 0
        self.addr_len = 4096 * 2 * 16 ## 4096 entries per bank * 2 bytes per entry * 16 banks
        self.func_type = 0
        self.x_radix = 0
        self.y_radix = 0
        self.input_bitwidth = 0

class PDMA_param(object):

    def __init__(self):
        self.data_bw = 0
        self.start_addr = 0
        self.len = 0


class DIDMA_param(object):
    
    def __init__(self):
        self.offset = 0
        self.datanode_in_id = 0
        self.datanode = None
        self.datanode_out_id = None
        self.rowLen = 0
        self.rowPitchLen = 0
        self.rowPitchNum = 0
        self.chPitchLen = 0
        self.chPitchNum = 0

        self.sram_offset = [0,0]
        self.dmem = 0
        self.preprocessType = 0
        self.concat_shift = [] 
        self.dma_add_shift = []
        self.M_information = 0
        self.N_information = 0
        self.O_information = []
        self.P_information = 0x350

    def set_offset(self, v_offset):
        self.offset = v_offset
    
    def set_addr_param(self, v_rowLen, v_rowPitchLen, v_rowPitchNum, v_chPitchLen, v_chPitchNum):
        self.rowLen = v_rowLen
        self.rowPitchLen = v_rowPitchLen
        self.rowPitchNum = v_rowPitchNum
        self.chPitchLen = v_chPitchLen
        self.chPitchNum = v_chPitchNum

    def set_sram_offset(self, v_sram_offset):
        self.sram_offset = v_sram_offset

    def set_concat_shift(self, radix_dict):
        x_radix, y_radix = [], []
        for radix_name, radix_val in radix_dict.items():
            if radix_name == "y_radix":
                y_radix.extend(radix_val)
            else:
                x_radix.extend(radix_val)
        while len(y_radix) < len(x_radix):
            y_radix.append(y_radix[-1])
        self.concat_shift = [x_radix[i] - y_radix[i] for i in range(len(y_radix))]
        for i in range(len(self.concat_shift)):
            assert(-4 <= self.concat_shift[i] <= 4, "concat shift overflow!")
        
    def set_dma_add_shift(self, x0_radix, x1_radix, y_radix):
        len_x0, len_x1, len_y = len(x0_radix), len(x1_radix), len(y_radix)
        assert (len_x0 == len_y) and (len_x1 == len_y)
        dram2sram_shift, sram_shift = [], []
        
        dram2sram_shift = [x0_radix[i] - y_radix[i] for i in range(len_x0)]
        sram_shift = [x1_radix[i] - y_radix[i] for i in range(len_x1)]
        
        self.dma_add_shift = [dram2sram_shift, sram_shift]

    def set_datanode_in_id(self,v_datanode_in_id, datanode):
        self.datanode_in_id = v_datanode_in_id
        self.datanode = datanode


class DODMA_param(object):
    
    def __init__(self):
        self.offset = 0
        self.datanode_out_id = 0
        self.datanode = None
        self.datanode_in_id = None
        self.rowLen = 0
        self.rowPitchLen = 0
        self.rowPitchNum = 0
        self.chPitchLen = 0
        self.chPitchNum = 0

        self.sram_offset = [0,0]
        self.smem = 0
        self.I_information = []
        self.G_information = 0x350
        self.Q_information = 0
        self.R_information = 0

    def set_offset(self, v_offset):
        self.offset = v_offset
    
    def set_addr_param(self, v_rowLen, v_rowPitchLen, v_rowPitchNum, v_chPitchLen, v_chPitchNum):
        self.rowLen = v_rowLen
        self.rowPitchLen = v_rowPitchLen
        self.rowPitchNum = v_rowPitchNum
        self.chPitchLen = v_chPitchLen
        self.chPitchNum = v_chPitchNum

    def set_sram_offset(self, v_sram_offset):
        self.sram_offset = v_sram_offset
        
    def set_datanode_out_id(self,v_datanode_out_id, datanode):
        self.datanode_out_id = v_datanode_out_id
        self.datanode = datanode
        

class CPUShift_param(object):

    def __init__(self):
        self.start_addr = 0
        self.len = 0

class L2Norm_param(object):
    def __init__(self):
        self.start_addr = 0
        self.len = 0