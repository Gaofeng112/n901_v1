from enum import Enum, unique
from Frontend.Node.node_def import NodeOpType


@unique
class CpuOpcode(Enum):
    CDMA = 0
    WDMA = 1
    DIDMA = 2
    DODMA = 3
    Concat = 4
    PDMA = 5
    Shift = 6
    L2Norm = 7
    Flatten = 8
    Softmax = 9
    LUTDMA = 10

class NodeType(Enum):
    CpuType = 0
    NpuType = 1
    DataType = 2
    LutType = 3
    
    
class CompuNode(object):
    def __init__(self):
        self.index = 0
        self.next_node = None
    
    def set_index(self, index):
        self.index = index
    
    def set_next_node(self, next_node):
        self.next_node = next_node


class CpuCompuNode(CompuNode):
    def __init__(self):
        super().__init__()
        self.node_type = NodeType.CpuType
        #self.op_type = ''
        self.datanode_in = []
        self.datanode_out = None
        self.param = []
    
    #def set_optype(self, op_type):
        #self.op_type = op_type
    
    def set_data_node(self, data_in_list, data_out):
        self.datanode_in = data_in_list
        self.datanode_out = data_out
    
    def set_param(self, param):
        self.param = param
        
        
class CdmaCompuNode(CompuNode):
    def __init__(self):
        super().__init__()
        self.node_type = NodeType.CpuType
        self.cpu_optype = CpuOpcode.CDMA
        self.opcodeID = 0
        self.start_addr = 0x0
        self.len = 0x0
    
    def set_param(self, node):
        self.start_addr = node.cmd_start_addr
        self.len = node.cmd_len


class WdmaCompuNode(CompuNode):
    def __init__(self):
        super().__init__()
        self.node_type = NodeType.CpuType
        self.cpu_optype = CpuOpcode.WDMA
        self.start_addr = 0x0
        self.len = 0x0

    def set_param(self, node):
        self.start_addr = node.weight_start_addr
        self.len = node.weight_len


class DidmaCompuNode(CompuNode):
    def __init__(self):
        super().__init__()
        self.node_type = NodeType.CpuType
        self.cpu_optype = CpuOpcode.DIDMA
        self.param = None
        self.datanode_in = None
    
    def set_param(self, param):
        self.param = param

    def set_data_in(self, datanode_in):
        self.datanode_in = datanode_in

class LutdmaCompmuNode(CompuNode):
    def __init__(self, lutnode):
        super().__init__()
        self.node_type = NodeType.CpuType
        self.cpu_optype = CpuOpcode.LUTDMA
        self.lutnode = lutnode

class NpuCompuNode(CompuNode):
    def __init__(self):
        super().__init__()
        self.node_type = NodeType.NpuType


class DodmaCompuNode(CompuNode):
    def __init__(self):
        super().__init__()
        self.node_type = NodeType.CpuType
        self.cpu_optype = CpuOpcode.DODMA
        self.param = None
        self.datanode_out = None

    def set_param(self, param):
        self.param = param
        
    def set_data_out(self, datanode_out):
        self.datanode_out = datanode_out


class ConcatCompuNode(CompuNode):
    def __init__(self):
        super().__init__()
        self.node_type = NodeType.CpuType
        self.cpu_optype = CpuOpcode.Concat
        self.datanode_in = []
        self.datanode_out = None
        self.axis = None
        
    def set_axis(self, axis):
        self.axis = axis - 1
    
    def set_data_node(self, data_in_list, data_out):
        self.datanode_in = data_in_list
        self.datanode_out = data_out
        
class PdmaCompuNode(CompuNode):
    def __init__(self):
        super().__init__()
        self.node_type = NodeType.CpuType
        self.cpu_optype = CpuOpcode.PDMA
        self.param = []

    def set_param(self, param):
        self.param = param
        
class ShiftCompuNode(CompuNode):
    def __init__(self):
        super().__init__()
        self.node_type = NodeType.CpuType
        self.cpu_optype = CpuOpcode.Shift
        self.datanode_in = []
        self.datanode_out = None
        self.param = []
        
    def set_data_node(self, data_in_list, data_out):
        self.datanode_in = data_in_list
        self.datanode_out = data_out
        
    def set_param(self, param):
        self.param = param

class L2NormCompuNode(CompuNode):
    def __init__(self):
        super().__init__()
        self.node_type = NodeType.CpuType
        self.cpu_optype = CpuOpcode.L2Norm
        self.datanode_in = []
        self.datanode_out = None
        self.param = []

    def set_data_node(self, data_in_list, data_out):
        self.datanode_in = data_in_list
        self.datanode_out = data_out
     
    def set_param(self, param):
        self.param = param

class FlattenCompuNode(CompuNode):
    def __init__(self):
        super().__init__()
        self.node_type = NodeType.CpuType
        self.cpu_optype = CpuOpcode.Flatten
        self.datanode_in = []
        self.datanode_out = None
        self.param = []
    
    def set_data_node(self, data_in_list, data_out):
        self.datanode_in = data_in_list
        self.datanode_out = data_out
     
    def set_param(self, param):
        self.param = param

class SoftmaxCompuNode(CompuNode):
    def __init__(self):
        super().__init__()
        self.node_type = NodeType.CpuType
        self.cpu_optype = CpuOpcode.Softmax
        self.datanode_in = []
        self.datanode_out = None
        self.param = []
    
    def set_data_node(self, data_in_list, data_out):
        self.datanode_in = data_in_list
        self.datanode_out = data_out
     
    def set_param(self, param):
        self.param = param
