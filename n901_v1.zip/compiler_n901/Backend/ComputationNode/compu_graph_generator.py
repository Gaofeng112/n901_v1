from .computation_node_def import (CompuNode, CpuCompuNode, CdmaCompuNode, FlattenCompuNode, L2NormCompuNode, SoftmaxCompuNode,WdmaCompuNode, 
    DidmaCompuNode, NpuCompuNode, DodmaCompuNode, ConcatCompuNode, 
    PdmaCompuNode, NodeType, ShiftCompuNode, LutdmaCompmuNode)
from Frontend.Node.node_def import L2NormalizationNode, NodeOpType
from Backend.CmdNode.MemoryManagement.lutnode_gen import lut_node_type
from Backend.CmdNode.MemoryManagement.dma_info_gen import DMAInfoGenAgent
import pdb

class NpuNodeListDebugger(object):
    def __init__(self, ):
        self.npu_node_list_dict = {}
        self.npu_node_index_dict = {}
    
    def fill_npu_node_list(self, npu_node, op_node):
        if npu_node not in self.npu_node_list_dict:
            self.npu_node_list_dict[npu_node] = []
        if op_node.op_type == NodeOpType.HardwareFusionNode:
            self.npu_node_list_dict[npu_node].extend(op_node.sub_node_list)
        else:
            self.npu_node_list_dict[npu_node].append(op_node)
    
    def merge_node_list(self, main_node, merge_node):
        self.npu_node_list_dict[main_node].extend(self.npu_node_list_dict[merge_node])
        del self.npu_node_list_dict[merge_node]
    
    def __fill_npu_node_index(self, compu_node_list):
        for i in range(len(compu_node_list)):
            node = compu_node_list[i]
            if node.node_type == NodeType.NpuType:
                self.npu_node_index_dict[node] = i 

    def display_npu_node_list(self, compu_node_list):
        self.__fill_npu_node_index(compu_node_list)
        for npu_node, node_list in self.npu_node_list_dict.items():
            print("NPU Node index: {}".format(self.npu_node_index_dict[npu_node]))
            print("Execution nodes: ")
            for op_node in node_list:
                print(op_node.name, end = "\t")
            print("\n")

class CompuGraphGenerator(object):
    def __init__(self):
        self.npu_node_debugger = None
        self.lutmode = None
            
    def compu_graph_generator(self, cmd_node_list):
        compu_node_list = []
        is_wdma = True
        for i in range(len(cmd_node_list)):
            curr_node = cmd_node_list[i]
            if curr_node.type == 'CPUType':
                compu_node_list += self._get_cpu_nodes(curr_node)
            elif curr_node.type == 'NPUType':
                compu_node_list += self._get_npu_nodes(curr_node, is_wdma)
                is_wdma = False
            else:
                print('Error cmd_node type !!')
        for i in range(len(compu_node_list)):
            compu_node_list[i].set_index(i)
            if i < len(compu_node_list) - 1:
                compu_node_list[i].set_next_node(compu_node_list[i + 1])
        if self.npu_node_debugger != None:
            self.npu_node_debugger.display_npu_node_list(compu_node_list)
        return compu_node_list
    
    def _get_cpu_nodes(self, node):
        node_list = []
        datanode_len = 0
        j = 0
        for i in range(len(node.contents.node_list)):
            curr_node = node.contents.node_list[i]
            
            if curr_node.op_type == NodeOpType.ConcatNode:
                compu_node = ConcatCompuNode()
                compu_node.set_data_node(node.datanode_in[datanode_len:datanode_len + \
                    len(curr_node.parents)], node.datanode_out[i])
                compu_node.set_axis(curr_node.concat_param['axis'])
                datanode_len += len(curr_node.parents)
            else:
                if curr_node.op_type == NodeOpType.ShiftNode:
                    compu_node = ShiftCompuNode()
                    compu_node.set_data_node([node.datanode_in[datanode_len]], 
                        node.datanode_out[i])
                    #compu_node.set_param(node.CPU_param[j])
                    #j += 1
                elif curr_node.op_type == NodeOpType.L2NormalizationNode:
                    compu_node = L2NormCompuNode()
                    compu_node.set_data_node(node.datanode_in[datanode_len], 
                        node.datanode_out[i])
                    compu_node.set_param(node.CPU_param[j])
                    j += 1
                elif curr_node.op_type == NodeOpType.FlattenNode:
                    compu_node = FlattenCompuNode()
                    compu_node.set_data_node([node.datanode_in[datanode_len]],
                        node.datanode_out[i])
                elif curr_node.op_type == NodeOpType.SoftmaxNode:
                    compu_node = SoftmaxCompuNode()
                    compu_node.set_data_node([node.datanode_in[datanode_len]],
                        node.datanode_out[i])
                else:
                    compu_node = CpuCompuNode()
                    compu_node.set_data_node([node.datanode_in[datanode_len]], 
                        node.datanode_out[i])
                #else:
                    #compu_node.set_optype(curr_node.op_type)
                datanode_len += 1
            node_list.append(compu_node)
        assert datanode_len == len(node.datanode_in)
        
        return node_list

    def _get_npu_nodes(self, node, is_wdma):
        node_list = []
        # command DMA
        # pdb.set_trace()
        if node.contents.avgpool_flag:
            if len(node.cmd_len_list) != 0:
                cmd_len_list = node.cmd_len_list
                start_addr = 0
                for i in range(len(cmd_len_list)):
                    cdma_node = CdmaCompuNode()
                    if i == 0:
                        cdma_node.start_addr = node.cmd_start_addr
                        cdma_node.len = hex(cmd_len_list[0])
                        start_addr = hex(int(node.cmd_start_addr, 16) + int(hex(cmd_len_list[0]), 16))
                        didma_node = DidmaCompuNode()
                        didma_node.set_param(node.DIDMA_param[0])
                        didma_node.set_data_in(node.datanode_in[0])
                        node_list.append(cdma_node)
                        node_list.append(didma_node)
                        npu_node = NpuCompuNode()
                        node_list.append(npu_node)
                    else:
                        cdma_node.len = hex(cmd_len_list[i])
                        cdma_node.start_addr = start_addr
                        start_addr = hex(int(cdma_node.start_addr, 16) + int(hex(cmd_len_list[i]), 16))
                        node_list.append(cdma_node)
                        npu_node = NpuCompuNode()
                        node_list.append(npu_node)
                dodma_node = DodmaCompuNode()
                dodma_node.set_param(node.DODMA_param)
                dodma_node.set_data_out(node.datanode_out[0])
                node_list.append(dodma_node)             
        else:
            cdma_node = CdmaCompuNode()
            cdma_node.set_param(node)
            node_list.append(cdma_node)
            # weight DMA
            #first NPU cmd_node
            if is_wdma == True:
                wdma_node = WdmaCompuNode()
                wdma_node.set_param(node)
                node_list.append(wdma_node)
            # data in DMA
            didma_node = DidmaCompuNode()
            didma_node.set_param(node.DIDMA_param[0])
            didma_node.set_data_in(node.datanode_in[0])
            # npu node
            datanode_in_cnt = 1
            pdma_cnt = 0
            lutnode_cnt = 0
            didma_cnt = 1
            if didma_node.param.preprocessType != 0:
                pdma_node = PdmaCompuNode()
                pdma_node.set_param(node.PDMA_param[0])
                node_list.append(pdma_node)
                pdma_cnt += 1
            node_list.append(didma_node)
            
            node_group = node.contents.node_list
            i = 0
            # if node.contents.node_list[0].name == "Add_15":
            #     pdb.set_trace()
            while i < len(node_group):
                #if an add node is found, add a NPU node in front of it
                lutnode_cnt = self.__deal_lut_dma(node, node_group[i], node_list, lutnode_cnt)
                if((node_group[i].op_type == NodeOpType.HardwareFusionNode and node_group[i].sub_node_list[0].op_type == NodeOpType.AddNode) or \
                    node_group[i].op_type == NodeOpType.AddNode):
                    parentInSameGrp, parentStofRes, didmaAdd = DMAInfoGenAgent().addNodeNeedDMA(node_group[i], node_group)
                    if(not parentInSameGrp):
                        if((not parentStofRes) or didmaAdd):
                            didma_node = DidmaCompuNode()
                            didma_node.set_param(node.DIDMA_param[didma_cnt])
                            didma_node.set_data_in(node.datanode_in[datanode_in_cnt])
                            didma_cnt += 1
                            if didma_node.param.preprocessType != 0:
                                pdma_node = PdmaCompuNode()
                                pdma_node.set_param(node.PDMA_param[pdma_cnt])
                                node_list.append(pdma_node)
                                pdma_cnt += 1
                            node_list.append(didma_node)
                #     npu_node = NpuCompuNode()
                #     if self.npu_node_debugger != None:
                #         self.npu_node_debugger.fill_npu_node_list(npu_node, node_group[i])
                #     node_list.append(npu_node)
                # elif node_group[i].op_type == NodeOpType.AddNode:
                #     #check if the add node is the first node
                #     didma_node = DidmaCompuNode()
                #     didma_node.set_param(node.DIDMA_param[j])
                #     didma_node.set_data_in(node.datanode_in[j])
                #     j += 1
                #     if didma_node.param.preprocessType != 0:
                #         pdma_node = PdmaCompuNode()
                #         pdma_node.set_param(node.PDMA_param[k])
                #         node_list.append(pdma_node)
                #         k += 1
                #     node_list.append(didma_node)
                    
                #Elementwise_Add needs a DIDMA_node and a NpuCompuNode
                if didma_node.param.preprocessType == 2:
                    i += 1
                    continue
                npu_node = NpuCompuNode()
                if self.npu_node_debugger != None:
                    self.npu_node_debugger.fill_npu_node_list(npu_node, node_group[i])
                node_list.append(npu_node)
                i += 1

            # data out DMA
            dodma_node = DodmaCompuNode()
            dodma_node.set_param(node.DODMA_param)
            dodma_node.set_data_out(node.datanode_out[0])
            node_list.append(dodma_node)
            
            for i in range(len(node_list) - 1, 0, -1):
                if (node_list[i].node_type == NodeType.NpuType
                    and node_list[i - 1].node_type == NodeType.NpuType):
                    if self.npu_node_debugger != None:
                        self.npu_node_debugger.merge_node_list(main_node=node_list[i - 1], merge_node=node_list[i])
                    del node_list[i]
        return node_list

    def __deal_lut_dma(self, cmd_node, node, compu_node_list, idx):
        sub_node = None
        if(node.op_type in lut_node_type):
            sub_node = node
        elif node.op_type == NodeOpType.HardwareFusionNode:
            for x in node.sub_node_list:
                if(x.op_type in lut_node_type):
                    sub_node = x
                    break
        if(sub_node == None):
            return idx
        ibw = sub_node.hardware_info["input_bitwidth"]
        xrd = sub_node.hardware_info["x_radix"][0]
        yrd = sub_node.hardware_info["y_radix"][0]
        if(sub_node.op_type == NodeOpType.MishNode):
            func_type = 0
        elif(sub_node.op_type == NodeOpType.SiluNode):
            func_type = 1
        else:
            assert(False), "Not Supported Node Type!!"
        mode = str(ibw) + "_" + str(xrd) + "_" + str(yrd) + "_" + str(func_type)
        if(mode == self.lutmode):
            return idx + 1
        self.lutmode = mode
        lutnode = cmd_node.lutnode[idx]
        assert(lutnode.input_bitwidth == ibw and lutnode.x_radix == xrd and lutnode.y_radix == yrd and lutnode.func_type == func_type), "Not Match LUTnode!!"
        compu_node_list.append(LutdmaCompmuNode(lutnode))
        return idx + 1
