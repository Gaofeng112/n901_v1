import struct
import os
# from .computation_node_def import (CompuNode, CpuCompuNode, CdmaCompuNode,
#     WdmaCompuNode, DidmaCompuNode, NpuCompuNode, DodmaCompuNode, CompuOpType)
# from .compu_graph_generator import CompuGraphGenerator
from .computation_node_def import (CompuNode, FlattenCompuNode, NodeType, CpuOpcode)

import pdb

class OpflowGenAgent(object):
    def __init__(self):
        pass

    def fill_opflow(self, computer_graph, path):

        # DataNodeSet = set()
        DataNodeList = []
        filepath = os.path.join(path, "opflow.bin")
        i = 0
        with open(filepath, 'wb') as f_opflow:
            for compu_node in computer_graph:
                # for compu_node in computer_graph:
                #     if compu_node.node_type == NodeType.CpuType and \
                #     compu_node.cpu_optype == CpuOpcode.DIDMA:
                #         i = i+1
                #         if compu_node.index == 90:
                #             pdb.set_trace()
                # pdb.set_trace()
                if compu_node.node_type == NodeType.CpuType and compu_node.cpu_optype == CpuOpcode.CDMA :
                    self.gen_CDMA_opcode(compu_node, f_opflow)

                elif compu_node.node_type == NodeType.CpuType and compu_node.cpu_optype == CpuOpcode.WDMA :
                    self.gen_WDMA_opcode(compu_node, f_opflow)
                    
                elif compu_node.node_type == NodeType.CpuType and compu_node.cpu_optype == CpuOpcode.PDMA :
                    self.gen_PDMA_opcode(compu_node, f_opflow)
                
                elif compu_node.node_type == NodeType.CpuType and compu_node.cpu_optype == CpuOpcode.DIDMA :
                    self.gen_DIDMA_opcode(compu_node, f_opflow)
                    if(compu_node.datanode_in not in DataNodeList):
                        DataNodeList.append(compu_node.datanode_in)
                elif compu_node.node_type == NodeType.CpuType and compu_node.cpu_optype == CpuOpcode.DODMA :
                    self.gen_DODMA_opcode(compu_node, f_opflow)
                    if(compu_node.datanode_out not in DataNodeList):
                        DataNodeList.append(compu_node.datanode_out)
                elif compu_node.node_type == NodeType.CpuType and compu_node.cpu_optype == CpuOpcode.Concat :
                    self.gen_Concat_opcode(compu_node, f_opflow)
                    
                    ### datanode_in
                    for datanode in compu_node.datanode_in:
                        if(datanode not in DataNodeList):
                            DataNodeList.append(datanode)

                    ### datanode_out
                    if(compu_node.datanode_out not in DataNodeList):
                        DataNodeList.append(compu_node.datanode_out)
                
                elif compu_node.node_type == NodeType.NpuType:
                    self.gen_npu_opcode(compu_node, f_opflow)
                    
                elif compu_node.node_type == NodeType.CpuType and compu_node.cpu_optype == CpuOpcode.Shift :
                    self.gen_Shift_opcode(compu_node, f_opflow)
                elif compu_node.node_type == NodeType.CpuType and compu_node.cpu_optype == CpuOpcode.L2Norm:
                    self.gen_L2Norm_opcode(compu_node, f_opflow)
                elif compu_node.node_type == NodeType.CpuType and compu_node.cpu_optype == CpuOpcode.Flatten:
                    self.gen_Flatten_opcode(compu_node, f_opflow)
                elif compu_node.node_type == NodeType.CpuType and compu_node.cpu_optype == CpuOpcode.Softmax:
                    self.gen_Softmax_opcode(compu_node, f_opflow)
                elif compu_node.node_type == NodeType.CpuType and compu_node.cpu_optype == CpuOpcode.LUTDMA:
                    self.gen_LUTDMA_opcode(compu_node, f_opflow)
                else:
                    assert False, "Unsupport Computation Node: {}".format(compu_node.__class__.__name__)
            for DataNode in DataNodeList:
                self.gen_datanode_opcode(DataNode, f_opflow)


    def gen_CDMA_opcode(self, CDMA_Node, f_opflow):
        f_opflow.write(struct.pack(">I", CDMA_Node.index))             ### Index
        f_opflow.write(struct.pack(">I", 0))                           ### Node type
        f_opflow.write(struct.pack(">I", CDMA_Node.next_node.index))   ### Next node index
        f_opflow.write(struct.pack(">I", 0))                           ### opcodeID
        f_opflow.write(struct.pack(">I", int(CDMA_Node.start_addr, 16)))  ### startAddr
        f_opflow.write(struct.pack(">I", int(CDMA_Node.len, 16)))               ### len
    
    def gen_WDMA_opcode(self, WDMA_Node, f_opflow):
        f_opflow.write(struct.pack(">I", WDMA_Node.index))             ### Index
        f_opflow.write(struct.pack(">I", 0))                           ### Node type
        f_opflow.write(struct.pack(">I", WDMA_Node.next_node.index))   ### Next node index
        f_opflow.write(struct.pack(">I", 1))                           ### opcodeID
        f_opflow.write(struct.pack(">I", int(WDMA_Node.start_addr, 16)))        ### startAddr
        f_opflow.write(struct.pack(">I", int(WDMA_Node.len, 16)))               ### len
 
    def gen_PDMA_opcode(self, PDMA_Node, f_opflow):
        f_opflow.write(struct.pack(">I", PDMA_Node.index))             ### Index
        f_opflow.write(struct.pack(">I", 0))                           ### Node type
        f_opflow.write(struct.pack(">I", PDMA_Node.next_node.index))   ### Next node index
        f_opflow.write(struct.pack(">I", 5))                           ### opcodeID
        f_opflow.write(struct.pack(">I", int(PDMA_Node.param.data_bw, 16)))        ### startAddr
        f_opflow.write(struct.pack(">I", int(PDMA_Node.param.start_addr, 16)))        ### startAddr
        f_opflow.write(struct.pack(">I", int(PDMA_Node.param.len, 16)))               ### len

    def gen_DIDMA_opcode(self, DIDMA_Node, f_opflow):
        f_opflow.write(struct.pack(">I", DIDMA_Node.index))            ### Index
        f_opflow.write(struct.pack(">I", 0))                           ### Node type
        f_opflow.write(struct.pack(">I", DIDMA_Node.next_node.index))  ### Next node index
        f_opflow.write(struct.pack(">I", 2))                           ### opcodeID
        f_opflow.write(struct.pack(">I", DIDMA_Node.datanode_in.index)) ### inputNodeIdx
        f_opflow.write(struct.pack(">I", DIDMA_Node.param.offset))      ### offset
        f_opflow.write(struct.pack(">I", DIDMA_Node.param.rowPitchLen)) ### rowPitchLen
        f_opflow.write(struct.pack(">I", DIDMA_Node.param.rowPitchNum)) ### rowPitchNum
        f_opflow.write(struct.pack(">I", DIDMA_Node.param.rowLen))      ### rowLen
        f_opflow.write(struct.pack(">I", DIDMA_Node.param.chPitchLen))  ### chPitchLen
        f_opflow.write(struct.pack(">I", DIDMA_Node.param.chPitchNum))  ### chPitchNum
        f_opflow.write(struct.pack(">I", DIDMA_Node.param.sram_offset[0] << 4 + 
                                        DIDMA_Node.param.sram_offset[1])) ### sram_offset ????
        f_opflow.write(struct.pack(">I", DIDMA_Node.param.dmem))        ### dmem
        f_opflow.write(struct.pack(">I", DIDMA_Node.param.preprocessType))       ### doAdd

    def gen_DODMA_opcode(self, DODMA_Node, f_opflow):
        f_opflow.write(struct.pack(">I", DODMA_Node.index))             ### Index
        f_opflow.write(struct.pack(">I", 0))                            ### Node type
        if (DODMA_Node.next_node):
            f_opflow.write(struct.pack(">I", DODMA_Node.next_node.index))   ### Next node index
        else:
            f_opflow.write(b'\xFF\xFF\xFF\xFF')
        f_opflow.write(struct.pack(">I", 3))                            ### opcodeID
        f_opflow.write(struct.pack(">I", DODMA_Node.datanode_out.index))    ### outputNodeIdx
        f_opflow.write(struct.pack(">I", DODMA_Node.param.offset))      ### offset
        f_opflow.write(struct.pack(">I", DODMA_Node.param.rowPitchLen)) ### rowPitchLen
        f_opflow.write(struct.pack(">I", DODMA_Node.param.rowPitchNum)) ### rowPitchNum
        f_opflow.write(struct.pack(">I", DODMA_Node.param.rowLen))      ### rowLen
        f_opflow.write(struct.pack(">I", DODMA_Node.param.chPitchLen))  ### chPitchLen
        f_opflow.write(struct.pack(">I", DODMA_Node.param.chPitchNum))  ### chPitchNum
        f_opflow.write(struct.pack(">I", DODMA_Node.param.sram_offset[0] << 4 +
                                        DODMA_Node.param.sram_offset[1])) ### sram_offset
        f_opflow.write(struct.pack(">I", DODMA_Node.param.smem))        ### smem


    def gen_Concat_opcode(self, Concat_Node, f_opflow):
        f_opflow.write(struct.pack(">I", Concat_Node.index))           ### Index
        f_opflow.write(struct.pack(">I", 0))                           ### Node type
        if (Concat_Node.next_node):
            f_opflow.write(struct.pack(">I", Concat_Node.next_node.index)) ### Next node index
        else:
            f_opflow.write(b'\xFF\xFF\xFF\xFF')
        f_opflow.write(struct.pack(">I", 4))                           ### opcodeID
        f_opflow.write(struct.pack(">I", Concat_Node.axis))            ### axis
        numOfInputNodes = len(Concat_Node.datanode_in)  
        f_opflow.write(struct.pack(">I", numOfInputNodes))             ### numOfInputNodes
        for i in range(numOfInputNodes):
            f_opflow.write(struct.pack(">I", Concat_Node.datanode_in[i].index))            ### inputNodeIdx
        
        f_opflow.write(struct.pack(">I", Concat_Node.datanode_out.index)) ### outputNodeIdx

    def gen_npu_opcode(self, Npu_Node, f_opflow):
        f_opflow.write(struct.pack(">I", Npu_Node.index))              ### index
        f_opflow.write(struct.pack(">I", 1))                           ### Node type
        f_opflow.write(struct.pack(">I", Npu_Node.next_node.index))    ### Next node index

    def gen_LUTDMA_opcode(self, LUTDMA_node, f_opflow):
        f_opflow.write(struct.pack(">I", LUTDMA_node.index))           ### index
        f_opflow.write(struct.pack(">I", 0))                           ### Node type
        if(LUTDMA_node.next_node):
            f_opflow.write(struct.pack(">I", LUTDMA_node.next_node.index)) ### Next Node Index
        else:
            f_opflow.write(b'\xFF\xFF\xFF\xFF')
        f_opflow.write(struct.pack(">I", 7))                           ### OpcodeID
        f_opflow.write(struct.pack(">I", LUTDMA_node.lutnode.addr)) ### addr
        f_opflow.write(struct.pack(">I", LUTDMA_node.lutnode.addr_len)) ### addr_len
        assert(LUTDMA_node.lutnode.addr_len == 4096 * 16 * 2), "Addrlen or Addrnum is wrong!!!"

    def gen_datanode_opcode(self, Data_Node, f_opflow):
        f_opflow.write(struct.pack(">I", Data_Node.index))             ### Index
        f_opflow.write(struct.pack(">I", 2))                           ### Node type
        f_opflow.write(struct.pack(">I", int(Data_Node.addr, 16)))              ### addr
        f_opflow.write(struct.pack(">I", Data_Node.format))            ### format
        f_opflow.write(struct.pack(">I", Data_Node.height))            ### height
        f_opflow.write(struct.pack(">I", Data_Node.width))             ### width
        f_opflow.write(struct.pack(">I", Data_Node.channel))           ### channel  
    
    def gen_Shift_opcode(self, Shift_Node, f_opflow):
        f_opflow.write(struct.pack(">I", Shift_Node.index)) # Index
        f_opflow.write(struct.pack(">I", 0)) # NodeType
        if(Shift_Node.next_node):
            f_opflow.write(struct.pack(">I", Shift_Node.next_node.index)) # next node index
        f_opflow.write(struct.pack(">I", 6)) # opcode

    def gen_Flatten_opcode(self, Flatten_Node, f_opflow):
        f_opflow.write(struct.pack(">I", Flatten_Node.index)) # Index
        f_opflow.write(struct.pack(">I", 0)) # NodeType
        if(Flatten_Node.next_node):
            f_opflow.write(struct.pack(">I", Flatten_Node.next_node.index)) # next node index
        f_opflow.write(struct.pack(">I", 8)) # opcode
    
    def gen_L2Norm_opcode(self, L2Norm_Node, f_opflow):
        f_opflow.write(struct.pack(">I", L2Norm_Node.index)) # Index
        f_opflow.write(struct.pack(">I", 0)) # NodeType
        if L2Norm_Node.next_node:
            f_opflow.write(struct.pack(">I", L2Norm_Node.next_node.index)) # next node index
        else:
            f_opflow.write(b'\xFF\xFF\xFF\xFF')
        f_opflow.write(struct.pack(">I", 8))                           ### OpcodeID
        f_opflow.write(struct.pack(">I", L2Norm_Node.datanode_in.index)) ### inputNodeIdx
        f_opflow.write(struct.pack(">I", L2Norm_Node.datanode_out.index)) ### outputNodeIdx
        f_opflow.write(struct.pack(">I", int(L2Norm_Node.param.start_addr, 16))) ### addr

    def gen_Softmax_opcode(self, Softmax_Node, f_opflow):
        f_opflow.write(struct.pack(">I", Softmax_Node.index)) # Index
        f_opflow.write(struct.pack(">I", 0)) # NodeType
        if Softmax_Node.next_node:
            f_opflow.write(struct.pack(">I", Softmax_Node.next_node.index)) # next node index
        f_opflow.write(struct.pack(">I", 9)) # opcode

    def display_compu_node(self, computer_graph, datanode_set):
        opcodeStrMap = {CpuOpcode.CDMA: "CDMA", CpuOpcode.WDMA: "WDMA", CpuOpcode.DIDMA: "DIDMA", CpuOpcode.DODMA: "DODMA",
                    CpuOpcode.Concat: "Concat", CpuOpcode.PDMA: "PDMA", CpuOpcode.Shift: "Shift", CpuOpcode.LUTDMA: "LutDma"}
        opcodeMap = {CpuOpcode.CDMA: 0, CpuOpcode.WDMA: 1, CpuOpcode.DIDMA: 2, CpuOpcode.DODMA: 3,
                    CpuOpcode.Concat: 4, CpuOpcode.PDMA: 5, CpuOpcode.Shift: 6, CpuOpcode.LUTDMA: 7}
        opflow = open('/mnt/d/opflow.txt', 'w')
        for node in computer_graph:
            print("-------------------------------------------------------")
            if(node.node_type == NodeType.CpuType and (node.cpu_optype == CpuOpcode.CDMA or node.cpu_optype == CpuOpcode.WDMA)):
                print("node opcode name: %s" % (opcodeStrMap[node.cpu_optype]), file = opflow)
                print("node index: %d" % (node.index), file = opflow)
                print("Node type: 0", file = opflow)
                print("next node index: %d" % (node.next_node.index), file = opflow)
                print("opcodeID: %d" % (opcodeMap[node.cpu_optype]), file = opflow)
                print("startAddr: %d" % (int(node.start_addr, 16)), file = opflow)
                print("len: %d" % (int(node.len, 16)), '\n',  file = opflow)
            elif (node.node_type == NodeType.CpuType and node.cpu_optype == CpuOpcode.LUTDMA):
                print("node opcode name: %s" % (opcodeStrMap[node.cpu_optype]), file = opflow)
                print("node index: %d" % (node.index), file = opflow)
                print("Node type: 0", file = opflow)
                print("next node index: %d" % (node.next_node.index), file = opflow)
                print("opcodeID: %d" % (opcodeMap[node.cpu_optype]), '\n',file = opflow)
            elif(node.node_type == NodeType.CpuType and node.cpu_optype == CpuOpcode.PDMA):
                print("node opcode name: %s" % (opcodeStrMap[node.cpu_optype]), file = opflow)
                print("node index: %d" % (node.index), file = opflow)
                print("Node type: 0", file = opflow)
                print("next node index: %d" % (node.next_node.index), file = opflow)
                print("opcodeID: %d" % (opcodeMap[node.cpu_optype]), file = opflow)
                print("startAddr: %d" % (int(node.param.start_addr, 16)), file = opflow)
                print("len: %d" % (int(node.param.len, 16)), '\n', file = opflow)
            elif(node.node_type == NodeType.CpuType and node.cpu_optype == CpuOpcode.DIDMA):
                print("node opcode name: %s" % (opcodeStrMap[node.cpu_optype]), file = opflow)
                print("node index: %d" % (node.index), file = opflow)
                print("Node type: 0", file = opflow)
                print("next node index: %d" % (node.next_node.index), file = opflow)
                print("opcodeID: %d" % (opcodeMap[node.cpu_optype]), file = opflow)
                print("datanode_in index: %d" % (node.datanode_in.index), file = opflow)
                print("offset: %d" % (node.param.offset), file = opflow)
                print("rowPitchLen: %d" % (node.param.rowPitchLen), file = opflow)
                print("rowPitchNum: %d" % (node.param.rowPitchNum), file = opflow)
                print("rowLen: %d" % (node.param.rowLen), file = opflow)
                print("channelPitchLen: %d" % (node.param.chPitchLen), file = opflow)
                print("channelPitchNum: %d" % (node.param.chPitchNum), file = opflow)
                print("sram offset: %d" % (node.param.sram_offset[0] << 4 + node.param.sram_offset[1]), file = opflow)
                print("node dmem: %d" % (node.param.dmem), file = opflow)
                print("preprocessType: %d" % (node.param.preprocessType), '\n', file = opflow)
            elif(node.node_type == NodeType.CpuType and node.cpu_optype == CpuOpcode.DODMA):
                print("node opcode name: %s" % (opcodeStrMap[node.cpu_optype]), file = opflow)
                print("node index: %d" % (node.index), file = opflow)
                print("Node type: 0", file = opflow)
                if(node.next_node):
                    print("next node index: %d" % (node.next_node.index), file = opflow)
                else:
                    print("4294967295", file = opflow)
                print("opcodeID: %d" % (opcodeMap[node.cpu_optype]), file = opflow)
                print("datanode_out index: %d" % (node.datanode_out.index), file = opflow)
                print("offset: %d" % (node.param.offset), file = opflow)
                print("rowPitchLen: %d" % (node.param.rowPitchLen) ,file = opflow)
                print("rowPitchNum: %d" % (node.param.rowPitchNum), file = opflow)
                print("rowLen: %d" % (node.param.rowLen), file = opflow)
                print("channelPitchLen: %d" % (node.param.chPitchLen), file = opflow)
                print("channelPitchNum: %d" % (node.param.chPitchNum), file = opflow)
                print("sram offset: %d" % (node.param.sram_offset[0] << 4 + node.param.sram_offset[1]), file = opflow)
                print("node dmem: %d" % (node.param.smem), '\n', file = opflow)
            elif(node.node_type == NodeType.CpuType and node.cpu_optype == CpuOpcode.Concat):
                print("node opcode name: %s" % (opcodeStrMap[node.cpu_optype]), file = opflow)
                print("node index: %d" % (node.index), file = opflow)
                print("Node type: 0", file = opflow)
                if(node.next_node):
                    print("next node index: %d" % (node.next_node.index), file = opflow)
                else:
                    print("4294967295", file = opflow)
                print("opcodeID: %d" % (opcodeMap[node.cpu_optype]), file = opflow)
                print("Concat axis: %d" % (node.axis), file = opflow)
                print("# of input node: %d" % (len(node.datanode_in)), file = opflow)
                for node_in in node.datanode_in:
                    print("node in index: %d" % (node_in.index), file = opflow)
                print("datanode_out index: %d" % (node.datanode_out.index), '\n', file = opflow)
            elif(node.node_type == NodeType.NpuType):
                print("node type name: NpuNode", file = opflow)
                print("node index: %d" % (node.index), file = opflow)
                print("Node type: 1", file = opflow)
                print("next node index: %d" % (node.next_node.index), '\n', file = opflow)
        for node in datanode_set:
            print("--------------------------------------------------")
            print("node type name: DataNode", file = opflow)
            print("node index: %d" % (node.index), file = opflow)
            print("node type: 2", file = opflow)
            print("node addr: %d" % (int(node.addr, 16)), file = opflow)
            print("node format: %d" % (node.format), file = opflow)
            print("height: %d width %d channel: %d" % (node.height, node.width, node.channel), '\n', file = opflow)
        opflow.close()