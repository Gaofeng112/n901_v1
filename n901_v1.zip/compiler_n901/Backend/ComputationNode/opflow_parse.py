import struct
import os
import logging

class opflow_parse(object):
    def __init__(self, bin_file_path, log_level, log_file_path):
        self.opflow_file_path = bin_file_path
        self.log_level = log_level
        self.log_file_path = log_file_path
    def parse(self):
        if(os.path.exists(self.log_file_path)):
            os.remove(self.log_file_path)
        logging.basicConfig(filename=self.log_file_path, 
                            format='%(message)s', 
                            level=self.log_level)
        with open(self.opflow_file_path, 'rb') as f:
            file_size = os.path.getsize(self.opflow_file_path)
            loop_cnt = int(file_size) / 4
            i = 0
            print(loop_cnt)
            while(i < loop_cnt):
                f.seek(i * 4, 0)
                index_bin_str = f.read(4)
                node_type_bin_str = f.read(4)
                i += 2
                index = struct.unpack(">I", index_bin_str)[0]
                node_type = struct.unpack(">I", node_type_bin_str)[0]
                parse_list = [index, node_type]
                if(node_type == 0):
                    i, res_list = self.parse_cpu_opcode(f, i)
                    parse_list.extend(res_list)
                    if(parse_list[-1] == "CWP"):
                        logging.info("NodeIndex: {} NodeType: {} NextNodeIndex: {} opcodeID: {} startAddr: {} len: {}".
                        format(parse_list[0], parse_list[1], parse_list[2], parse_list[3], parse_list[4], parse_list[5]))
                    elif(parse_list[-1] == 'DI'):
                        logging.info("NodeIndex: {} NodeType: {} NextNodeIndex: {} opcodeID: {} InputNodeIdx: {} OffSet: {} rowPitchLen: {} rowPitchNum: {} rowLen: {} chPitchLen: {} chPitchNum: {} sram_offset: {} dmem: {} doAdd: {}" \
                            .format(parse_list[0], parse_list[1], parse_list[2], parse_list[3], parse_list[4], parse_list[5], \
                                    parse_list[6], parse_list[7], parse_list[8], parse_list[9], parse_list[10], parse_list[11], \
                                    parse_list[12], parse_list[13]))
                    elif(parse_list[-1] == 'DO'):
                        logging.info("NodeIndex: {} NodeType: {} NextNodeIndex: {} opcodeID: {} outputNodeIdx: {} offset {} rowPitchLen {} rowPitchNum {} rowLen {} chPitchLen {} chPitchNum {} sram_offset {} smem {}" \
                            .format(parse_list[0], parse_list[1], parse_list[2], parse_list[3], parse_list[4], parse_list[5],
                                    parse_list[6], parse_list[7], parse_list[8], parse_list[9], parse_list[10], parse_list[11],
                                    parse_list[12]))
                    elif(parse_list[-1] == 'Concat'):
                        logging.info("NodeIndex: {} NodeType: {} NextNodeIndex: {} opcodeID: {} axis: {} numOfInputNodes {} " \
                            .format(parse_list[0], parse_list[1], parse_list[2], parse_list[3], parse_list[4],parse_list[5]))
                        for j in range(parse_list[5]):
                            logging.info("InputNodeIndex: {}".format(parse_list[6 + j]))
                        logging.info("outputNodeIdx: {}".format(parse_list[-2]))
                    else:
                        assert False, "Unsupported Node Type!"
                elif(node_type == 1):
                    i, res_list = self.parse_npu_opcode(f, i)
                    parse_list.extend(res_list)
                    logging.info("Index: {} NodeType: {} NextNodeIndex: {}".format(parse_list[0], parse_list[1], parse_list[2],))
                elif(node_type == 2):
                    i, res_list = self.parse_datanode_opcode(f, i)
                    parse_list.extend(res_list)
                    logging.info("Index: {} NodeType: {} addr: {} format: {} height: {} width: {} channel: {}"\
                        .format(parse_list[0], parse_list[1], parse_list[2], parse_list[3], parse_list[4],
                                parse_list[5], parse_list[6]))
                else:
                    print(index)
                    print(node_type)
                    assert False, "Unsupported Node Type!"

    def parse_cpu_opcode(self, bin_file, idx):
        bin_file.seek(idx * 4, 0)
        next_node_index_bin_str = bin_file.read(4)
        next_node_index = struct.unpack(">I", next_node_index_bin_str)[0]
        opcodeID_bin_str = bin_file.read(4)
        opcodeID = struct.unpack(">I", opcodeID_bin_str)[0]
        idx += 2
        if(opcodeID == 0 or opcodeID == 1 or opcodeID == 5):
            idx, parse_res = self.parse_CWPDMA_opcode(bin_file, idx)
        elif(opcodeID == 2):
            idx, parse_res = self.parse_DIDMA_opcode(bin_file, idx)
        elif(opcodeID == 3):
            idx, parse_res = self.parse_DODMA_opcode(bin_file, idx)
        elif(opcodeID == 4):
            idx, parse_res = self.parse_concat_opcode(bin_file, idx)
        else:
            assert False, "Unsupported Node Type"
        res = [next_node_index, opcodeID]
        res.extend(parse_res)
        return idx, res

    def parse_npu_opcode(self, bin_file, idx):
        bin_file.seek(idx * 4, 0)
        next_node_index_bin_str = bin_file.read(4)
        next_node_index = struct.unpack(">I", next_node_index_bin_str)[0]
        idx += 1
        return idx, [next_node_index]
    
    def parse_datanode_opcode(self, bin_file, idx):
        bin_file.seek(idx * 4, 0)
        addr = struct.unpack(">I", bin_file.read(4))[0]
        format = struct.unpack(">I", bin_file.read(4))[0]
        height = struct.unpack(">I", bin_file.read(4))[0]
        width = struct.unpack(">I", bin_file.read(4))[0]
        channel = struct.unpack(">I", bin_file.read(4))[0]
        idx += 5
        return idx, [addr, format, height, width, channel]
    
    def parse_CWPDMA_opcode(self, bin_file, idx):
        bin_file.seek(idx * 4, 0)
        startAddr = struct.unpack(">I", bin_file.read(4))[0]
        len = struct.unpack(">I", bin_file.read(4))[0]
        idx += 2
        return idx, [startAddr, len, "CWP"]
    
    def parse_DIDMA_opcode(self, bin_file, idx):
        bin_file.seek(idx * 4, 0)
        res = []
        for i in range(10):
            val = struct.unpack(">I", bin_file.read(4))[0]
            res.append(val)
            idx += 1
        res.append("DI")
        return idx, res
    
    def parse_DODMA_opcode(self, bin_file, idx):
        bin_file.seek(idx * 4, 0)
        res = []
        for i in range(9):
            val = struct.unpack(">I", bin_file.read(4))[0]
            res.append(val)
            idx += 1
        res.append("DO")
        return idx, res
    
    def parse_concat_opcode(self, bin_file, idx):
        bin_file.seek(idx * 4, 0)
        res = []
        for i in range(4):
            if(i == 2):
                for j in range(res[-1]):
                    res.append(struct.unpack(">I", bin_file.read(4))[0])
                    idx += 1
            else:
                res.append(struct.unpack(">I", bin_file.read(4))[0])
                idx += 1
        res.append("Concat")
        return idx, res

if __name__ == "__main__":
    bin_file_path_golden = "/data/zhangchenshuo/bin_file/auto_cut/yolov3_auto_uncompress/opflow.bin"
    log_level = "INFO"
    log_file_path_golden = "./opflow_golden_parse_3.log"
    bin_file_path_manual = "/data/zhangchenshuo/bin_file/manual_cut/yolov3_manual_uncompress/opflow.bin"
    log_level = "INFO"
    log_file_path_manual = "./opflow_manual_parse_3.log"
    opflow_parse(bin_file_path_golden, log_level, log_file_path_golden).parse()
    # opflow_parse(bin_file_path_manual, log_level, log_file_path_manual).parse()
    
    # f_golden = open(log_file_path_golden, "r+")
    # f_manual = open(log_file_path_manual, "r+")
    # lines_golden = f_golden.readlines()
    # lines_manual = f_manual.readlines()
    # assert(len(lines_golden) == len(lines_manual))
    # for i in range(len(lines_golden)):
    #     l1 = lines_golden[i]
    #     l2 = lines_manual[i]
    #     if(l1 != l2):
    #         print(i)


