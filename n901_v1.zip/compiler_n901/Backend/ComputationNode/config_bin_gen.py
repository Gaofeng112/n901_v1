import struct
from .computation_node_def import (NodeType, CpuOpcode)
from Frontend.Node.node_def import NodeOpType
import pdb
import json
import os

class ConfigBinGenAgent(object):
    def __init__(self):
        pass

    def fill_config_bin(self, cmd_nodes, path, memory_json_path):
        # print('fill_config_bin start')
        ## get start address of cmd.bin and weight.bin
        json_file = open(memory_json_path, 'r', encoding='utf-8')
        start_addr_info_dict = json.load(json_file)
        cmd_bin_start_addr = int(start_addr_info_dict["cmd_start_addr"], 16)
        weight_bin_start_addr = int(start_addr_info_dict["weight_start_addr"], 16)
        ## get number of input datanode and output datanode
        input_datanode_num = 0
        for node in list(cmd_nodes.datanode_dict.keys()):
            if node.op_type == NodeOpType.InputNode:
                input_datanode_num += 1
        output_datanode_num = int(len(list(cmd_nodes.output_datanode_dict.values())))
        ## write config.bin
        filepath = os.path.join(path, "config.bin")
        with open(filepath, 'wb') as f_config:
            ## mode
            f_config.write(b'\x00\x00\x00\x01') # 0: SingleLayer, 1: Full model
            ## start address of cmd.bin file
            f_config.write(struct.pack(">I", cmd_bin_start_addr))
            ## start address of weight.bin file
            f_config.write(struct.pack(">I", weight_bin_start_addr))
            ## number of input data node
            f_config.write(struct.pack(">I", input_datanode_num))
            ## the indexes of all the input datanode
            for node in list(cmd_nodes.datanode_dict.keys()):
                if node.op_type == NodeOpType.InputNode:
                    data_node = cmd_nodes.datanode_dict[node]
                    f_config.write(struct.pack(">I", data_node.index))
            ## number of output data node
            f_config.write(struct.pack(">I", output_datanode_num))
            ## the indexes of all the output datanode
            for data_node in list(cmd_nodes.output_datanode_dict.values()):
                f_config.write(struct.pack(">I", data_node.index))
