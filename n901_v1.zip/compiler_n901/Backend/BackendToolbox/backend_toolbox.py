import pdb
import math

class BackendToolbox(object):
    def __init__(self):
        pass

    def get_8bit_datanode_dma(self, cmd_node_list):
        ## this function modify all the data_node to 8 bit
        for cmd_node in cmd_node_list:
            ## dodma
            dodma = cmd_node.DODMA_param
            data_node = cmd_node.datanode_out[0]
            # print('------------------------------------')
            # print('dodma', dodma.__dict__)
            # print('data_node', data_node.__dict__)
            # print('------------------------------------')
            if data_node.format == 0:
                dodma.rowLen = int(dodma.rowLen * \
                    math.ceil(data_node.width/16) / math.ceil(data_node.width/8))
                dodma.rowPitchLen = int(dodma.rowPitchLen * \
                    math.ceil(data_node.width/16) / math.ceil(data_node.width/8))
                dodma.chPitchLen = int(dodma.chPitchLen * \
                    math.ceil(data_node.width/16) / math.ceil(data_node.width/8))
            elif data_node.format == 1:
                dodma.chPitchNum = int(dodma.chPitchNum * \
                    math.ceil(data_node.channel/64) / math.ceil(data_node.channel/32))
            # print('------------------------------------')
            # print('dodma', dodma.__dict__)
            # print('data_node', data_node.__dict__)
            # print('------------------------------------')
            ## didma
            for didma, data_node in zip(cmd_node.DIDMA_param, cmd_node.datanode_in):
                # print('------------------------------------')
                # print('didma', didma.__dict__)
                # print('data_node', data_node.__dict__)
                # print('------------------------------------')
                if data_node.format == 0:
                    didma.rowLen = int(didma.rowLen * \
                        math.ceil(data_node.width/16) / math.ceil(data_node.width/8))
                    didma.rowPitchLen = int(didma.rowPitchLen * \
                        math.ceil(data_node.width/16) / math.ceil(data_node.width/8))
                    didma.chPitchLen = int(didma.chPitchLen * \
                        math.ceil(data_node.width/16) / math.ceil(data_node.width/8))
                elif data_node.format == 1:
                    didma.chPitchNum = int(didma.chPitchNum * \
                        math.ceil(data_node.channel/64) / math.ceil(data_node.channel/32))
                # print('------------------------------------')
                # print('didma', didma.__dict__)
                # print('data_node', data_node.__dict__)
                # print('------------------------------------')
        for cmd_node in cmd_node_list:
            ## data_node
            for data_node in (cmd_node.datanode_in + cmd_node.datanode_out):
                # print('------------------------------------')
                # print('data_node', data_node.__dict__)
                # print('------------------------------------')
                if data_node.format == 0:
                    data_node.format = 3
                    data_node.addr_len = int(data_node.addr_len * \
                        math.ceil(data_node.width/16) / math.ceil(data_node.width/8))
                elif data_node.format == 1:
                    data_node.format = 4
                    data_node.addr_len = int(data_node.addr_len * \
                        math.ceil(data_node.channel/64) / math.ceil(data_node.channel/32))
                # print('------------------------------------')
                # print('data_node', data_node.__dict__)
                # print('------------------------------------')
