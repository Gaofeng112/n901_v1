from re import L
import onnx
import os
import shutil
import pdb
import copy

from Frontend.Graph.graph_def import Graph
from Frontend.Node.node_def import Node
from Frontend.HWToolBox.N900HWToolBox import N900HWToolBox
from Frontend.Hardware.hardware_info import HardWareInfo
from Frontend.Visitors.graph_visitor import GraphVisitor
from Frontend.Visitors.datanode_dict_visitor import DataNodeDictVisitor
from Frontend.Visitors.bin_merge import BinMerge

from Middleend.GroupAssigner.node_group_def import NodeGroup
# from Middleend.GroupAssigner.group_assigner import GroupAssigner
from Middleend.GroupAssigner.group_assigner_v2 import GroupAssigner
from Middleend.GroupAssigner.image_cut import ImageCut

from Backend.CmdNode.cmd_nodes_gen import CmdNodeContainer
from Backend.ComputationNode.compu_graph_generator import CompuGraphGenerator
from Backend.ComputationNode.computation_node_def import (CompuNode, CpuCompuNode, CdmaCompuNode,
    WdmaCompuNode, DidmaCompuNode, NpuCompuNode, DodmaCompuNode)

from Backend.ComputationNode.opflow_gen import OpflowGenAgent
from Backend.ComputationNode.config_bin_gen import ConfigBinGenAgent

from Middleend.ManualCut.get_group_image_cut_file import get_group_image_cut_file
from Middleend.ManualCut.check_cut import check_cut
from Middleend.ManualCut.get_chunk_from_file import get_chunk_from_file
from Middleend.ManualCut.check_gen_group import check_gen_group
from Middleend.ManualCut.get_group_image_cut_file import get_group_image_cut_file

import json
import time
import logging
import argparse

def main_(args):
    time0 = time.time()
    onnx_file_path = args.onnx_file_path
    hardware_config_file_path = args.hw_config_file_path
    scaling_factor_file_path = args.scale_file_path
    memory_file_path = args.memory_file_path
    log_level = "INFO"
    debug_mode = False
    process_cnt = int(args.process_cnt)
    output_path = args.result_path
    result_path = output_path + '/case_ncf'
    release_version = False
    if args.not_compress == False and args.not_compress_fm == False:
        compress_weight = True
        compress_fm = True
        print('compressed weight and datanode')
    # if args.not_compress == True and args.not_compress_fm == False:
    #     compress_weight = False
    #     compress_fm = True
    #     print('uncompressed weight and compress datanode')
    if args.not_compress == False and args.not_compress_fm == True:
        compress_weight = True
        compress_fm = False
        print('compress weight and uncompress datanode')
    # compress_weight = True
    # if args.not_compress == True and args.not_compress_fm == True:
    #     compress_weight = False
    #     compress_fm = False
    #     print('uncompress weight and datanode')

    logging.basicConfig(format='%(message)s', level=log_level)

    logging.critical("Compiling Start!")
    # pdb.set_trace()
    # current_path = os.path.abspath(__file__)
    # current_path = os.path.dirname(current_path)
    # result_path = os.path.join(current_path, "Result")  ### result path 

    if (os.path.exists(result_path)):
        shutil.rmtree(result_path)
    os.mkdir(result_path)

    # if(os.path.exists(manual_cut_file)):
    #     os.remove(manual_cut_file)
    myHw_info1 = HardWareInfo(hardware_config_file_path, scaling_factor_file_path)
    myGraph = Graph(onnx_file_path, myHw_info = myHw_info1)
    if(debug_mode):
        topo_sort = GraphVisitor().topo_sort(myGraph)
    else:
        toolbox = N900HWToolBox()
        toolbox.HardwareFusion(myGraph)

        topo_sort = GraphVisitor().topo_sort(myGraph)
    # N900HWToolBox().reverse_concat_input(topo_sort)
    time1 = time.time()
    logging.info("Frontend done! Time used is {}".format(time1 - time0))
    assigned_groups = GroupAssigner().assigner(topo_sort, debug_mode)
    ImageCut().image_cut(assigned_groups)
    time2 = time.time()
    logging.info("Middleend done! Time used is {}".format(time2 - time1))
    CmdNodes = CmdNodeContainer(compress_weight, compress_fm)
    CmdNodes.build_cmdnode(assigned_groups, myGraph, myHw_info1, process_cnt, memory_file_path, result_path)

    compu_node_list = CompuGraphGenerator().compu_graph_generator(CmdNodes.cmd_node_list)
    time_c = time.time()
    logging.debug("Time used by gen cmd and weight is {}".format(time_c - time2))

    # pdb.set_trace()
    OpflowGenAgent().fill_opflow(compu_node_list, result_path)
    # datanode_list = list(CmdNodes.datanode_dict.values())
    # OpflowGenAgent().display_compu_node(compu_node_list, datanode_list)
    ConfigBinGenAgent().fill_config_bin(CmdNodes, result_path, memory_file_path)
    time3 = time.time()
    logging.info("Backend done! Time used is {}".format(time3 - time2))
    logging.critical("Total time is {}".format(time3 - time0))
    logging.critical("Compiling End!")
    BinMerge().merge_bin_files(result_path, output_path)
    ## get json file for debug of cmodel
    DataNodeDictVisitor().write_datanode_map_json(CmdNodes.datanode_dict, result_path)
    GraphVisitor().write_datanode_map_bin(compu_node_list, result_path)
    GraphVisitor().write_hf_map_json(CmdNodes.cmd_node_list, result_path)
    DataNodeDictVisitor().write_datanode_map_txt(CmdNodes.datanode_dict, result_path)
    DataNodeDictVisitor().write_compressed_datanode_json(CmdNodes.cmd_node_list, CmdNodes.output_datanode_dict, result_path)
    if release_version:
        shutil.rmtree(result_path)
    onnx_name = onnx_file_path.split('/')[-1]
    json_name = scaling_factor_file_path.split('/')[-1]
    shutil.copyfile(onnx_file_path, output_path + '/' + onnx_name)
    shutil.copyfile(scaling_factor_file_path, output_path + '/' + json_name)
if __name__ == "__main__":

    argparser = argparse.ArgumentParser(
            description="This is the interface of Compiler\n\n\
                python3 Compiler.py -o onnx_file_path -hw hw_config_file_path -s scale_file_path -m memory_file_path -r result_path -l log_level -c cut_method -mcf manual_cut_file\n\n\
                onnx_file_path      : the input onnx model file path \n\n\
                hw_config_file_path : the input hardware config file path \n\n\
                scale_file_path     : the input scaling_factor file path  \n\n\
                memory_file_path    : the input memory config file path  \n\n\
                result_path         : the result path which saves the output results \n\n\
                log_level           : the log level \n\n\
                cut_method          : image cut method: auto cut or manual cut \n\n\
                manual_cut_file     : the image cut file path if choose manual cut \n\n\
                process_cnt         : the compiler running process count \n\n\
                ",
            # formatter_class=argparse.RawTextHelpFormatter
            )

    argparser.add_argument(
        '-o',
        '--onnx_file_path',
        help="path of input onnx model file, to compiler into the binary files",
        default="",
        )

    argparser.add_argument(
        '-hw',
        '--hw_config_file_path',
        help="path of hardware config file, which saves the hardware bitwidth info",
        default="",
        )

    argparser.add_argument(
        '-s',
        '--scale_file_path',
        help="path of scaling_factor file, which saves the scaling factor info of the model",
        default="",
        )
    
    argparser.add_argument(
        '-m',
        '--memory_file_path',
        help="path of memory config, which saves the hardware memory config",
        default="",
        )
    
    argparser.add_argument(
        '-r',
        '--result_path',
        help="path of result file, which will save the outputs of the compiler",
        default="",
        )
        
    argparser.add_argument(
        '-l',
        '--log_level',
        help="log_level, options: info, warning, error, critical",
        default="CRITICAL",
    )

    argparser.add_argument(
        '-c',
        '--cut_method',
        help="image cut method, options: auto_cut, manual_cut",
        default="auto_cut",
    )

    argparser.add_argument(
        '-mcf',
        '--manual_cut_file',
        help="the image cut file path if choose manual_cut",
        default="",
    )

    argparser.add_argument(
        '-pc',
        '--process_cnt',
        help='process count',
        default=16,
    )

    argparser.add_argument(
        '-nc', 
        '--not_compress', 
        action='store_true', 
        dest='not_compress', 
        help='use the uncomressed weight.bin',
    )

    argparser.add_argument(
        '-ncf', 
        '--not_compress_fm', 
        action='store_true', 
        dest='not_compress_fm', 
        help='use the uncomressed datanode',
    )


    args = argparser.parse_args()
    main_(args)