from io import DEFAULT_BUFFER_SIZE
import os

def cmp(debug_case_dir_path, full_case_dir_path):
    debug_file_path_list = os.listdir(debug_case_dir_path)
    full_file_path_list = os.listdir(full_case_dir_path)
    compose_full_path(debug_case_dir_path, debug_file_path_list)
    compose_full_path(full_case_dir_path, full_file_path_list)
    debug_file_path_list.sort()
    full_file_path_list.sort()
    assert(len(debug_file_path_list) == len(full_file_path_list)), "# of files are different !"
    for i in range(len(debug_file_path_list)):
        f_debug = open(debug_file_path_list[i], "rb")
        f_case = open(debug_file_path_list[i], "rb")
        f_debug_size = os.path.getsize(debug_file_path_list[i])
        f_case_size = os.path.getsize(full_file_path_list[i])
        back_name = debug_file_path_list[i].split('/')[-1]
        if "weight" in back_name:
            # if(back_name == "weight_origin.bin"):
            f_size = f_debug_size
            assert(f_size <= f_case_size), "debug weight should less than full weight !"
            # else:
                # continue
        else:
            f_size = f_debug_size
            assert(f_size == f_case_size), "size of other files should be the same !"
        for i in range(f_size):
            debug_data = f_debug.read(1)
            case_data = f_case.read(1)
            assert(debug_data == case_data), "Not match in %s" % (back_name)
        print("%s has been checked !" % (back_name))
        f_debug.close()
        f_case.close()

def compose_full_path(dir_path, path_list):
    i = 0
    while(i < len(path_list)):
        if(path_list[i][-3:] != "bin"):
            del path_list[i]
        else:
            path_list[i] = os.path.join(dir_path, path_list[i])
            i += 1


if __name__ == "__main__":
    case_dir = "/data/zhangchenshuo/compiler_weight_debug_901/case"
    debug_dir = "/data/zhangchenshuo/compiler_weight_debug_901/bin_file/cut_2_test_weight_debug.bin"
    cmp(debug_case_dir_path=debug_dir, full_case_dir_path=case_dir)