# compiler

You can run the compiler tool by the command below

```python
python3 Compiler.py -o onnx_file_path -hw hw_config_file_path -s scale_file_path -m memory_file_path -r result_path -l log_level
```
