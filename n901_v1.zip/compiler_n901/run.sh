# # !/bin/bash

# echo "Parsing Input Param!"
# # onnx_file_path="/mnt/g/workspace/onnx_net/yolov3/update.onnx"
# # onnx_file_path="/mnt/c/opflow_case/models/yolov4_mix/update.onnx"
# # onnx_file_path="C:\Users\14062\Documents\GitHub\onnx_net\yolov4_mix\update.onnx"
# onnx_file_path="mnt/c/Users/14062/Documents/GitHub/onnx_net/yolov4_mix/update.onnx"
# # hw_config_file_path="/home/zhangchenshuo/compiler_n901/config/hardware.json"
# # hw_config_file_path="/mnt/c/Users/14062/Documents/GitHub/compiler_n901/config/hardware.json"
# hw_config_file_path="config\hardware.json"
# # scale_file_path="/mnt/g/workspace/onnx_net/yolov3/update_16_16.json"
# scale_file_path="/mnt/c/Users/14062/Documents/GitHub/onnx_net/yolov4_mix/testcases_yolov4_mix_8_8.json"
# # scale_file_path="C:\Users\14062\Documents\GitHub\onnx_net\yolov4_mix\tetcases_yolov4_mix_8_8.onnx"
# # memory_file_path="/home/zhangchenshuo/compiler_n901/config/memory.json"
# memory_file_path="/mnt/c/Users/14062/Documents/GitHub/compiler_n901/config/memory.json"
# # memory_file_path="C:\Users\14062\Documents\GitHub\compiler_n901\config\memory.json"
# # result_path="/mnt/g/workspace/bin_file_n901/yolov3.bin"
# result_path="/mnt/c/output/yolov4_8_8"
# # result_path="C:\output\yolov4_8_8"
# # cut_log_path="/mnt/g/workspace/cut_info_n901_4x4/yolov3_cutinfo.txt"
# log_level="INFO"
# process_cnt=32

# #run compiler
# echo "Running Compiler"
# python Compiler.py -o $onnx_file_path -hw $hw_config_file_path -s $scale_file_path -m $memory_file_path -r $result_path -l $log_level #> $cut_log_path # -c $cut_method -mcf $manual_cut_file
python3 Compiler.py -o '../onnx_net/yolov4_mix/update.onnx' -hw 'config/hardware.json' -s '../onnx_net/yolov4_mix/testcases_yolov4_mix_8_8.json' -m 'config/memory.json' -r '/mnt/c/output/n901_case_yolov4_8_8' -l INFO