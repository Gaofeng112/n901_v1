import json
import copy
from Middleend.GroupAssigner.node_group_def import NodeGroup
from Frontend.Node.node_def import NodeOpType


class get_chunk_from_file(object):

    def __init__(self, file_path):
        self.file_path = file_path
    
    def get_group(self, topo_sort, node_idx_list):
        group_info = {}
        with open(self.file_path, 'r+') as f:
            group_info = json.load(f)

        group_list = []
        idx_of_node_idx_list = 0
        for group_id in group_info.keys():
            newGroup = NodeGroup()
            group_st_ed_idx = node_idx_list[idx_of_node_idx_list]
            newGroup.type = group_info[group_id]['type']
            newGroup.st_idx = group_st_ed_idx[0]
            newGroup.ed_idx = group_st_ed_idx[1]
            newGroup.id = int(group_id)
            newGroup.chunk_num = group_info[group_id]['chunk_num']
            newGroup.input_shape = topo_sort[newGroup.st_idx].input_shape
            newGroup.shape = topo_sort[newGroup.ed_idx].shape
            self.get_node_list(newGroup, topo_sort, newGroup.st_idx, newGroup.ed_idx)
            if(newGroup.chunk_num == 1):
                self.get_input_output_chunk_one_chunk(newGroup)
            else:
                self.get_input_output_chunk(newGroup, group_info[group_id]['input_chunk'])
            group_list.append(newGroup)
            idx_of_node_idx_list += 1
        self.get_in_didma_group(group_list)
        self.get_parents(group_list)
        self.get_children(group_list)
        return group_list

    
    def get_node_list(self, group, topo_sort, st_idx, ed_idx):
        for i in range(st_idx, ed_idx + 1):
            curNode = topo_sort[i]
            group.node_list.append(curNode)
    
    def get_input_output_chunk_one_chunk(self, group):
        if(group.type != 'NPUType'):
            return
        for node in group.node_list:
            row_st, row_ed = 0, node.input_shape[0][2] - 1
            col_st, col_ed = 0, node.input_shape[0][3] - 1
            ch_st, ch_ed = 0, node.input_shape[0][1] - 1
            chunk_dict = {'row_st': row_st, 'row_ed': row_ed, 'col_st': col_st, 'col_ed': col_ed,
                        'ch_st': ch_st, 'ch_ed': ch_ed}
            group.input_chunk.append([chunk_dict])
            row_st_out, row_ed_out = 0, node.shape[2] - 1
            col_st_out, col_ed_out = 0, node.shape[3] - 1
            ch_st_out, ch_ed_out = 0, node.shape[1] - 1
            chunk_dict_out = {'row_st': row_st_out, 'row_ed': row_ed_out, 'col_st': col_st_out, 'col_ed': col_ed_out,
                                'ch_st': ch_st_out, 'ch_ed': ch_ed_out}
            group.output_chunk.append([chunk_dict_out])

    def get_input_output_chunk(self, group, input_chunk_first_node): ### According node list and chunk_num to calculate the input_chunk of the group
        if(group.type != 'NPUType'):
            return
        # for node_idx in range(group.st_idx, group.ed_idx + 1):
        for node_idx in range(len(group.node_list)):
            if(node_idx == 0):
                group.input_chunk.append(input_chunk_first_node)
                output_chunk_dict = self.get_ock(group, input_chunk_first_node, node_idx)
                group.output_chunk.append(output_chunk_dict)
            else:
                group.input_chunk.append(group.output_chunk[-1])
                output_chunk_dict = self.get_ock(group, group.input_chunk[-1], node_idx)
                group.output_chunk.append(output_chunk_dict)
                
    def get_ock(self, group, input_chunk_list, node_idx):
        curNode = group.node_list[node_idx]
        if(curNode.op_type == NodeOpType.HardwareFusionNode):
            subNodeList = curNode.sub_node_list
        else:
            subNodeList = [curNode]
        node_in_chunk_list = input_chunk_list
        node_out_chunk_list = []
        for subNode in subNodeList:
            if(subNode.op_type == NodeOpType.ConvNode or
                subNode.op_type == NodeOpType.MaxPoolNode or
                subNode.op_type == NodeOpType.AveragePoolNode):
                node_out_chunk_list = self.get_conv_pool_chunk(node_in_chunk_list, subNode)
            elif(subNode.op_type == NodeOpType.UpsampleNode):
                node_out_chunk_list = self.get_upsample_chunk(node_in_chunk_list, subNode)
            else:
                node_out_chunk_list = node_in_chunk_list
            node_in_chunk_list = node_out_chunk_list
        return node_out_chunk_list
    
    def get_conv_pool_chunk(self, in_chunk_list, node):
        param = []
        if(node.op_type == NodeOpType.ConvNode):
            param = node.conv_param
        elif(node.op_type == NodeOpType.MaxPoolNode):
            param = node.maxpool_param
        else:
            param = node.avgpool_param
        if(isinstance(param, dict)):
            kernelHeight, kernelWidth = param['kernel_shape'][0], param['kernel_shape'][1]
            pad_t, pad_b, pad_l, pad_r = param['pads'][0], param['pads'][2], param['pads'][1], param['pads'][3]
            stride_row, stride_col = param['strides'][0], param['strides'][1]
        else:
            kernelHeight, kernelWidth = param.kernel_shape[0], param.kernel_shape[1]
            pad_t, pad_b, pad_l, pad_r = param.pads[0], param.pads[2], param.pads[1], param.pads[3]
            stride_row, stride_col = param.strides[0], param.strides[1]

        chunk_list = []
        for i in range(len(in_chunk_list)):
            in_chunk_dict = in_chunk_list[i]
            ch_st_cur, ch_ed_cur = 0, node.shape[1] - 1
            col_st_cur, col_ed_cur = 0, node.shape[3] - 1
            row_st_pre, row_ed_pre = in_chunk_dict['row_st'], in_chunk_dict['row_ed']
            if(i == 0):
                row_st_cur = 0
            else:
                row_st_cur = (row_st_pre + pad_t) // stride_row

            if(i == 0):
                row_in = row_ed_pre - row_st_pre + pad_t + 1
            elif(i == len(in_chunk_list) - 1):
                row_in = row_ed_pre - row_st_pre + pad_b + 1
            else:
                row_in = row_ed_pre - row_st_pre + 1
            row_out = (row_in - kernelHeight) // stride_row + 1
            row_ed_cur = row_st_cur + row_out - 1
            out_chunk_dict = {'row_st': row_st_cur, 'row_ed': row_ed_cur, 'col_st': col_st_cur, 'col_ed': col_ed_cur,
                                'ch_st': ch_st_cur, 'ch_ed': ch_ed_cur}
            chunk_list.append(out_chunk_dict)
        return chunk_list
    
    def get_upsample_chunk(self, in_chunk_list, node):
        scale_up_row = node.Upsample_param.scales[2] / node.Upsample_param.scales[0]
        scale_up_col = node.Upsample_param.scales[3] / node.Upsample_param.scales[1]
        chunk_list = []
        for in_chunk_dict in in_chunk_list:
            ch_st_cur, ch_ed_cur = 0, node.shape[1]
            col_st_pre, col_ed_pre = in_chunk_dict['col_st'], in_chunk_dict['col_ed']
            row_st_pre, row_ed_pre = in_chunk_dict['row_st'], in_chunk_dict['row_ed']
            col_st_cur, col_ed_sur = col_st_pre * scale_up_col, col_ed_pre * scale_up_col + (scale_up_col - 1)
            row_st_cur, row_ed_cur = row_st_pre * scale_up_row, row_ed_pre * scale_up_col + (scale_up_row - 1)
            out_chunk_dict = {'row_st': row_st_cur, 'row_ed': row_ed_cur, 'col_st': col_st_cur, 'col_ed': col_ed_sur,
                                'ch_st': ch_st_cur, 'ch_ed': ch_ed_cur}
            chunk_list.append(out_chunk_dict)
        return chunk_list

    # def get_in_didma_group(self, group_list):
    #     for i in range(len(group_list)):
    #         for j in range(len(group_list[i].node_list)):
    #             curr_node = group_list[i].node_list[j]
    #             for m in range(len(curr_node.parents)):
    #                 parent_node = curr_node.parents[m]
    #                 for k in range(len(group_list)):
    #                     if self._check_node_in_group(parent_node, group_list[k]) == True:
    #                         if k != i:
    #                             group_list[i].in_didma_group_list.append(group_list[k])
    #                             break

    def get_in_didma_group(self, group_list):
        for group in group_list:
            for node in group.node_list:
                for parent_node in node.parents:
                    for check_group in group_list:
                        if(parent_node in check_group.node_list and check_group != group):
                            group.in_didma_group_list.append(check_group)

    # def get_parents(self, group_list):
    #     for i in range(len(group_list)):
    #         for j in range(len(group_list[i].node_list)):
    #             curr_node = group_list[i].node_list[j]
    #             for m in range(len(curr_node.parents)):
    #                 parent_node = curr_node.parents[m]
    #                 for k in range(len(group_list)):
    #                     if self._check_node_in_group(parent_node, group_list[k]) == True:
    #                         if k != i and (group_list[k] not in group_list[i].parents):
    #                             group_list[i].parents.append(group_list[k])
    #                             break
    def get_parents(self, group_list):
        for group in group_list:
            in_didma_list = group.in_didma_group_list
            for check_group in in_didma_list:
                if check_group not in group.parents:
                    group.parents.append(check_group)

    # def get_children(self, group_list):
    #     for i in range(len(group_list)):
    #         last_node = group_list[i].node_list[-1]
    #         for j in range(len(last_node.children)):
    #             child_node = last_node.children[j]
    #             for k in range(len(group_list)):
    #                 if self._check_node_in_group(child_node, group_list[k]) == True:
    #                     if k != i and (group_list[k] not in group_list[i].children):
    #                         group_list[i].children.append(group_list[k])
    #                         break
    
    def get_children(self, group_list):
        for group in group_list:
            for parent_group in group.parents:
                if(group not in parent_group.children):
                    parent_group.children.append(group)

    # def _check_node_in_group(self, node_in, node_group):
    #     check = False
    #     for node in node_group.node_list:
    #         if node.index == node_in.index:
    #             check = True
    #             break
    #     return check