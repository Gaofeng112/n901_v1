import json
from Frontend.Node.node_def import Node
from Frontend.Node.node_def import NodeOpType

class check_cut(object):
    def __init__(self, file_path):
        self.file_path = file_path
    
    def check(self, topo_sort):
        group_info = {}
        with open(self.file_path, 'r+') as f:
            group_info = json.load(f)
        node_idx = []
        for group_cnt in group_info.keys():
            group_type = group_info[group_cnt]['type']
            node_name_in_grp = group_info[group_cnt]['node_name']
            chunk_num  = group_info[group_cnt]['chunk_num']
            input_chunk = group_info[group_cnt]['input_chunk']
            self.check_group_type(group_type, node_name_in_grp, topo_sort)
            self.check_chunk_num(group_type, chunk_num, input_chunk)
            node_idx.append(self.check_node_seq_in_topo_sort(node_name_in_grp, topo_sort))

        # if(len(node_idx) > 1):
        #     for i in range(len(node_idx) - 1):
        #         assert(node_idx[i][-1] + 1== node_idx[i + 1][0]), 'Omit node between groups!'
        if(len(node_idx) > 1):
            for i in range(len(node_idx) - 1):
                for idx in range(node_idx[i][-1] + 1, node_idx[i + 1][0]):
                    assert(topo_sort[idx].op_type == NodeOpType.OutputNode or
                        topo_sort[idx].op_type == NodeOpType.InputNode), 'Omit node between groups!'

                
        node_idx_gross = [node_idx[0][0], node_idx[-1][-1]]
        for i in range(0, node_idx_gross[0]):
            assert(topo_sort[i].op_type.name == 'InputNode'), 'Omit node at the beginning of the graph!'
        for i in range(node_idx_gross[-1] + 1, len(topo_sort)):
            assert(topo_sort[i].op_type.name == 'OutputNode'), 'Omit node at the end of the graph!'
        return node_idx
    
    def check_group_type(self, group_type, node_name_in_grp, topo_sort):
        find_node_cnt = 0
        node_cnt = len(node_name_in_grp)
        for hw_node in topo_sort:
            # if(hw_node.op_type.name == 'HardwareFusionNode'):
            if(hw_node.op_type == NodeOpType.HardwareFusionNode):
                for sub_node in hw_node.sub_node_list:
                    if(sub_node.name in node_name_in_grp):
                        find_node_cnt += 1
                        assert(sub_node.type == group_type), "Group includes different type nodes!"
            else:
                if(hw_node.name in node_name_in_grp):
                    find_node_cnt += 1
                    assert(hw_node.type == group_type), "Group includes different type nodes!"
            if(find_node_cnt == node_cnt):
                break
    
    def check_chunk_num(self, group_type, chunk_num, input_chunk):
        if(group_type == 'NPUtype'):
            assert(chunk_num == len(input_chunk)), "Chunk num is wrong!"
    
    def check_node_seq_in_topo_sort(self, node_name_in_grp, topo_sort):
        node_cnt = len(node_name_in_grp)
        first_find_idx = -1
        idx_in_topo_sort = 0
        for hw_node in topo_sort:
            loop_stop = False
            # if(hw_node.op_type.name == 'HardwareFusionNode'):
            if(hw_node.op_type == NodeOpType.HardwareFusionNode):
                for sub_node in hw_node.sub_node_list:
                    if(sub_node.name == node_name_in_grp[0]):
                        first_find_idx = idx_in_topo_sort
                        loop_stop = True
                        break
            else:
                if(hw_node.name == node_name_in_grp[0]):
                    first_find_idx = idx_in_topo_sort
                    loop_stop = True
            if(loop_stop):
                break
            idx_in_topo_sort += 1
        assert(first_find_idx != -1), "Not find node in topo_sort!"
        for node_name in node_name_in_grp:
            hw_node = topo_sort[idx_in_topo_sort]
            # if(hw_node.op_type.name == 'HardwareFusionNode'):
            if(hw_node.op_type == NodeOpType.HardwareFusionNode):
                assert(hw_node.sub_node_list[0].name == node_name), 'Not find node in topo_sort!'
            else:
                assert(hw_node.name == node_name), 'Not find node in topo_sort!'
            idx_in_topo_sort += 1
        last_find_idx = idx_in_topo_sort - 1
        return [first_find_idx, last_find_idx]
                        