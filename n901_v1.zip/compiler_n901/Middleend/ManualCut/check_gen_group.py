from Middleend.GroupAssigner.node_group_def import NodeGroup

class check_gen_group(object):
    def __init__(self):
        pass
    def check(self, auto_group_list, manual_group_list):
        assert(len(auto_group_list) == len(manual_group_list)), 'Group length is different!'
        for i in range(len(auto_group_list)):
            auto_group = auto_group_list[i]
            manual_group = manual_group_list[i]
            assert(auto_group.type == manual_group.type), 'Different Group type! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            assert(auto_group.id == manual_group.id), 'Different Group id! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            assert(auto_group.st_idx == manual_group.st_idx), 'Different Group st_idx! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            assert(auto_group.ed_idx == manual_group.ed_idx), 'Different Group ed_idx! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            assert(auto_group.chunk_num == manual_group.chunk_num), 'Different Group chunk_num! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            assert(auto_group.input_shape == manual_group.input_shape), 'Different Group input shape! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            assert(auto_group.shape == manual_group.shape), 'Different Group shape! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            # assert(auto_group.node_list == manual_group.node_list), 'Different Group node list! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            assert(len(auto_group.node_list) == len(manual_group.node_list)), 'Different Group node list length! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            for j in range(len(auto_group.node_list)):
                assert(auto_group.node_list[j].index == manual_group.node_list[j].index), 'Different Node! auto Group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            assert(auto_group.input_chunk == manual_group.input_chunk), 'Different Group input_chunk! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            assert(auto_group.output_chunk == manual_group.output_chunk), 'Different Group output_chunk! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            # assert(auto_group.in_didma_group_list == manual_group.in_didma_group_list), 'Different Group didma in list! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            # assert(auto_group.parents == manual_group.parents), 'Different Group parents! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            # assert(auto_group.children == manual_group.children), 'Different Group children! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            
            auto_didma_id_list = []
            manual_didma_id_list = []
            for in_didma_group in auto_group.in_didma_group_list:
                auto_didma_id_list.append(in_didma_group.id)
            for in_didma_group in manual_group.in_didma_group_list:
                manual_didma_id_list.append(in_didma_group.id)
            assert(auto_didma_id_list == manual_didma_id_list), \
                'Different Group didma in list! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)
            
            auto_parents_id_list = []
            manual_parents_id_list = []
            for parent_group in auto_group.parents:
                auto_parents_id_list.append(parent_group.id)
            for parent_group in manual_group.parents:
                manual_parents_id_list.append(parent_group.id)
            assert(auto_parents_id_list == manual_parents_id_list), \
                'Different Group parents list! auto group id: {}; manual group id: {}'.format(auto_group.id, manual_group.id)