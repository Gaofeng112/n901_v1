import json
from Frontend.Node.node_def import Node
from Frontend.Node.node_def import NodeOpType

class get_group_image_cut_file(object):
    def __init__(self, file_path):
        self.file_path = file_path
    
    def get_file(self, assigned_grp):
        group_info = {}
        for group in assigned_grp:
            group_info[group.id] = {}
            group_info[group.id].update({'type': group.type})
            node_name_list = []
            for hw_node in group.node_list:
                if hw_node.op_type == NodeOpType.HardwareFusionNode:
                    node_name_list.append(hw_node.sub_node_list[0].name)
                else:
                    node_name_list.append(hw_node.name)
            group_info[group.id].update({'node_name': node_name_list})
            # first_input_chunk = group.input_chunk[0]
            first_input_chunk = []
            # if(group.input_chunk):
            #     first_input_chunk.append(group.input_chunk[0])
            if(group.input_chunk):
                first_input_chunk = group.input_chunk[0]
            group_info[group.id].update({'input_chunk': first_input_chunk})
            group_info[group.id].update({'chunk_num': group.chunk_num})
        
        with open(self.file_path, 'w+') as f:
            json.dump(group_info, f, indent=4)
