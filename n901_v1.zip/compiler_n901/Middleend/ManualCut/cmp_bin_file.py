import os

class cmp_bin_file(object):
    def __init__(self, auto_folder_path, manual_folder_path):
        self.auto_folder_path = auto_folder_path
        self.manual_folder_path = manual_folder_path
    
    def cmp(self):
        auto_file_path_list = os.listdir(self.auto_folder_path)
        manual_file_path_list = os.listdir(self.manual_folder_path)
        for name in auto_file_path_list:
            if('.bin' not in name):
                auto_file_path_list.remove(name)
                break
        for name in manual_file_path_list:
            if('.bin' not in name):
                manual_file_path_list.remove(name)
                break
        for i in range(len(auto_file_path_list)):
            auto_file_path_list[i] = os.path.join(self.auto_folder_path, auto_file_path_list[i])
        for i in range(len(manual_file_path_list)):
            manual_file_path_list[i] = os.path.join(self.manual_folder_path, manual_file_path_list[i])
        assert(len(auto_file_path_list) == len(manual_file_path_list)), 'Different file #!'
        for i in range(len(auto_file_path_list)):
            auto_file_path = auto_file_path_list[i]
            manual_file_path = manual_file_path_list[i]
            auto_binfile = open(auto_file_path, 'rb')
            manual_binfile = open(manual_file_path, 'rb')
            auto_size = os.path.getsize(auto_file_path)
            manual_size = os.path.getsize(manual_file_path)
            assert(auto_size == manual_size), "ERROR: {} and {} has different file size!".format(auto_file_path, manual_file_path)
            for j in range(auto_size):
                auto_bin_data = auto_binfile.read(1)
                manual_bin_data = manual_binfile.read(1)
                # assert(auto_bin_data == manual_bin_data), "ERROR, {} and {} is not same at {}!".format(auto_file_path, manual_file_path, j)
                if(auto_bin_data != manual_bin_data):
                    print("{} and {} is not same at {}!".format(auto_file_path, manual_file_path, j))
            print(manual_file_path, 'has been checked!')
            auto_binfile.close()
            manual_binfile.close()
        # print("Congratulations! All the bin biles are matched :)")

if __name__ == '__main__':
    # auto_bin_path = "/home/zhangchenshuo/bin_file/auto_cut/verify_net_auto_uncompress/"
    # manual_bin_path = "/home/zhangchenshuo/bin_file/manual_cut/verify_net_manual_uncompress/"
    # auto_bin_path = "/home/zhangchenshuo/bin_file/auto_cut/verify_net_auto_compress/"
    # manual_bin_path = "/home/zhangchenshuo/bin_file/manual_cut/verify_net_manual_compress/"
    # auto_bin_path = "/home/zhangchenshuo/bin_file/auto_cut/cut7_4_auto_compress/"
    # manual_bin_path = "/home/zhangchenshuo/bin_file/manual_cut/cut7_4_manual_compress/"
    # auto_bin_path = "/home/zhangchenshuo/bin_file/auto_cut/cut7_4_auto_uncompress/"
    # manual_bin_path = "/home/zhangchenshuo/bin_file/manual_cut/cut7_4_manual_uncompress/"
    # auto_bin_path = "/home/zhangchenshuo/bin_file/auto_cut/cut2_test_auto_uncompress/"
    # manual_bin_path = "/home/zhangchenshuo/bin_file/manual_cut/cut2_test_manual_uncompress/"
    # auto_bin_path = "/home/zhangchenshuo/bin_file/auto_cut/cut2_test_auto_compress/"
    # manual_bin_path = "/home/zhangchenshuo/bin_file/manual_cut/cut2_test_manual_compress/"
    # auto_bin_path = "/home/zhangchenshuo/opflow_case/case_yolov3_416_no_fuse_1.onnx/case/"
    # manual_bin_path = "/home/zhangchenshuo/bin_file_v1/auto_bin_file/result_yolov3_416_no_fuse_1_auto_compress.bin/"
    auto_bin_path = "/data/zhangchenshuo/bin_file/auto_cut/yolov3_auto_uncompress/"
    manual_bin_path = "/data/zhangchenshuo/bin_file/manual_cut/yolov3_manual_uncompress/"
    cmp_bin_file(auto_bin_path, manual_bin_path).cmp()
