from Frontend.Node.node_def import NodeOpType
from Frontend.Node.node_def import NodeOpType
from Middleend.GroupAssigner.node_group_toolbox import NodeGroupToolbox

import math
import pdb

class ImageCut(object):
    def __init__(self):
        pass

    def image_cut(self, group_list):
        for group in group_list:
            if group.type == 'NPUType':
                chunk_num = group.chunk_num
                if chunk_num == 1:
                    self._get_one_chunks(group)
                else:
                    ## get transmit direction of this group
                    trans_direct = NodeGroupToolbox().get_node_list_trans_direct(group.node_list)
                    if trans_direct == 'foreward':
                        ## transmit from input to output
                        self._get_foreward_chunks(group)
                    else:
                        ## transmit from output to input
                        self._get_backward_chunks(group)
        # NodeGroupToolbox().display_node_groups(group_list)
        # NodeGroupToolbox().display_hf_bw(group_list)
        # pdb.set_trace()

    def _get_one_chunks(self, group):
        # both are list of lists of dicts
        input_chunks = []
        output_chunks = []
        # list of dicts of output chunks for the last node, for initiate of input chunks
        for i in range(len(group.node_list)):
            # get row chunks from the last node to the first node
            curr_node = group.node_list[i]
            ## get input chunk of node
            ch_st_in, ch_ed_in = 0, curr_node.input_shape[0][1] - 1
            col_st_in, col_ed_in = 0, curr_node.input_shape[0][3] - 1
            row_st_in, row_ed_in = 0, curr_node.input_shape[0][2] - 1
            in_chunk_dict = {'row_st': row_st_in, 'row_ed': row_ed_in,
                'col_st': col_st_in, 'col_ed': col_ed_in,
                'ch_st': ch_st_in, 'ch_ed': ch_ed_in}
            ## get output chunk of node
            ch_st_out, ch_ed_out = 0, curr_node.shape[1] - 1
            col_st_out, col_ed_out = 0, curr_node.shape[3] - 1
            row_st_out, row_ed_out = 0, curr_node.shape[2] - 1
            out_chunk_dict = {'row_st': row_st_out, 'row_ed': row_ed_out,
                'col_st': col_st_out, 'col_ed': col_ed_out,
                'ch_st': ch_st_out, 'ch_ed': ch_ed_out}
            input_chunks.append([in_chunk_dict])
            output_chunks.append([out_chunk_dict])
        # get input and output chunks
        group.get_input_chunks(input_chunks)
        group.get_output_chunks(output_chunks)

    def _get_foreward_chunks(self, group):
        # both are list of lists of dicts
        input_chunks = []
        output_chunks = []
        node_list = group.node_list
        # list of dicts of output chunks for the last node, for initiate of input chunks
        node_in_chunks = self._get_group_in_chunks(group)               
        for i in range(len(node_list)):
            # get row chunks from the last node to the first node
            curr_node = node_list[i]
            node_out_chunks = self._get_out_chunks(curr_node, node_in_chunks)
            input_chunks.append(node_in_chunks)
            output_chunks.append(node_out_chunks)
            node_in_chunks = node_out_chunks
        # get input and output chunks
        group.get_input_chunks(input_chunks)
        group.get_output_chunks(output_chunks)

    def _get_group_in_chunks(self, group):
        node_in_chunks = []
        ch_st, ch_ed = 0, group.input_shape[0][1] - 1
        col_st, col_ed = 0, group.input_shape[0][3] - 1
        row_in = group.input_shape[0][2]
        chunk_num = group.chunk_num
        for i in range(chunk_num):
            row_st = i * math.ceil(row_in/chunk_num)
            # input row num of current part
            if i == chunk_num - 1:
                in_part_row = math.ceil(row_in/chunk_num)
            else:
                in_part_row = row_in - (chunk_num - 1) * math.ceil(row_in/chunk_num)
            row_ed = row_st + in_part_row - 1
            in_chunk_dict = {'row_st': row_st, 'row_ed': row_ed,
                'col_st': col_st, 'col_ed': col_ed,
                'ch_st': ch_st, 'ch_ed': ch_ed}
            node_in_chunks.append(in_chunk_dict)
        return node_in_chunks

    def _get_out_chunks(self, node, node_in_chunks):
        # get output row chunks from input row chunks for one (hf) node
        if node.op_type == NodeOpType.HardwareFusionNode:
            for i in range(len(node.sub_node_list)):
                sub_node = node.sub_node_list[i]
                node_out_chunks = self._get_sub_node_out_chunks(sub_node, node_in_chunks)
                node_in_chunks = node_out_chunks
        else:
            node_out_chunks = self._get_sub_node_out_chunks(node, node_in_chunks)
        return node_out_chunks

    def _get_sub_node_out_chunks(self, node, node_in_chunks):
        ## get output row chunks from input row chunks for one calculation node
        ## hardware fusion node will be decomposed to single calculation node for this function
        if node.op_type == NodeOpType.UpsampleNode:
            node_out_chunks = self._get_foreward_node_out_chunks(node, node_in_chunks)
        else:
            node_out_chunks = node_in_chunks
        return node_out_chunks
        
    def _get_foreward_node_out_chunks(self, node, node_in_chunks):
        ## upsample node
        chunk_num = len(node_in_chunks)
        for i in range(chunk_num):
            row_st_in = node_in_chunks[i]['row_st']
            row_ed_in = node_in_chunks[i]['row_ed']
            row_in = row_ed_in - row_st_in + 1
            # get output chunk
            col_st_out, col_ed_out = 0, node.shape[3] - 1
            ch_st_out, ch_ed_out = 0, node.shape[1] - 1
            row_st_out = row_st_in * 2
            row_ed_out = (row_ed_in + 1) * 2 - 1
            out_chunk_dict = {'row_st': row_st_out, 'row_ed': row_ed_out,
                'col_st': col_st_out, 'col_ed': col_ed_out,
                'ch_st': ch_st_out, 'ch_ed': ch_ed_out}
            node_in_chunks.append(out_chunk_dict)

    def _get_backward_chunks(self, group):
        # both are list of lists of dicts
        input_chunks = []
        output_chunks = []
        node_list = group.node_list
        # list of dicts of output chunks for the last node, for initiate of input chunks
        node_out_chunks = self._get_group_out_chunks(group)             
        for i in range(len(node_list)):
            # get row chunks from the last node to the first node
            i_inv = len(node_list) - 1 - i
            curr_node = node_list[i_inv]
            node_in_chunks = self._get_in_chunks(curr_node, node_out_chunks)
            input_chunks.insert(0, node_in_chunks)
            output_chunks.insert(0, node_out_chunks)
            node_out_chunks = node_in_chunks
        # get input and output chunks'
        group.get_input_chunks(input_chunks)
        group.get_output_chunks(output_chunks)

    def _get_group_out_chunks(self, group):
        node_out_chunks = []
        ch_st, ch_ed = 0, group.shape[1] - 1
        col_st, col_ed = 0, group.shape[3] - 1
        row_out = group.shape[2]
        chunk_num = group.chunk_num
        index = row_out % chunk_num
        for i in range(chunk_num):
            # row_st = i * math.floor(row_out/chunk_num)
            # output row num of current part
            # if i == chunk_num - 1:
            #     out_part_row = row_out - (chunk_num - 1) * math.ceil(row_out/chunk_num)
            # else:
            #     out_part_row = math.ceil(row_out/chunk_num)
            if i < chunk_num - index:
                row_st = i * math.floor(row_out/chunk_num)
                out_part_row = math.floor(row_out/chunk_num)
            else:
                row_st = (chunk_num-index) * math.floor(row_out/chunk_num) + (i -(chunk_num-index)) * math.ceil(row_out/chunk_num)
                out_part_row = math.ceil(row_out/chunk_num)
            row_ed = row_st + out_part_row - 1
            out_chunk_dict = {'row_st': row_st, 'row_ed': row_ed,
                'col_st': col_st, 'col_ed': col_ed,
                'ch_st': ch_st, 'ch_ed': ch_ed}
            node_out_chunks.append(out_chunk_dict)
        return node_out_chunks

    def _get_in_chunks(self, node, node_out_chunks):
        # get input row chunks from output row chunks for one (hf) node
        if node.op_type == NodeOpType.HardwareFusionNode:
            for i in range(len(node.sub_node_list)):
                i_inv = len(node.sub_node_list) - 1 - i
                sub_node = node.sub_node_list[i_inv]
                node_in_chunks = self._get_sub_node_in_chunks(sub_node, node_out_chunks)
                node_out_chunks = node_in_chunks
        else:
            node_in_chunks = self._get_sub_node_in_chunks(node, node_out_chunks)
        return node_in_chunks

    def _get_sub_node_in_chunks(self, node, node_out_chunks):
        # get input row chunks from output row chunks for one calculation node
        # hardware fusion node will be decomposed to single calculation node for this function
        if (node.op_type == NodeOpType.ConvNode
            or node.op_type == NodeOpType.MaxPoolNode.MaxPoolNode
            or node.op_type == NodeOpType.AveragePoolNode):
            node_in_chunks = self._get_backward_node_in_chunks(node, node_out_chunks)
        else: #relu, batch norm .etc
            node_in_chunks = node_out_chunks
        # print('++++++++++')
        # print(node.op_type)
        # print(node_out_chunks)
        # print(node_in_chunks)
        # print('++++++++++')
        return node_in_chunks

    def _get_backward_node_in_chunks(self, node, node_out_chunks):
        chunk_num = len(node_out_chunks)
        if node.op_type == NodeOpType.ConvNode:
            param = node.conv_param
        elif node.op_type == NodeOpType.MaxPoolNode:
            param = node.maxpool_param
        else:
            param = node.avgpool_param
        node_in_chunks = []
        waste_row = param['kernel_shape'][0] \
            - param['strides'][0]
        for i in range(chunk_num):
            row_st_out = node_out_chunks[i]['row_st']
            row_ed_out = node_out_chunks[i]['row_ed']
            row_out = row_ed_out - row_st_out + 1
            row_in = (row_out - 1) * param['strides'][0] \
                + param['kernel_shape'][0]
            # get input chunk
            col_st_in, col_ed_in = 0, node.input_shape[0][3] - 1
            ch_st_in, ch_ed_in = 0, node.input_shape[0][1] - 1
            ## get row_st_in
            if i == 0:
                row_st_in = 0
            else:
                row_st_in = row_st_out * param['strides'][0] \
                    - param['pads'][0]
            ## get row_ed_in
            if i == 0 and i == chunk_num - 1:
                row_ed_in = node.input_shape[0][2] - 1
            elif i == 0:
                row_ed_in = row_in - param['pads'][0] - 1
            elif i == chunk_num - 1:
                row_ed_in = node.input_shape[0][2] - 1
            else:
                row_ed_in = row_st_in + row_in - 1
            if len(node.input_shape) == 1:
                max_row = node.input_shape[0][2]
                if row_ed_in > max_row - 1:
                    row_ed_in = max_row - 1
            in_chunk_dict = {'row_st': row_st_in, 'row_ed': row_ed_in,
                'col_st': col_st_in, 'col_ed': col_ed_in,
                'ch_st': ch_st_in, 'ch_ed': ch_ed_in}
            node_in_chunks.append(in_chunk_dict)
        return node_in_chunks
