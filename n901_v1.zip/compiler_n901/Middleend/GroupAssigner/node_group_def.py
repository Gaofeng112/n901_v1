class NodeGroup(object):
    def __init__(self):
        #input nodes not included !!
        # CPU Node can be included
        # only one type
        self.type = ''
        self.st_idx = 0 #start index in toposort
        self.ed_idx = 0 #end index in toposort
        self.id = 0
        self.in_didma_group_list = []
        self.parents = []
        self.children = []
        self.chunk_num = 1
        self.shape = []
        self.input_shape = []
        self.input_chunk = [] #list of list of dictionaries which contains chunk information
        self.output_chunk = [] #list of list of dictionaries which contains chunk information
        self.node_list = [] 
        self.chunk_num_list = []
        self.avgpool_flag = False
    def init_type(self, type_in):
        if type_in == 'NPUType':
            self.type = 'NPUType'
        elif type_in == 'CPUType':
            self.type = 'CPUType'
        else:
            print('Not supported type %s !' % type_in)


    def get_input_chunks(self, dict_list_list):
        # dict['row_st'] = row_st
        # dict['row_ed'] = row_ed
        # dict['col_st'] = col_st
        # dict['col_ed'] = col_ed
        # dict['ch_st'] = ch_st
        # dict['ch_ed'] = ch_ed
        self.input_chunk = dict_list_list

    def get_output_chunks(self, dict_list_list):
        # dict['row_st'] = row_st
        # dict['row_ed'] = row_ed
        # dict['col_st'] = col_st
        # dict['col_ed'] = col_ed
        # dict['ch_st'] = ch_st
        # dict['ch_ed'] = ch_ed
        self.output_chunk = dict_list_list
