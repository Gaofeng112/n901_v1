from .node_group_def import NodeGroup
from Frontend.Node.node_def import NodeOpType
from Frontend.HWToolBox.N900HWToolBox import N900HWToolBox
from Middleend.GroupAssigner.node_group_toolbox import NodeGroupToolbox

import math
import pdb


class GroupAssigner(object):
    def __init__(self):
        self.group_list = []
     
    def assigner(self, node_list_in, debug_mode):
        node_list_len = len(node_list_in)
        # a flag when it is True, a new group need to be instantiated
        new_group = True
        curr_id = 0
        # traverse all nodes in node_list_in
        if (debug_mode):
            for i in range(len(node_list_in)):
                curr_node = node_list_in[i]
                if(curr_node.op_type == NodeOpType.InputNode or curr_node.op_type == NodeOpType.OutputNode):
                    new_group = True
                    i += 1
                else:
                    if (new_group):
                        node_group = NodeGroupToolbox().init_new_group(curr_node, i, curr_id)
                        curr_id += 1
                    NodeGroupToolbox().extend_group(node_group, curr_node, i)
                    if node_group.type == 'NPUType':
                        node_group.chunk_num = NodeGroupToolbox().get_chunk_num(node_group.node_list)
                    NodeGroupToolbox().end_node_group(curr_node, node_group, self.group_list, i)
        else:
            for i in range(node_list_len):
                curr_node = node_list_in[i]
                # print(i, curr_node.op_type)   
                if (curr_node.op_type == NodeOpType.InputNode
                    or curr_node.op_type == NodeOpType.OutputNode):
                    new_group = True
                else:
                    #instantiate a new node_group if flag is True
                    if new_group == True:
                        node_group = NodeGroupToolbox().init_new_group(curr_node, i, curr_id)
                        curr_id += 1
                        new_group = False
                    #append curr_node to node_list
                    NodeGroupToolbox().extend_group(node_group, curr_node, i)
                    if node_group.type == 'NPUType':
                        node_group.chunk_num = NodeGroupToolbox().get_chunk_num(node_group.node_list)
                    # under these case, a node_group is ended and a new one is needed for next node
                    if i == node_list_len - 1:
                        NodeGroupToolbox().end_node_group(curr_node, node_group, self.group_list, i)
                    else:
                        next_node = node_list_in[i+1]
                        if (next_node.op_type == NodeOpType.ConvNode
                            and 'avgpool_flag' in next_node.conv_param
                            and next_node.conv_param['avgpool_flag']):
                            if node_group.type == 'NPUType':
                                node_group.chunk_num = NodeGroupToolbox().get_chunk_num(node_group.node_list)
                            NodeGroupToolbox().end_node_group(curr_node, node_group, self.group_list, i)
                            new_group = True
                        if (curr_node.op_type == NodeOpType.ConvNode
                            and 'avgpool_flag' in curr_node.conv_param
                            and curr_node.conv_param['avgpool_flag']):
                            node_group.chunk_num = NodeGroupToolbox().get_chunk_num(node_group.node_list)
                            NodeGroupToolbox().end_node_group(curr_node, node_group, self.group_list, i)
                            node_group.avgpool_flag = True
                            new_group = True
                        if (next_node.type != node_group.type #different type
                            or next_node.op_type == NodeOpType.InputNode
                            or len(curr_node.children) != 1 ##no children or more than one children
                            or (next_node not in curr_node.children)): 
                            NodeGroupToolbox().end_node_group(curr_node, node_group, self.group_list, i)
                            new_group = True
                        elif (node_group.type == 'NPUType' 
                            and next_node.type == 'NPUType'):
                            st = node_group.st_idx
                            ed = node_group.ed_idx
                            ## if the wasted row num is not more than 8, waste_check_pass = True
                            waste_check_pass = NodeGroupToolbox().waste_check(node_list_in[st: ed + 2])
                            ## if the transmit direction feature of the next node is differe from current node group direction_check_pass = False
                            trans_direct_check_pass \
                                = NodeGroupToolbox().transmit_direction_check(node_list_in[st: ed + 2])
                            if waste_check_pass == False or trans_direct_check_pass == False:
                                NodeGroupToolbox().end_node_group(curr_node, node_group, self.group_list, i)
                                new_group = True
        # reference between node groups
        #get input didma group list
        NodeGroupToolbox().get_in_didma_group_list(self.group_list)
        #get parents
        NodeGroupToolbox().get_group_parents(self.group_list)
        # get children
        NodeGroupToolbox().get_group_child(self.group_list)
        return self.group_list


                
        
