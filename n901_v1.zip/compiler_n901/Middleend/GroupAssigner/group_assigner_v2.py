from ast import NodeTransformer
from http.client import EXPECTATION_FAILED
from .node_group_def import NodeGroup
from Frontend.Node.node_def import NodeOpType
from Frontend.HWToolBox.N900HWToolBox import N900HWToolBox
from Middleend.GroupAssigner.node_group_toolbox import NodeGroupToolbox
import pdb
import math

class GroupAssigner(object):
    def __init__(self):
        self.group_list = []
    
    def assigner(self, node_list_in, debug_mode):
        node_list_len = len(node_list_in)
        new_group = True
        curr_id = 0
        i = 0
        # debug_mode = False
        if (debug_mode):
            for i in range(len(node_list_in)):
                curr_node = node_list_in[i]
                if(curr_node.op_type == NodeOpType.InputNode or curr_node.op_type == NodeOpType.OutputNode):
                    new_group = True
                    i += 1
                else:
                    if (new_group):
                        node_group = NodeGroupToolbox().init_new_group(curr_node, i, curr_id)
                        curr_id += 1
                    NodeGroupToolbox().extend_group(node_group, curr_node, i)
                    if node_group.type == 'NPUType':
                        node_group.chunk_num = NodeGroupToolbox().get_chunk_num(node_group.node_list)
                    NodeGroupToolbox().end_node_group(node_group, self.group_list, i)
               
        else:
            while(i < node_list_len):
                curr_node = node_list_in[i]
                ## input node and output node are excluded during group assignment
                if (curr_node.op_type == NodeOpType.InputNode or curr_node.op_type == NodeOpType.OutputNode):
                    new_group = True
                    i += 1
                else:
                    ## initial a new group
                    if(new_group):
                        node_group = NodeGroupToolbox().init_new_group(curr_node, i, curr_id)
                        curr_id += 1
                        new_group = False
                    NodeGroupToolbox().extend_group(node_group, curr_node, i)
                    if node_group.type == 'CPUType':
                        NodeGroupToolbox().end_node_group(node_group, self.group_list, i)
                        new_group = True
                        i += 1
                    # if curr_node.name == "hardwarefusion_10":
                    #     pdb.set_trace()
                    if node_group.type == 'NPUType':
                        node_group.chunk_num = NodeGroupToolbox().get_chunk_num(node_group.node_list)
                        # node_group.chunk_num_list.append(NodeGroupToolbox().get_chunk_num(node_group.node_list))
                        # node_group.chunk_num_list.append(node_group.node_list)
                        # node_group.chunk_num = max(node_group.chunk_num_list)
                    ## curr_node is the start of a legal branch
                    # if branch_len := NodeGroupToolbox().check_branch(curr_node):
                        # st_idx = node_group.st_idx
                        # if node_group.node_list[-1].name == "model_add_2_add":
                        #     pdb.set_trace()
                    branch_len =NodeGroupToolbox().check_branch(curr_node)
                    if node_group.type == 'NPUType':
                        if branch_len != 0:
                            st_idx = node_group.st_idx
                            ed_idx = node_group.ed_idx + branch_len
                            waste_check_pass = NodeGroupToolbox().waste_check(node_list_in[st_idx: ed_idx + 1])
                            trans_direct_check_pass = NodeGroupToolbox().transmit_direction_check(node_list_in[st_idx: ed_idx + 1], tailLen=branch_len)
                            ## branch will be seperate from curr_node
                            if(waste_check_pass == False or trans_direct_check_pass == False):
                                NodeGroupToolbox().end_node_group(node_group, self.group_list, i)
                                i += 1
                                new_group = True
                            ## branch could put in this group, the right chain is extended first, the left_node is left for the next check 
                            else:
                                j = ed_idx
                                for k in range(i + 1, ed_idx):
                                    NodeGroupToolbox().extend_group(node_group, node_list_in[k], k)
                                i = j
                        ## curr_node is not the start of a legal branch
                        else:
                            ## curr node is the end node
                            if i == node_list_len - 1:
                                NodeGroupToolbox().end_node_group(node_group, self.group_list, i)
                                i += 1
                            ## other cases:
                            else:
                                next_node = node_list_in[i + 1]
                                if (next_node.op_type == NodeOpType.ConvNode
                                and 'avgpool_flag' in next_node.conv_param
                                and next_node.conv_param['avgpool_flag']):
                                    if node_group.type == 'NPUType':
                                        node_group.chunk_num = NodeGroupToolbox().get_chunk_num(node_group.node_list)
                                    NodeGroupToolbox().end_node_group(node_group, self.group_list, i)
                                    new_group = True
                                if (curr_node.op_type == NodeOpType.ConvNode
                                    and 'avgpool_flag' in curr_node.conv_param
                                    and curr_node.conv_param['avgpool_flag']):
                                    node_group.chunk_num = NodeGroupToolbox().get_chunk_num(node_group.node_list)
                                    NodeGroupToolbox().end_node_group(node_group, self.group_list, i)
                                    node_group.avgpool_flag = True
                                    new_group = True
                                if(next_node.type != node_group.type ## different type
                                    or next_node.op_type == NodeOpType.InputNode ## next is a InputNode
                                    or len(curr_node.children) != 1 ## no children or more than one children
                                    or (next_node not in curr_node.children)): ## next node is not the children of current node
                                        NodeGroupToolbox().end_node_group(node_group, self.group_list, i)
                                        new_group = True
                                elif(node_group.type == 'NPUType' and next_node.type == 'NPUType'):
                                    st_idx = node_group.st_idx
                                    ed_idx = node_group.ed_idx
                                    waste_check_pass = NodeGroupToolbox().waste_check(node_list_in[st_idx: ed_idx + 2])
                                    ## if the transmit direction feature of the next node is differe from current node group direction_check_pass = False
                                    trans_direct_check_pass = NodeGroupToolbox().transmit_direction_check(node_list_in[st_idx: ed_idx + 2])
                                    if waste_check_pass == False or trans_direct_check_pass == False:
                                        NodeGroupToolbox().end_node_group(node_group, self.group_list, i)
                                        new_group = True
                                i += 1
        #get input didma group list
        NodeGroupToolbox().get_in_didma_group_list(self.group_list)
        #get parents
        NodeGroupToolbox().get_group_parents(self.group_list)
        # get children
        NodeGroupToolbox().get_group_child(self.group_list)
        # NodeGroupToolbox().display_node_groups(self.group_list)
        return self.group_list
    
    def visit_group(self):
        for grp in self.group_list:
            for sub_node in grp.node_list:
                if(sub_node.op_type == NodeOpType.HardwareFusionNode):
                    for node in sub_node.sub_node_list:
                        print(node.name, end=" ")
                else:
                    print(sub_node.name, end=" ")
            print("\n")

