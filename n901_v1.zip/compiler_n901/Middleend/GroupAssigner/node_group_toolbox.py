import chunk
import math

from Frontend.Node.node_def import NodeOpType
from Middleend.GroupAssigner.node_group_def import NodeGroup
from Frontend.HWToolBox.N900HWToolBox import N900HWToolBox

import pdb
import logging
class NodeGroupToolbox(object):
    def __init__(self):
        pass

#############################################
## for group operation
#############################################
    def init_new_group(self, curr_node, st, curr_id):
        node_group = NodeGroup()
        node_group.init_type(curr_node.type)
        node_group.input_shape = curr_node.input_shape
        node_group.st_idx = st
        node_group.id = curr_id
        return node_group

    def extend_group(self, node_group, curr_node, ed):
        node_group.node_list.append(curr_node)
        node_group.ed_idx = ed

    # def end_node_group(self, curr_node, node_group, group_list, ed):
    #     node_group.ed_idx = ed
    #     node_group.shape = curr_node.shape
    #     group_list.append(node_group)

    def end_node_group(self, node_group, group_list, ed):
        '''
            end current group
        '''
        node_group.ed_idx = ed
        node_group.shape = node_group.node_list[-1].shape
        group_list.append(node_group)
#############################################
## for getting chunk_num
#############################################
    def get_chunk_num(self, sub_node_list):
        ## get transmit direction
        trans_direct = self.get_node_list_trans_direct(sub_node_list)
        ## get chunk_num
        if trans_direct == 'one_chunk':
            chunk_num = 1
        elif trans_direct == 'foreward':
            chunk_num = self._get_fore_chunk_num(sub_node_list)
        else:
            chunk_num = self._get_back_chunk_num(sub_node_list)
        return chunk_num

    def _check_branch_back_overflow(self, endNode, row_out_chunked, input_bw, output_bw):
        node_list = []
        row_out_chunked_list = []
        [p1, p2] = endNode.parents
        currNode = None
        startNode = None
        if(len(p1.children) == 2):
            currNode = p2
            startNode = p1
        else:
            currNode = p1
            startNode = p2
        assert(len(currNode.children) == 1 and len(startNode.children) == 2)
        branchLen = 1
        node_list = []
        while(currNode != startNode):
            branchLen += 1
            node_list.append(currNode)
            currNode = currNode.parents[0]
        # if endNode.name == "model_add_2_add":
        #     pdb.set_trace()
        if(endNode.op_type == NodeOpType.HardwareFusionNode):
            [SramOffset, check_pass, row_out_chunked] = self._check_hf_back_overflow(endNode, row_out_chunked, input_bw, output_bw, sramOffset = 0, getOffset = True)
        else:
            [SramOffset, check_pass, row_out_chunked] = self._check_sub_node_back_overflow(endNode, row_out_chunked, True, True, input_bw, output_bw, sramOffset = 0, getOffset = True)
        if(check_pass == False):
            return branchLen, check_pass, row_out_chunked
        for i in range(len(node_list)):
            currNode = node_list[i]
            idx = len(node_list) - 1 - i
            row_out_chunked_list.append(row_out_chunked)
            if(idx % 2 == 0):
                if(currNode.op_type == NodeOpType.HardwareFusionNode):
                    [check_pass, row_out_chunked] = self._check_hf_back_overflow(currNode, row_out_chunked, input_bw, output_bw)
                else:
                    [check_pass, row_out_chunked] = self._check_sub_node_back_overflow(currNode, row_out_chunked, True, True, input_bw, output_bw)
            else:
                if(currNode.op_type == NodeOpType.HardwareFusionNode):
                    [check_pass, row_out_chunked] = self._check_hf_back_overflow(currNode, row_out_chunked, input_bw, output_bw, sramOffset=SramOffset)
                else:
                    [check_pass, row_out_chunked] = self._check_sub_node_back_overflow(currNode, row_out_chunked, True, True, input_bw, output_bw, sramOffset=SramOffset)
            if(check_pass == False):
                return branchLen, check_pass, row_out_chunked
        if(check_pass):
            row_check = row_out_chunked
            if(endNode.op_type == NodeOpType.HardwareFusionNode):
                [SramOffset, check_pass, _] = self._check_hf_back_overflow(endNode, row_check,input_bw, output_bw, sramOffset = 0, getOffset = True)
            else:
                [SramOffset, check_pass, _] = self._check_sub_node_back_overflow(endNode, row_check, True, True, input_bw, output_bw, sramOffset = 0, getOffset = True)
            if(not check_pass):
                return branchLen, check_pass, row_out_chunked
            for i in range(len(node_list)):
                currNode = node_list[i]
                idx = len(node_list) - 1 - i
                if(i == 0):
                    row_check = row_out_chunked
                else:
                    row_check = row_out_chunked_list[i]
                if(idx % 2 == 0):
                    if(currNode.op_type == NodeOpType.HardwareFusionNode):
                        [check_pass, _] = self._check_hf_back_overflow(currNode, row_check, input_bw, output_bw)
                    else:
                        [check_pass, _] = self._check_sub_node_back_overflow(currNode, row_check, True, True, input_bw, output_bw)
                else:
                    if(currNode.op_type == NodeOpType.HardwareFusionNode):
                        [check_pass, _] = self._check_hf_back_overflow(currNode, row_check, input_bw, output_bw, sramOffset=SramOffset)
                    else:
                        [check_pass, _] = self._check_sub_node_back_overflow(currNode, row_check, True, True, input_bw, output_bw, sramOffset=SramOffset)
                if(check_pass == False):
                    return branchLen, check_pass, row_out_chunked
        return branchLen, check_pass, row_out_chunked
    
    def _get_back_chunk_num(self, sub_node_list):
        chunk_num = 0
        check_pass = False
        while (check_pass==False):
            check_pass = True
            chunk_num += 1
            row_out_chunked = math.ceil(sub_node_list[-1].shape[2] / chunk_num)
            i = len(sub_node_list) - 1
            while(i >= 0):
                curr_node = sub_node_list[i]
                input_bw = curr_node.hardware_info['input_bitwidth']
                output_bw = curr_node.hardware_info['output_bitwidth']
                assert(len(curr_node.parents) <= 2)
                if(len(curr_node.parents) == 2 and (self.check_branch(curr_node.parents[0]) or self.check_branch(curr_node.parents[1]))):
                    cnt, check_pass, row_out_chunked = self._check_branch_back_overflow(curr_node, row_out_chunked, input_bw, output_bw)
                    i -= cnt
                elif(curr_node.op_type == NodeOpType.HardwareFusionNode):
                    check_pass, row_out_chunked = self._check_hf_back_overflow(curr_node, row_out_chunked, input_bw, output_bw)
                    i -= 1
                else:
                    check_pass, row_out_chunked = self._check_sub_node_back_overflow(curr_node, row_out_chunked, True, True, input_bw, output_bw)
                    i -= 1
                if(check_pass == False):
                    break
        return chunk_num
    def _check_res(self, node, node_list):
        if len(node.children) != 2:
            return 0
        [child1, child2] = node.children

        if (node not in node_list):
            return 0
        ## If is not the case that one child has a parent and the other one has two, return false
        if (not(len(child1.parents) == 2 and len(child2.parents) == 1)) and (not(len(child1.parents) == 1 and len(child2.parents) == 2)):
            return 0
        if(len(child1.parents) == 1 and len(child2.parents) == 2):
            left_node = child2
            right_node = child1
        else:
            left_node = child1
            right_node = child2
        currNode = right_node
        branch_len = 0
        while(True):
            branch_len += 1
            if(currNode == left_node):
                break
            elif(len(currNode.children) != 1):
                branch_len = 0
                break
            currNode = currNode.children[0]
        return branch_len
    # def _get_back_chunk_num(self, sub_node_list):
    #     chunk_num = 0
    #     check_pass = False
    #     while check_pass == False:
    #         check_pass = True
    #         chunk_num += 1
    #         row_out_chunked \
    #             = math.ceil(sub_node_list[-1].shape[2] / chunk_num)
    #         for i in range(len(sub_node_list)):
    #             i_inv = len(sub_node_list) - 1 - i
    #             curr_node = sub_node_list[i_inv]
    #             # print('name', curr_node.name, 'chunk_num', chunk_num)
    #             input_bw = curr_node.hardware_info['input_bitwidth']
    #             output_bw = curr_node.hardware_info['output_bitwidth']
    #             if curr_node.op_type == NodeOpType.HardwareFusionNode:
    #                 check_pass, row_out_chunked \
    #                     = self._check_hf_back_overflow(curr_node, row_out_chunked, input_bw, output_bw)
    #                 if check_pass == False:
    #                     break
    #             else:
    #                 check_pass, row_out_chunked \
    #                     = self._check_sub_node_back_overflow(curr_node, row_out_chunked, True, True, input_bw, output_bw)
    #                 if check_pass == False:
    #                     break
    #     return chunk_num
    def _check_hf_back_overflow(self, node, row_chunked, input_bw, output_bw, sramOffset = 0, getOffset = False):
        check_pass = True
        for i in range(len(node.sub_node_list) - 1, -1, -1):
            from_sram, to_sram = False, False
            if(i == len(node.sub_node_list) - 1):
                to_sram = True
            if(i == 0):
                from_sram = True
            sub_node = node.sub_node_list[i]
            checkRes \
                = self._check_sub_node_back_overflow(sub_node, row_chunked, from_sram, to_sram, input_bw, output_bw, sramOffset, getOffset)
            if(getOffset):
                [offset, check_pass, row_chunked] = checkRes
            else:
                [check_pass, row_chunked] = checkRes
            if check_pass == False:
                break
        if(getOffset):
            return [offset, check_pass, row_chunked]
        return [check_pass, row_chunked]
    # def _check_hf_back_overflow(self, node, row_chunked, input_bw, output_bw, sramOffset = 0, getOffset = False):
    #     check_pass = True
    #     for i in range(len(node.sub_node_list)):
    #         i_inv = len(node.sub_node_list) - 1 - i
    #         from_sram, to_sram = False, False
    #         if i_inv == 0:
    #             from_sram = True
    #         if i_inv == len(node.sub_node_list) - 1:
    #             to_sram = True
    #         sub_node = node.sub_node_list[i_inv]
    #         check_pass, row_chunked \
    #             = self._check_sub_node_back_overflow(sub_node, row_chunked, \
    #                 from_sram, to_sram, input_bw, output_bw, sramOffset, getOffset)
    #         if check_pass == False:
    #             break
    #     return check_pass, row_chunked
    def _check_sub_node_back_overflow(self, curr_node, row_chunked, from_sram, to_sram, input_bw, output_bw, sramOffset=0, getOffset=False):
        if curr_node.op_type == NodeOpType.ConvNode:
            checkRes = self._check_conv_overflow(curr_node, row_chunked, input_bw, output_bw,
                direct_to_sram=to_sram, sramOffset=sramOffset, getOffset=getOffset)
        elif (curr_node.op_type == NodeOpType.MaxPoolNode
            or curr_node.op_type == NodeOpType.AveragePoolNode):
            checkRes = self._check_pool_overflow(curr_node, row_chunked, input_bw, output_bw,
                direct_from_sram=from_sram, direct_to_sram=to_sram, sramOffset=sramOffset, getOffset=getOffset)
        elif curr_node.op_type == NodeOpType.UpsampleNode:
            checkRes = self._check_upsample_overflow(curr_node, row_chunked, input_bw, output_bw,
                direct_to_sram=to_sram, sramOffset=sramOffset, getOffset=getOffset)
        elif curr_node.op_type == NodeOpType.AddNode:
            checkRes = self._check_add_overflow(curr_node, row_chunked, input_bw, output_bw,
                direct_to_sram=to_sram, sramOffset=sramOffset, getOffset=getOffset)
        elif (curr_node.op_type == NodeOpType.BatchNormalizationNode
            or curr_node.op_type == NodeOpType.NormalReluNode
            or curr_node.op_type == NodeOpType.LeakyReluNode
            or curr_node.op_type == NodeOpType.PReluNode
            or curr_node.op_type == NodeOpType.ClipNode
            or curr_node.op_type == NodeOpType.SiluNode
            or curr_node.op_type == NodeOpType.MishNode
            or curr_node.op_type == NodeOpType.BypassNode
            or curr_node.op_type == NodeOpType.TruncaterNode):
            checkRes = self._check_bn_or_relu_or_lut_overflow(curr_node, row_chunked, input_bw, output_bw,
                direct_from_sram=from_sram, direct_to_sram=to_sram, sramOffset=sramOffset, getOffset=getOffset)
        else:
            logging.error('Error! not supportted node !')
            logging.error(curr_node.op_type)
            return
        if(getOffset):
            [check_pass, row_chunked, offset] = checkRes
        else:
            [check_pass, row_chunked] = checkRes
        if(getOffset):
            return [offset, check_pass, row_chunked]
        return [check_pass, row_chunked]

    # def _check_sub_node_back_overflow(self, curr_node, row_chunked, from_sram, to_sram, input_bw, output_bw, sramOffset=0, getOffset=False):
    #     if curr_node.op_type == NodeOpType.ConvNode:
    #         checkRes = self._check_conv_overflow(curr_node, \
    #             row_chunked, input_bw, output_bw, direct_to_sram=to_sram, sramOffset=sramOffset, getOffset=getOffset)
    #     elif (curr_node.op_type == NodeOpType.MaxPoolNode
    #         or curr_node.op_type == NodeOpType.AveragePoolNode):
    #         check_pass, row_chunked = self._check_pool_overflow(curr_node, row_chunked, \
    #             input_bw, output_bw, \
    #             direct_from_sram=from_sram, direct_to_sram=to_sram)
    #     elif curr_node.op_type == NodeOpType.UpsampleNode:
    #         check_pass, row_chunked = self._check_upsample_overflow(curr_node, row_chunked, \
    #             input_bw, output_bw, \
    #             direct_to_sram=to_sram)
    #     elif curr_node.op_type == NodeOpType.AddNode:
    #         check_pass = self._check_add_overflow(curr_node, row_chunked, input_bw, output_bw, 
    #             direct_to_sram=to_sram)
    #     elif (curr_node.op_type == NodeOpType.BatchNormalizationNode
    #         or curr_node.op_type == NodeOpType.NormalReluNode
    #         or curr_node.op_type == NodeOpType.LeakyReluNode
    #         or curr_node.op_type == NodeOpType.PReluNode
    #         or curr_node.op_type == NodeOpType.ClipNode
    #         or curr_node.op_type == NodeOpType.SiluNode
    #         or curr_node.op_type == NodeOpType.MishNode
    #         or curr_node.op_type == NodeOpType.BypassNode):
    #         check_pass = self._check_bn_or_relu_overflow(curr_node, row_chunked, input_bw, output_bw, 
    #             direct_from_sram=from_sram, direct_to_sram=to_sram)
    #     else:
    #         print('Error! not supportted node !')
    #         print(curr_node.op_type)
    #         return
    #     return check_pass, row_chunked
    def _get_fore_chunk_num(self, sub_node_list):
        chunk_num = 0
        check_pass = False
        while check_pass == False:
            check_pass = True
            chunk_num += 1
            row_in_chunked = math.ceil(sub_node_list[0].input_shape[0][2] / chunk_num)
            # for curr_node in sub_node_list:
            i = 0
            while(i < len(sub_node_list)):
                curr_node = sub_node_list[i]
                input_bw = sub_node_list[0].hardware_info['input_bitwidth']
                output_bw = sub_node_list[-1].hardware_info['output_bitwidth']
                assert(len(curr_node.children) <= 2), "More children branches!"
                ## curr_node is the start of a branch and the branch is in the group
                if(len(curr_node.children) == 2 and i != len(sub_node_list) - 1 and self.check_branch(curr_node)):
                    cnt, check_pass, row_in_chunked = self._check_branch_fore_overflow(curr_node, row_in_chunked, input_bw, output_bw)
                    i += cnt
                ## curr_node is a hardwarefusion node
                elif(curr_node.op_type == NodeOpType.HardwareFusionNode):
                    check_pass, row_in_chunked = self._check_hf_fore_overflow(curr_node, row_in_chunked, input_bw, output_bw)
                    i += 1
                ## curr_node is a single node
                else:
                    check_pass, row_in_chunked = self._check_sub_node_fore_overflow(curr_node, row_in_chunked, True, True, input_bw, output_bw)
                    i += 1
                if check_pass == False:
                    break
        return chunk_num
    # def _get_fore_chunk_num(self, sub_node_list):
    #     chunk_num = 0
    #     check_pass = False
    #     while check_pass == False:
    #         check_pass = True
    #         chunk_num += 1
    #         row_in_chunked \
    #             = math.ceil(sub_node_list[0].input_shape[0][2] / chunk_num)
    #         for i in range(len(sub_node_list)):
    #             curr_node = sub_node_list[i]
    #             input_bw = sub_node_list[0].hardware_info['input_bitwidth']
    #             output_bw = sub_node_list[-1].hardware_info['output_bitwidth']
    #             if curr_node.op_type == NodeOpType.HardwareFusionNode:
    #                 check_pass, row_in_chunked \
    #                     = self._check_hf_fore_overflow(curr_node, row_in_chunked, input_bw, output_bw)
    #                 if check_pass == False:
    #                     break
    #             else:
    #                 check_pass, row_in_chunked \
    #                     = self._check_sub_node_fore_overflow(curr_node, row_in_chunked, True, True, input_bw, output_bw)
    #                 if check_pass == False:
    #                     break
    #     return chunk_num
    def _check_branch_fore_overflow(self, startNode, row_in_chunked, input_bw, output_bw):
        [child1, child2] = startNode.children
        leftNode = None
        rightNode = None
        if(len(child1.parents) == 2):
            leftNode = child1
            rightNode = child2
        elif(len(child2.parents) == 2):
            leftNode = child2
            rightNode = child1
        assert(leftNode and rightNode), "Not find the end node of the branch!"
        assert(len(rightNode.parents) == 1), "More than one parents of the start node of the right chain!"
        node_list = []  ## only contains the right chain (not contain the startNode and leftNode)
        currNode = rightNode
        branchLen = 1 ## the length of the branch (include the leftNode, not include the startNode)
        while(currNode != leftNode):
            branchLen += 1
            node_list.append(currNode)
            currNode = currNode.children[0]
        ## the startNode decided the sramOffset
        if(startNode.op_type == NodeOpType.HardwareFusionNode):
            [SramOffset, check_pass, row_in_chunked] = self._check_hf_fore_overflow(startNode, row_in_chunked, input_bw, output_bw, sramOffset=0, getOffset=True)
        else:
            [SramOffset, check_pass, row_in_chunked] = self._check_sub_node_fore_overflow(startNode, row_in_chunked, True, True, input_bw, output_bw,sramOffset=0, getOffset=True)
        if(check_pass == False):
            return branchLen, check_pass, row_in_chunked
        for i in range(len(node_list)):
            currNode = node_list[i]
            if(i % 2 == 0):
                if(currNode.op_type == NodeOpType.HardwareFusionNode):
                    [check_pass, row_in_chunked] = self._check_hf_fore_overflow(currNode, row_in_chunked, input_bw, output_bw)
                else:
                    [check_pass, row_in_chunked] = self._check_sub_node_fore_overflow(currNode, row_in_chunked, True, True, input_bw, output_bw)
            else:
                if(currNode.op_type == NodeOpType.HardwareFusionNode):
                    [check_pass, row_in_chunked] = self._check_hf_fore_overflow(currNode, row_in_chunked, input_bw, output_bw, sramOffset=SramOffset)
                else:
                    [check_pass, row_in_chunked] = self._check_sub_node_fore_overflow(currNode, row_in_chunked, True, True, input_bw, output_bw, sramOffset=SramOffset)
            if(check_pass == False):
                return branchLen, check_pass, row_in_chunked
        if(leftNode.op_type == NodeOpType.HardwareFusionNode):
            [check_pass, row_in_chunked] = self._check_hf_fore_overflow(currNode, row_in_chunked, input_bw, output_bw)
        else:
            [check_pass, row_in_chunked] = self._check_sub_node_fore_overflow(currNode, row_in_chunked, True, True, input_bw, output_bw)
        return branchLen, check_pass, row_in_chunked

    def _check_hf_fore_overflow(self, node, row_chunked, input_bw, output_bw):
        check_pass = True
        for i in range(len(node.sub_node_list)):
            from_sram, to_sram = False, False
            if i == 0:
                from_sram = True
            if i == len(node.sub_node_list) - 1:
                to_sram = True
            sub_node = node.sub_node_list[i]
            check_pass, row_chunked \
                = self._check_sub_node_fore_overflow(sub_node, row_chunked, \
                    from_sram, to_sram, input_bw, output_bw)
            if check_pass == False:
                break
        return check_pass, row_chunked

    def _check_sub_node_fore_overflow(self, curr_node, row_chunked, from_sram, to_sram, input_bw, output_bw, sramOffset=0, getOffset=False):
        if curr_node.op_type == NodeOpType.UpsampleNode:
            checkRes = self._check_upsample_overflow(curr_node, row_chunked, \
                input_bw, output_bw, \
                direct_to_sram=to_sram, sramOffset=sramOffset, getOffset=getOffset)
        elif curr_node.op_type == NodeOpType.AddNode:
            checkRes= self._check_add_overflow(curr_node, row_chunked, \
                input_bw, output_bw, \
                direct_to_sram=to_sram, sramOffset=sramOffset, getOffset=getOffset)
        elif (curr_node.op_type == NodeOpType.BatchNormalizationNode
            or curr_node.op_type == NodeOpType.NormalReluNode
            or curr_node.op_type == NodeOpType.LeakyReluNode
            or curr_node.op_type == NodeOpType.PReluNode
            or curr_node.op_type == NodeOpType.ClipNode
            or curr_node.op_type == NodeOpType.MishNode
            or curr_node.op_type == NodeOpType.SiluNode):
            checkRes = self._check_bn_or_relu_or_lut_overflow(curr_node, row_chunked, \
                input_bw, output_bw, \
                direct_from_sram=from_sram, direct_to_sram=to_sram, sramOffset=sramOffset, getOffset=getOffset)
        else:
            print('Error! not supportted node !')
            print(curr_node.op_type)
            return
        if(getOffset):
            if(curr_node.op_type == NodeOpType.UpsampleNode):
                [check_pass, row_chunked, offset] = checkRes
            else:
                [check_pass, offset] = checkRes
        else:
            if(curr_node.op_type == NodeOpType.UpsampleNode):
                [check_pass, row_chunked] = checkRes
            else:
                [check_pass] = checkRes
        if(getOffset):
            return [offset, check_pass, row_chunked]
        return [check_pass, row_chunked]
    
    def _check_conv_overflow(self, node, row_chunked, input_bw, output_bw, direct_to_sram=True, sramOffset = 0, getOffset = False):
        ch_in, row_in, col_in = node.input_shape[0][1:4]
        ch_out, row_out, col_out = node.shape[1:4]
        kernel_h, kernel_w = node.conv_param["kernel_shape"][0:2]
        stride = node.conv_param['strides'][0]
        psum_enable = 1
        if(kernel_h <= 3 and kernel_w <=3 and 'group' in node.conv_param.keys()
           and node.conv_param['group'] != 1):
            psum_enable = 0
        check_pass = True
        row_out_chunked = row_chunked
        if(row_out_chunked == row_out):
            row_in_chunked = row_in
        else:
            row_in_chunked = (row_out_chunked - 1) * stride + kernel_h
        ch_list, row_list, col_list = [ch_in], [row_in_chunked], [col_in]
        if(ch_in > 4):
            in_checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '32ch', input_bw, getOffset)
        else:
            in_checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '4ch', input_bw, getOffset)
        if(getOffset):
            [offset, check] = in_checkRes
        else:
            [check] =  in_checkRes
        if not check:
            check_pass = False
        psum_ch = 32
        out_check = True
        ch_list, row_list, col_list = [ch_out], [row_out_chunked], [col_out]
        if(psum_enable):
            ch_list.append(psum_ch)
            col_list.append(col_out)
            row_list.append(row_out_chunked)
            ch_list.append(ch_in)
            col_list.append(col_in)
            row_list.append(row_in_chunked)
            out_checkRes = self._check_sram_overflow_psum(ch_list, row_list, col_list, sramOffset, 2047, kernel_h, output_bw)
            [check] = out_checkRes
            if not check:
                check_pass = False
        elif(direct_to_sram==True):
            out_checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '32ch', output_bw, getOffset)
            if(getOffset):
                [offset, check] = out_checkRes
            else:
                [check] =  out_checkRes
            if not check:
                check_pass = False
        if(getOffset):
            return [check_pass, row_in_chunked, offset]
        return [check_pass, row_in_chunked]
    
    # def _check_conv_overflow(self, node, row_chunked, input_bw, output_bw, direct_to_sram=True, sramOffset=0, getOffset=False):
    #     ch_in, row_in, col_in = node.input_shape[0][1:4] # input shape
    #     ch_out, row_out, col_out = node.shape[1:4] # output chape
    #     kernel_h, kernel_w = node.conv_param["kernel_shape"][0:2]
    #     stride = node.conv_param['strides'][0]
        
    #     psum_enable = 1
    #     if(kernel_h <= 3 and kernel_w <= 3 and 'group' in node.conv_param.keys()
    #         and node.conv_param['group'] != 1):
    #         psum_enable = 0
        
    #     check_pass = True
    #     row_out_chunked = row_chunked
    #     if(row_out_chunked == row_out):
    #         row_in_chunked = row_in
    #     else:
    #         row_in_chunked = (row_out_chunked - 1) * stride + kernel_h
    #     ch_list, row_list, col_list = [ch_in], [row_in_chunked], [col_in]
    #     if(ch_in > 4):
    #         in_check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '32ch', input_bw)
    #     else:
    #         in_check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '4ch', input_bw)
    #     if not in_check:
    #         return in_check, row_in_chunked
    #     psum_ch = 32
    #     out_check = True
    #     ch_list, row_list, col_list = [ch_out], [row_out_chunked], [col_out]
    #     if(psum_enable):
    #         ch_list.append(psum_ch)
    #         col_list.append(col_out)
    #         row_list.append(row_out_chunked)
    #         ch_list.append(ch_in)
    #         col_list.append(col_in)
    #         row_list.append(row_in_chunked)
    #         out_check = self._check_sram_overflow_psum(ch_list, row_list, col_list, 0, 2047, kernel_h, output_bw)
    #     elif(direct_to_sram==True):
    #         out_check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '32ch', output_bw)
    #     if not out_check:
    #         return out_check, row_in_chunked
    #     return check_pass, row_in_chunked

    def _check_pool_overflow(self, node, row_chunked, input_bw, output_bw, direct_from_sram=True, direct_to_sram=True, sramOffset=0, getOffset=False):
        ch_in, row_in, col_in = node.input_shape[0][1:4]
        ch_out, row_out, col_out = node.shape[1:4]
        if node.op_type == NodeOpType.MaxPoolNode:
            param = node.maxpool_param
        elif node.op_type == NodeOpType.AveragePoolNode:
            param = node.avgpool_param
        else:
            print("Error! Not supported pool mode!")
        check_pass = True
        row_out_chunked = row_chunked
        if row_out_chunked == row_out:
            row_in_chunked = row_in
        else:
            row_in_chunked = (row_out_chunked - 1) * param['strides'][0] \
            + param['kernel_shape'][0]
        if (direct_from_sram==True):
            ch_list, row_list, col_list = [ch_in], [row_in_chunked], [col_in]
            if (ch_in > 4):
                checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '32ch', input_bw, getOffset)
            else:
                checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '4ch', input_bw, getOffset)
            if(getOffset):
                [offset, check] = checkRes
            else:
                [check] = checkRes
            if not check:
                check_pass = False
        if (direct_to_sram==True):
            ch_list, row_list, col_list = [ch_out], [row_out_chunked], [col_out]
            checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '32ch', output_bw, getOffset)
            if(getOffset):
                [offset, check] = checkRes
            else:
                [check] = checkRes
            if not check:
                check_pass = False
        if(getOffset):
            return [check_pass, row_in_chunked, offset]
        return [check_pass, row_in_chunked]
    
    # def _check_pool_overflow(self, node, row_chunked, input_bw, output_bw, direct_from_sram=True, direct_to_sram=True):
    #     # direct_from_sram means data derectly from sram (without conv)
    #     # input shape
    #     ch_in, row_in, col_in = node.input_shape[0][1:4]
    #     # output shape
    #     ch_out, row_out, col_out = node.shape[1:4]
    #     ## get param
    #     if node.op_type == NodeOpType.MaxPoolNode:
    #         param = node.maxpool_param
    #     elif node.op_type == NodeOpType.AveragePoolNode:
    #         param = node.avgpool_param
    #     else:
    #         print('Error! Not supported pool mode!')
    #     ## check overflow
    #     check_pass = True
    #     row_out_chunked = row_chunked
    #     if row_out_chunked == row_out:
    #         row_in_chunked = row_in
    #     else:
    #         row_in_chunked = (row_out_chunked - 1) * param['strides'][0] \
    #             + param['kernel_shape'][0]
    #     ## check input sram
    #     if direct_from_sram == True:
    #         ch_list, row_list, col_list = [ch_in], [row_in_chunked], [col_in]
    #         if ch_in > 4:
    #             check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '32ch', input_bw)
    #         else:
    #             check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '4ch', input_bw)
    #         if not check:
    #             check_pass = False
    #     ## check output sram
    #     if direct_to_sram == True:
    #         ch_list, row_list, col_list = [ch_out], [row_out_chunked], [col_out]
    #         check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '32ch', output_bw)
    #         if not check:
    #             check_pass = False
    #     return check_pass, row_in_chunked
    def _check_upsample_overflow(self, node, row_chunked, input_bw, output_bw, direct_to_sram=True, sramOffset=0, getOffset=False):
        ch_in, row_in, col_in = node.input_shape[0][1:4]
        ch_out, row_out, col_out = node.shape[1:4]
        check_pass = True
        row_in_chunked = row_chunked
        row_out_chunked = 2 * row_in_chunked
        ch_list, row_list, col_list = [ch_in], [row_in_chunked], [col_in]
        if (ch_in > 4):
            checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '32ch', input_bw, getOffset)
        else:
            checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '4ch', input_bw, getOffset)
        if(getOffset):
            [offset, check] = checkRes
        else:
            [check] =  checkRes
        if (not check):
            check_pass = False
        if (direct_to_sram==True):
            ch_list, row_list, col_list = [ch_out], [row_out_chunked], [col_out]
            checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '32ch', output_bw, getOffset)
            if(getOffset):
                [offset, check] = checkRes
            else:
                [check] = checkRes
            if (not check):
                check_pass = False
        if(getOffset):
            return [check_pass, row_in_chunked, offset]
        return [check_pass, row_out_chunked]
    # def _check_upsample_overflow(self, node, row_chunked, input_bw, output_bw, direct_to_sram=True):
    #     # input shape
    #     ch_in, row_in, col_in = node.input_shape[0][1:4]
    #     # output shape
    #     ch_out, row_out, col_out = node.shape[1:4]
    #     ## check overflow
    #     check_pass = True
    #     row_in_chunked = row_chunked
    #     row_out_chunked = 2 * row_in_chunked
    #     # check input sram
    #     ch_list, row_list, col_list = [ch_in], [row_in_chunked], [col_in]
    #     if ch_in > 4:
    #         check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '32ch', input_bw)
    #     else:
    #         check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '4ch', input_bw)
    #     if not check:
    #         check_pass = False
    #     # check output sram
    #     if direct_to_sram == True:
    #         ch_list, row_list, col_list = [ch_out], [row_out_chunked], [col_out]
    #         check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '32ch', output_bw)
    #         if not check:
    #             check_pass = False
    #     return check_pass, row_out_chunked
    def _check_add_overflow(self, node, row_chunked, input_bw, output_bw, direct_to_sram=True, sramOffset=0, getOffset=True):
        ch_in, row_in, col_in = node.input_shape[0][1:4]
        ch_out, row_out, col_out = node.shape[1:4]
        is_didma_add = N900HWToolBox().is_DIDMA_Add(node)
        check_pass = True
        ch_list, row_list, col_list = [], [], []
        if (is_didma_add==True):
            ch_list.append(ch_in)
            row_list.append(row_chunked)
            col_list.append(col_in)
        else:
            for j in range(2):
                ch_list.append(ch_in)
                row_list.append(row_chunked)
                col_list.append(col_in)
        if (ch_in > 4):
            in_checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '32ch', input_bw, getOffset)
        else:
            in_checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '4ch', input_bw, getOffset)
        if(getOffset):
            [offset, check] = in_checkRes
        else:
            [check] =  in_checkRes
        if not check:
            check_pass = False
        if (direct_to_sram==True):
            out_checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '32ch', output_bw, getOffset)
            if(getOffset):
                [check] = [out_checkRes[1]]
            else:
                [check] =  out_checkRes
            if not check:
                check_pass = False
        if (getOffset):
            return [check_pass, row_chunked, offset]
        return [check_pass, row_chunked]
    # def _check_add_overflow(self, node, row_chunked, input_bw, output_bw, direct_to_sram=True): 
    #     ##  two function didma overflow check(one input data) and elementwise overflow check(two input data)
    #     # input shape
    #     ch_in, row_in, col_in = node.input_shape[0][1:4]
    #     # output shape
    #     ch_out, row_out, col_out = node.shape[1:4]
    #     ## check if it is didma add
    #     is_didma_add = N900HWToolBox().is_DIDMA_Add(node)
    #     ## check overflow
    #     check_pass = True
    #     ch_list, row_list, col_list = [], [], []
    #     if is_didma_add == True:
    #         ch_list.append(ch_in)
    #         row_list.append(row_chunked)
    #         col_list.append(col_in)
    #     else: # didma add
    #         for j in range(2):
    #             ch_list.append(ch_in)
    #             row_list.append(row_chunked)
    #             col_list.append(col_in)
    #     ## check input sram
    #     if ch_in > 4:
    #         check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '32ch', input_bw)
    #     else:
    #         check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '4ch', input_bw)
    #     if not check:
    #         check_pass = False
    #     if direct_to_sram == True:
    #         # check output sram
    #         check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '32ch', output_bw)
    #         if not check:
    #             check_pass = False
    #     return check_pass
    def _check_bn_or_relu_or_lut_overflow(self, node, row_chunked, input_bw, output_bw, direct_from_sram=True, direct_to_sram=True, sramOffset=0, getOffset=False):
        ch_in, row_in, col_in = node.input_shape[0][1:4]
        ch_out, row_out, col_out = node.shape[1:4]
        check_pass = True
        ch_list, row_list, col_list = [ch_in], [row_chunked], [col_in]
        if (direct_from_sram==True):
            if (ch_in > 4):
                checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '32ch', input_bw, getOffset)
            else:
                checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '4ch', input_bw, getOffset)
            if(getOffset):
                [offset, check] = checkRes
            else:
                [check] =  checkRes
            if not check:
                check_pass = False
        if (direct_to_sram==True):
            checkRes = self._check_sram_overflow(ch_list, row_list, col_list, sramOffset, 2047, '32ch', output_bw, getOffset)
            if(getOffset):
                [offset, check] = checkRes
            else:
                [check] =  checkRes
            if (not check):
                check_pass = False
        if(getOffset):
            return [check_pass, row_chunked, offset]
        return [check_pass, row_chunked]
    # def _check_bn_or_relu_overflow(self, node, row_chunked, input_bw, output_bw, direct_from_sram=True, direct_to_sram=True):
    #     # input shape
    #     ch_in, row_in, col_in = node.input_shape[0][1:4]
    #     # output shape
    #     ch_out, row_out, col_out = node.shape[1:4]
    #     ## check overflow
    #     check_pass = True
    #     ch_list, row_list, col_list = [ch_in], [row_chunked], [col_in]
    #     ## check input sram
    #     if direct_from_sram == True:
    #         if ch_in > 4:
    #             check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '32ch', input_bw)
    #         else:
    #             check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '4ch', input_bw)
    #         if not check:
    #             check_pass = False
    #     ## check output sram
    #     if direct_to_sram == True:
    #         check = self._check_sram_overflow(ch_list, row_list, col_list, 0, 2047, '32ch', output_bw)
    #         if not check:
    #             check_pass = False
    #     return check_pass

#############################################
## for transmit direction check
#############################################
    def transmit_direction_check(self, sub_node_list, tailLen = 1):
        check_pass = False
        ## check transmit direction
        list_len = int(len(sub_node_list))
        curr_trans_direct = self.get_node_list_trans_direct(sub_node_list[0: list_len - tailLen])
        next_trans_direct = self.get_node_list_trans_direct(sub_node_list[list_len - tailLen:])
        chunk_num_curr = self.get_chunk_num(sub_node_list[0: list_len - tailLen])
        chunk_num_next = self.get_chunk_num(sub_node_list[list_len - tailLen:])
        ## if chunk num of backward and foreward node are both 1, check pass
        if (curr_trans_direct == 'None' or next_trans_direct == 'None'
            or curr_trans_direct == next_trans_direct):
            check_pass = True
        elif ([curr_trans_direct, next_trans_direct] == ['backward', 'foreward']
            or [curr_trans_direct, next_trans_direct] == ['foreward', 'backward']):
            if chunk_num_curr == 1 and chunk_num_next == 1:
                check_pass = True
        elif curr_trans_direct == 'one_chunk':
            if chunk_num_next == 1:
                check_pass = True
        return check_pass
        
    def get_node_list_trans_direct(self, node_list):
        trans_direct = 'None'
        for curr_node in node_list:
            node_direct = self._get_node_trans_direct(curr_node)
            if node_direct != 'None':
                if trans_direct == 'None':
                    trans_direct = node_direct
                else:
                    if trans_direct != node_direct:
                        trans_direct = 'one_chunk'
                        break
        return trans_direct

    def _get_node_trans_direct(self, curr_node):
        if curr_node.op_type == NodeOpType.HardwareFusionNode:
            for sub_node in curr_node.sub_node_list:
                trans_direct = self._get_sub_node_trans_direct(sub_node)
                if trans_direct != 'None':
                    break
        else:
            trans_direct = self._get_sub_node_trans_direct(curr_node)
        return trans_direct

    def _get_sub_node_trans_direct(self, curr_node):
        if (curr_node.op_type == NodeOpType.ConvNode
            or curr_node.op_type == NodeOpType.MaxPoolNode
            or curr_node.op_type == NodeOpType.AveragePoolNode):
            transmit_direction = 'backward'
        elif curr_node.op_type == NodeOpType.UpsampleNode:
            transmit_direction = 'foreward'
        else:
            transmit_direction = 'None'
        return transmit_direction

#############################################
## for generation of didma_group_list
#############################################
    def get_in_didma_group_list(self, group_list):
        for i in range(len(group_list)):
            for j in range(len(group_list[i].node_list)):
                curr_node = group_list[i].node_list[j]
                for m in range(len(curr_node.parents)):
                    parent_node = curr_node.parents[m]
                    for k in range(len(group_list)):
                        if self._check_node_in_group(parent_node, group_list[k]) == True:
                            if k != i:
                                group_list[i].in_didma_group_list.append(group_list[k])
                                break
    
    def _check_node_in_group(self, node_in, node_group):
        check = False
        for node in node_group.node_list:
            if node.index == node_in.index:
                check = True
                break
        return check

#############################################
## for generation of group_parents
#############################################
    def get_group_parents(self, group_list):
        for i in range(len(group_list)):
            for j in range(len(group_list[i].node_list)):
                curr_node = group_list[i].node_list[j]
                for m in range(len(curr_node.parents)):
                    parent_node = curr_node.parents[m]
                    for k in range(len(group_list)):
                        if self._check_node_in_group(parent_node, group_list[k]) == True:
                            if k != i and (group_list[k] not in group_list[i].parents):
                                group_list[i].parents.append(group_list[k])
                                break
    
#############################################
## for generation of group_chidren
#############################################
    def get_group_child(self, group_list):
        for i in range(len(group_list)):
            last_node = group_list[i].node_list[-1]
            for j in range(len(last_node.children)):
                child_node = last_node.children[j]
                for k in range(len(group_list)):
                    if self._check_node_in_group(child_node, group_list[k]) == True:
                        if k != i and (group_list[k] not in group_list[i].children):
                            group_list[i].children.append(group_list[k])
                            break

#############################################
## for check of overflow
#############################################
    # def _check_sram_overflow(self, ch_list, row_list, col_list, x_st, x_ed, mode):
    #     ed = x_st - 1
    #     list_len = len(col_list)
    #     check_pass = True
    #     if mode == '4ch':
    #         st = ed + 1
    #         for i in range(list_len):
    #             col_list[i] = math.ceil(col_list[i] / 8)
    #         for i in range(list_len):
    #             ed = st + col_list[i] * math.floor((row_list[i] - 1) / 16) + col_list[i] - 1
    #             # ed = st + col_list[i] * math.ceil(row_list[i] / 16) - 1
    #             if ed > x_ed:
    #                 check_pass = False
    #     else:
    #         for i in range(list_len):
    #             st = ed + 1
    #             ed = st + col_list[i] * math.floor((row_list[i] * 
    #                 math.floor((ch_list[i] - 1) / 32) + row_list[i] - 1) / 16) + col_list[i] - 1
    #             if ed > x_ed:
    #                 check_pass = False
    #     return check_pass

    def _check_sram_overflow(self, ch_list, row_list, col_list, st_addr, ed_addr, mode, data_bw, getOffset=False):
        list_len = len(col_list)
        check_pass = True
        ed = st_addr - 1
        assert data_bw in [8, 14, 16]
        if mode == "4ch":
            if data_bw == 16 or data_bw == 14:
                for i in range(list_len):
                    col_list[i] = math.ceil(col_list[i] / 8)
                for i in range(list_len):
                    st = ed + 1
                    ed = st + math.ceil(row_list[i] / 16) * col_list[i] - 1
                    if(i==0):
                        offset = ed
                    if(ed > ed_addr):
                        check_pass = False
                        break
            elif data_bw == 8:
                for i in range(list_len):
                    col_list[i] = math.ceil(col_list[i] / 16)
                for i in range(list_len):
                    st = ed + 1
                    ed = st + math.ceil(row_list[i] / 16) * col_list[i] - 1
                    if(i==0):
                        offset = ed
                    if(ed > ed_addr):
                        check_pass = False
                        break
        else:
            if data_bw == 16 or data_bw == 14:
                for i in range(list_len):
                    st = ed + 1
                    ed = st + math.ceil(row_list[i] * math.ceil(ch_list[i] / 32) / 16) * col_list[i] - 1
                    if(i==0):
                        offset = ed
                    if(ed > ed_addr):
                        check_pass = False
                        break
            elif data_bw == 8:
                for i in range(list_len):
                    st = ed + 1
                    ed = st + math.ceil(row_list[i] * math.ceil(ch_list[i] / 64) / 16) * col_list[i] - 1
                    if(i==0):
                        offset = ed
                    if(ed > ed_addr):
                        check_pass = False
                        break
        if(getOffset):
            return [offset, check_pass]
        return [check_pass]

    def _check_sram_overflow_psum(self, ch_list, row_list, col_list, st_addr, ed_addr, k_r, data_bw):
        assert data_bw in [8, 14, 16]
        list_len = len(col_list)
        check_pass = True
        ed = st_addr - 1
        ## output
        st = ed + 1
        if data_bw == 16 or data_bw == 14:
            ed = st + math.ceil((row_list[0] * math.ceil(ch_list[0] / 32)) / 16) * col_list[0] - 1
        elif data_bw == 8:
            ed = st + math.ceil((row_list[0] * math.ceil(ch_list[0] / 64)) / 16) * col_list[0] - 1
        if(ed > ed_addr):
            check_pass = False
        ## psum
        st = ed + 1
        if st_addr != 0:
            st = st_addr * 2
        rbm_row_frame = math.ceil((row_list[-1] - (k_r - 1)) / 8)
        psum_max_addr = ((math.floor(rbm_row_frame / 2 ) + 1) * col_list[1])
        ed = st + psum_max_addr - 1
        if(ed > ed_addr):
            check_pass = False
        # for i in range(2):
        #     st = ed + 1
        #     if(i == 0):
        #         if data_bw == 16:
        #             ed = st + math.ceil((row_list[i] * math.ceil(ch_list[i] / 32)) / 16) * col_list[i] - 1
        #         elif data_bw == 8:
        #             ed = st + math.ceil((row_list[i] * math.ceil(ch_list[i] / 64)) / 16) * col_list[i] - 1
        #     else:
        #         rbm_row_frame = math.floor((row_list[-1] - (k_r - 1)) / 8)
        #         psum_max_addr = (math.floor(rbm_row_frame / 2 ) + 1) * col_list[i]
        #         ed = st + psum_max_addr - 1
        #     if(ed > ed_addr):
        #         check_pass = False
        return [check_pass]

    def _check_sc_pad_overflow(self, row, col):
        check_pass = True
        frame_num = math.ceil(row / 8)
        frame_col_num = frame_num * col
        if frame_col_num > 2048:
            check_pass = False
        return check_pass

#############################################
## for check of wasted row num
#############################################
    def waste_check(self, sub_node_list):
        waste_row_num = 0
        chunk_num = self.get_chunk_num(sub_node_list)
        if chunk_num > 1:
            for i in range(len(sub_node_list)):
                i_inv = len(sub_node_list) - 1 - i
                if sub_node_list[i_inv].op_type == NodeOpType.HardwareFusionNode:
                    for j in range(len(sub_node_list[i_inv].sub_node_list)):
                        j_inv = len(sub_node_list[i_inv].sub_node_list) - 1 - j
                        waste_row_num = self._get_waste_row(waste_row_num, 
                            sub_node_list[i_inv].sub_node_list[j_inv])
                else:
                    waste_row_num = self._get_waste_row(waste_row_num, sub_node_list[i_inv])
        if waste_row_num > 8:
            check_pass = False
        else:
            check_pass = True
        return check_pass

    def _get_waste_row(self, waste_row_in, node):
        if node.op_type == NodeOpType.ConvNode:
            waste_row_out = node.conv_param['strides'][0] * waste_row_in \
                + node.conv_param['kernel_shape'][0] \
                - node.conv_param['strides'][0]
        elif (node.op_type == NodeOpType.AveragePoolNode
            or node.op_type == NodeOpType.MaxPoolNode):
            if node.op_type == NodeOpType.AveragePoolNode:
                param = node.avgpool_param
            else:
                param = node.maxpool_param
            waste_row_out = param['strides'][0] * waste_row_in \
                + param['kernel_shape'][0] - param['strides'][0]
        else:
            waste_row_out = waste_row_in
        return waste_row_out

#############################################
## for display of node_group_list
#############################################
    def display_node_groups(self, assigned_groups):
        ### print information of assigned_groups
        print('----assigned_groups----')
        for i in range(len(assigned_groups)):
            print('--------')
            print('group id', assigned_groups[i].id)
            print('group type', assigned_groups[i].type)
            print('group st_idx', assigned_groups[i].st_idx, 'group_ed_idx', assigned_groups[i].ed_idx)
            print('parents:')
            for j in range(len(assigned_groups[i].parents)):
                parent = assigned_groups[i].parents[j]
                print('\tgroup_id:', parent.id)
            print('in_didma_group_list:')
            for j in range(len(assigned_groups[i].in_didma_group_list)):
                in_didma_group = assigned_groups[i].in_didma_group_list[j]
                print('\tgroup_id:', in_didma_group.id)
            print('children:')
            for j in range(len(assigned_groups[i].children)):
                child = assigned_groups[i].children[j]
                print('\tgroup_id:', child.id)
            print('hardware fused node:')
            for j in range(len(assigned_groups[i].node_list)):
                print(assigned_groups[i].node_list[j].name, end=' ')
                input_bw = assigned_groups[i].node_list[j].hardware_info['input_bitwidth']
                output_bw = assigned_groups[i].node_list[j].hardware_info['output_bitwidth']
                print(input_bw, output_bw, end=' ')
            print('\n')
            print('sub_node:')
            for j in range(len(assigned_groups[i].node_list)):
                if assigned_groups[i].node_list[j].op_type == NodeOpType.HardwareFusionNode:
                    for k in range(len(assigned_groups[i].node_list[j].sub_node_list)):
                        print(assigned_groups[i].node_list[j].sub_node_list[k].name, end=' ')
                else:
                    print(assigned_groups[i].node_list[j].name, end=' ')
            print('\n')
            print('input shape', assigned_groups[i].input_shape)
            print('output shape', assigned_groups[i].shape)
            print('chunk num', assigned_groups[i].chunk_num)
            print('input_chunk')
            for j in range(len(assigned_groups[i].input_chunk)):
                print(assigned_groups[i].input_chunk[j])
            print('output_chunk')
            for j in range(len(assigned_groups[i].output_chunk)):
                print(assigned_groups[i].output_chunk[j])
            print('--------')
#############################################
## for display of hardware fusion bitwidth
#############################################
    def display_hf_bw(self, assigned_groups):
        ### print information of assigned_groups
        print('----assigned_groups----')
        for i in range(len(assigned_groups)):
            print('--------')
            print(assigned_groups[i].id)
            print(assigned_groups[i].type)
            print(assigned_groups[i].st_idx, assigned_groups[i].ed_idx)
            print('hardware fused node:')
            for j in range(len(assigned_groups[i].node_list)):
                print(assigned_groups[i].node_list[j].name, end=' ')
                input_bw = assigned_groups[i].node_list[j].hardware_info['input_bitwidth']
                output_bw = assigned_groups[i].node_list[j].hardware_info['output_bitwidth']
                print(input_bw, output_bw, end=' ')
            print('\n')
            print('sub_node:')
            for j in range(len(assigned_groups[i].node_list)):
                print('|', assigned_groups[i].node_list[j].name, end=' ')
                if assigned_groups[i].node_list[j].op_type == NodeOpType.HardwareFusionNode:
                    for k in range(len(assigned_groups[i].node_list[j].sub_node_list)):
                        print(assigned_groups[i].node_list[j].sub_node_list[k].name, end=' ')
                        input_bw = assigned_groups[i].node_list[j].sub_node_list[k].hardware_info['input_bitwidth']
                        output_bw = assigned_groups[i].node_list[j].sub_node_list[k].hardware_info['output_bitwidth']
                        print(input_bw, output_bw, end=' ')
                else:
                    print(assigned_groups[i].node_list[j].name, end=' ')
                print('|')
            print('\n')
            print('--------')

    def check_branch(self, node):
        ## check if the node only has 2 children nodes, and one child 
        ## is the offspring of the other which only has a single chain to it
        if len(node.children) != 2:
            return 0
        [child1, child2] = node.children
        ## If is not the case that one child has a parent and the other one has two, return false
        if (not(len(child1.parents) == 2 and len(child2.parents) == 1)) and (not(len(child1.parents) == 1 and len(child2.parents) == 2)):
            return 0
        if(len(child1.parents) == 1 and len(child2.parents) == 2):
            leftNode = child2
            rightNode = child1
        else:
            leftNode = child1
            rightNode = child2
        currNode = rightNode
        branch_len = 0
        while(True):
            branch_len += 1
            if(currNode == leftNode):
                break
            elif(len(currNode.children) != 1):
                branch_len = 0
                break
            currNode = currNode.children[0]
        return branch_len